import {hasNourishment,nourishmentCapacity,nourishmentOf} from '../sim/nourishment';
import {personalRequests} from '../sim/promise_expectations';
import { describeGoal } from '../sim/life';
import { deceasedById } from '../sim/historical_index';
import { choiceKeys } from './choice_keys';
import { blockedCraftNeeds } from '../sim/options_work';
// The inhabitant's observation: everything an outside controller may know about the person it drives, and nothing else
// (docs/INHABITANT.md, section 2).
//
// PROVENANCE. Every field below is taken from the person's own records (`p.*`), and the comment on each field says which. The
// builder reads the World for three things only:
//   (a) what everyone feels: the tick, the light, the weather;
//   (b) the names of people whom the person's own records refer to by id (a relation, someone in sight, a promise, a worry);
//   (c) the person's own household: its name, who is in it, and their own home.
// It never reads world.events, world.sources / buildings / sites / plots / piles / animals, other people's needs, inventories,
// beliefs or plans, world.stats, the ledger, the dead, or the seed. The options are the engine's own offer to this person
// (decision.ts, after every hard filter); an option's target is described from the person's beliefs or from what is in sight,
// never from the world's index, so a remembered thing that has since vanished reads as remembered, not as gone.
//
// The result is deep-frozen. The prompt builder (protocol.ts) takes this object and nothing else.
import { BUILD_DEF, CRITICAL, NEED_KEYS, TOOL_DEFS } from '../sim/constants';
import { householdOf } from '../sim/buildings';
import { clockText, dayFraction, dayNumber, phaseName, weatherLabel } from '../sim/environment';
import { membersOf } from '../sim/households';
import { observedAge as ageText, observedDuration as durationText } from './time_text';
import { estimatedAmount, isWaterBeliefId } from '../sim/knowledge';
import { ACTIVITY_NOUN, BELIEF_NOUN, compass } from '../sim/labels';
import { isRich, thoughtsOf } from '../sim/mood';
import { ageYears, carryCap, stageOf, traitSummary } from '../sim/people';
import { relLabel } from '../sim/relations';
import { reservedFor } from '../sim/social';
import { hashString } from '../sim/rng';
import { toolsHeldBy } from '../sim/toolreg';
import { weightOf } from '../sim/economy';
import type { Ctx, Option } from '../sim/optutil';
import type { Belief, BuildingType, ItemKind, Items, NeedKey, Person, World } from '../sim/types';
import { hyp } from '../sim/util';
import { proposableItems } from '../sim/proposals';
import { PROJECT_LIMITS } from '../sim/project_graph';

/** 2 adds the tick (`t`) to memory entries and the last result, so notes can refer to them; 1 is the shape protocol inhabitant/1 recorded.
 *  3 adds the limits an action accepts. */
/** Bump when the observation's content or wording changes, and keep the old shape under the old version: replay rebuilds each ask's
 * observation and refuses one that differs from the recording, so every recorded transcript replays under the version its header names.
 *  7 adds active/recent personal plans (with what each has spoken for) and the carried/spoken-for/available split of the pack.
 *  8 says the walk to a site to be laid out is not counted in its estimate.
 *  9 says building work is a session, not a promise to finish the whole structure.
 * 10 distinguishes a remembered promise obstacle from a current obstruction.
 * 11 exposes the person's own aspiration and fulfilled history.
 * 12 explains personal trust used to select a project helper. */
// 13 adds dated coarse ecological signs and remembered field rest, never live soil data.
// 14 adds dated coarse natural-water supply, never exact remote hydrological stock.
// 15 adds dated local flood-ground observations, without actual recovery deadlines.
export const OBSERVATION_VERSION = 18;

export interface ObservedOption {
  /** the key the controller answers with: the engine's own option key */
  key: string;
  kind: string;
  label: string;
  goal: string;
  /** Personal basis for selecting this recipient, if present (observation 12+). */
  selectionReason?: string;
  /** the need it serves, if any */
  need: string | null;
  /** rough time to get there, in words */
  eta: string;
  /** the target as the person knows it; null when the option has no particular target */
  target: string | null;
  /** the engine's own score: only when the operator asks for it (`showScores`) */
  score?: number;
  /** limits this action accepts, with the range the engine will honour (version 3+; absent = it takes no parameters) */
  limits?: { field: string; kind: 'count' | 'until'; min: number; max: number; note: string }[];
}

export interface ObservedPlace {
  id: number;
  what: string;
  x: number;
  y: number;
  distance: number;
  direction: string;
  /** how long ago it was seen (by whoever saw it) */
  seen: string;
  /** 'seen' or 'told by <name>' (and how many mouths it passed through) */
  source: string;
  /** stale: not seen for a long time */
  stale: boolean;
  /** sources: what was there when seen, and what the person reckons is there now */
  amount?: number;
  estimate?: number;
  owner?: string;
  items?: Items;
  missing?: Items;
  state?: string;
  progress?: number;
  condition?: number;
  ecology?: string;
  fieldRest?: string;
  waterSupply?: string;
  fuel?: number;
  tools?: string[];
}

export interface ObservedPerson {
  id: number;
  name: string;
  x: number;
  y: number;
  distance: number;
  direction: string;
  /** what can be seen of their state */
  looks: string[];
  doing: string;
  carrying: ItemKind[];
  talking: boolean;
  relation: string;
}

export interface InhabitantObservation {
  version: number;
  /** (a) world.tick, world.light, world.weather */
  time: { tick: number; day: number; clock: string; phase: string; light: 'dark' | 'dim' | 'daylight'; weather: string; tempC: number };
  /** p.name, p.sex, p.birthTick, p.traits, p.skills, p.health, p.needs, p.inv, toolsHeldBy(p.id), p.cartId, p.x/y, p.mood */
  self: {
    name: string;
    sex: 'f' | 'm';
    stage: string;
    ageYears: number;
    character: string;
    skills: Record<string, number>;
    health: number;
    nourishment?: {stored:number;capacity:number};
    needs: Record<NeedKey, { value: number; state: 'ok' | 'low' | 'critical' }>;
    carrying: Items;
    load: { used: number; cap: number };
    /** what of the pack is already spoken for by a promise or a plan, and what is free for a new purpose (version 7+) */
    spokenFor?: Items;
    available?: Items;
    tools: { kind: string; label: string; wear: number; loan: string | null }[];
    pullingCart: boolean;
    position: { x: number; y: number };
    mood?: number;
    thoughts?: string[];
    /** Their own current hope and fulfilled history (observation 11+). */
    aspiration?: string | null;
    /** the trade they settled on, and the techniques they hold (version 7+) */
    trade?: { kind: string; why: string } | null;
    techniques?: string[];
  };
  /** (c) householdOf(p), membersOf(hh), hh.homeId; p.partnerId, p.parents, p.children */
  household: { name: string; members: { name: string; kin: string }[]; home: string | null; partner: string | null; parents: string[]; children: string[] };
  /** p.activity, p.suspended, p.convId (own conversation), p.lastResult, p.lastDecision */
  doing: {
    activity: { label: string; goal: string; phase: string; progress: number; target: string | null; blocked: string; since: string } | null;
    suspended: string | null;
    conversation: { partner: string; purpose: string } | null;
    lastResult: { label: string; outcome: string; detail: string; when: string; t?: number } | null;
    /** what this person's last exchange with someone came to, from their own side (version 3+) */
    lastInteraction?: { purpose: string; outcome: string; detail: string; when: string; t: number } | null;
    lastChoice: { label: string; when: string; trigger: string } | null;
  };
  /** p.seen */
  seen: { people: ObservedPerson[]; wolves: { x: number; y: number; distance: number; direction: string }[] };
  /** p.beliefs (nearest of each kind; `counts` says how many of each kind are known in all) */
  remembered: { places: ObservedPlace[]; water: ObservedPlace[]; dangers: ObservedPlace[]; floods?: ObservedPlace[]; counts: Record<string, number> };
  /** p.relations, p.whereabouts, p.concerns, world.requests where from/to is p, p.commitments */
  people: {
    relations: { id: number; name: string; label: string; affinity: number; trust: number; familiarity: number; kin: string; lastMet: string; avoiding: boolean; owesMe: number; lastNote: string; grievance: string | null }[];
    whereabouts: { id: number; name: string; x: number; y: number; when: string }[];
    worries: { about: string; kind: string; seen: string; source: string }[];
    requests: { direction: 'I asked' | 'asked of me'; other: string; what: string; status: string; note: string; when: string }[];
    promises: { text: string; status: string; detail: string; due: string }[];
    meetings?: {id:number;host:string;place:string;agreedAt:number;heardAt:number;from:number;conversationId?:number;reply:string;arrivedAt?:number;ateAt?:number;ending?:{tick:number;source:string;reason:string};laterExplanation?:{tick:number;source:string;reason:string}}[];
  };
  /** p.log, p.failures */
  recent: { memory: { when: string; text: string; kind: string; t?: number }[]; failures: { place: string; when: string; reason: string }[] };
  /** the engine's offer to this person now (rankOptions(ctx)), and what it set aside with the person's own reasons (ctx.blocked) */
  options: ObservedOption[];
  setAside: { label: string; reason: string; target: string | null }[];
  /** active and recently-ended private plans, with what each has spoken for (version 7+) */
  plans?: { goal: string; kind: string; status: string; step: string; wants: Items; blocked: string; reason: string; since: string }[];
  /** what the person could propose as a project of their own, from workshops they know of (version 17+; proposals.ts). Knowing a workshop is not feasibility: a proposal may still be refused. */
  canPropose?: { items: string[]; quantity: { min: number; max: number }; tiers: (0 | 1)[] };
  /** Own saved personal production goals only; feasibility is checked when a revision is requested. */
  canRevise?: {planId:number;item:string;quantity:number;until:number;reconsiderationsLeft:number}[];
}

export interface ObserveOptions {
  /** include the engine's own utility scores on the options (off: the controller judges for itself) */
  showScores?: boolean;
  /** the shape to build (OBSERVATION_VERSION unless a transcript recorded an older one) */
  version?: number;
}

const NEED_LOW: Record<NeedKey, number> = { hunger: 45, thirst: 45, energy: 32, warmth: 42, safety: 45, social: 35 };
const STALE_AFTER = 1800;
const PLACE_CAPS: Partial<Record<Belief['kind'], number>> = {
  berry_bush: 8,
  fruit_tree: 8,
  wild_grain: 8,
  fish_spot: 6,
  tree: 6,
  rock: 6,
  clay_pit: 4,
  ore_vein: 4,
  outcrop: 4,
  building: 24,
  site: 8,
  plot: 8,
  pile: 6,
  cart: 4,
  grave: 4,
};

/** control characters out, and nothing that could close the observation block in a prompt */
export function cleanText(s: string, max = 300): string {
  let t = '';
  for (let i = 0; i < s.length && t.length < max; i++) {
    const c = s.charCodeAt(i);
    if (c < 32 || c === 127) continue;
    t += s[i];
  }
  return t.replace(/<\/?observation/gi, '[observation]');
}

const r1 = (v: number): number => Math.round(v * 10) / 10;

/** (b) a name for an id taken from the person's own records */
function nameOf(world: World, id: number): string {
  const e = world.byId.get(id);
  if (e && e.ent === 'person') return e.name;
  const d = deceasedById(world,id);
  return d ? d.name : `someone (#${id})`;
}

function householdName(world: World, id: number): string {
  return world.households.find((h) => h.id === id)?.name ?? 'nobody';
}

function placeNoun(b: Belief): string {
  if (isWaterBeliefId(b.id)) return 'water (shore)';
  if ((b.kind === 'building' || b.kind === 'site') && b.btype) {
    const def = BUILD_DEF[b.btype as BuildingType];
    return def ? `${def.label}${b.kind === 'site' ? ' site' : ''}` : b.kind;
  }
  if (b.kind === 'danger') return 'wolf';
  return BELIEF_NOUN[b.kind] ?? b.kind;
}

function deepFreeze<T>(o: T): T {
  if (o && typeof o === 'object') {
    Object.freeze(o);
    for (const k of Object.keys(o as object)) deepFreeze((o as Record<string, unknown>)[k]);
  }
  return o;
}

function describePlace(world: World, p: Person, b: Belief, version: number): ObservedPlace {
  const dx = b.x - p.x;
  const dy = b.y - p.y;
  const out: ObservedPlace = {
    id: b.id,
    what: placeNoun(b),
    x: r1(b.x),
    y: r1(b.y),
    distance: Math.round(hyp(dx, dy)),
    direction: compass(dx, dy),
    seen: ageText(world, version, b.seen),
    source: b.src === 'seen' ? 'seen' : `told by ${nameOf(world, b.from)}${(b.hops ?? 1) > 1 ? ` (${b.hops} mouths)` : ''}`,
    stale: world.tick - b.seen > STALE_AFTER,
  };
  const isSource = !isWaterBeliefId(b.id) && !['building', 'site', 'plot', 'pile', 'grave', 'cart', 'danger', 'water'].includes(b.kind);
  if (isSource) {
    out.amount = b.amount;
    const est = estimatedAmount(world, b);
    if (est !== b.amount) out.estimate = est;
  }
  if (b.hh) out.owner = householdName(world, b.hh);
  if (b.items && Object.keys(b.items).length) out.items = { ...b.items };
  if (b.need && Object.keys(b.need).length) out.missing = { ...b.need };
  if (b.state) out.state = b.state;
  if(version>=14&&b.waterSupply)out.waterSupply=`${b.waterSupply} when observed; present availability and recharge date unknown`;
  if (version >= 13 && b.ecology) out.ecology = `${b.ecology} when observed; current condition and recovery date unknown`;
  if (version >= 13 && b.fallowUntil !== undefined) out.fieldRest = `Prepared to rest until tick ${b.fallowUntil}, as last observed`;
  if (b.progress !== undefined && (b.kind === 'site' || b.kind === 'plot')) out.progress = Math.round(b.progress * 100) / 100;
  if (b.cond !== undefined && b.kind === 'building') out.condition = Math.round(b.cond);
  if (b.fuel !== undefined && b.btype === 'fire') out.fuel = Math.round(b.fuel);
  if (b.tools && b.tools.length) out.tools = b.tools.slice();
  if (b.kind === 'plot' && b.amount) out.amount = b.amount;
  return out;
}

/** the target of an option or a failure, as the person knows it */
function describeTarget(world: World, p: Person, id: number, version: number): string | null {
  if (!id) return null;
  const s = p.seen.find((x) => x.id === id);
  if (s) {
    const d = Math.round(hyp(s.x - p.x, s.y - p.y));
    return s.ent === 'person' ? `${nameOf(world, id)} (in sight, ${d} tiles ${compass(s.x - p.x, s.y - p.y)})` : `wolf (in sight, ${d} tiles away)`;
  }
  const b = p.beliefs[id];
  if (b) return `${placeNoun(b)} ${Math.round(hyp(b.x - p.x, b.y - p.y))} tiles ${compass(b.x - p.x, b.y - p.y)} (seen ${ageText(world, version, b.seen)})`;
  const wh = p.whereabouts[id];
  if (wh) return `${nameOf(world, id)} (last seen ${ageText(world, version, wh.tick)})`;
  if (p.relations[id] || p.hhId === (world.byId.get(id) as Person | undefined)?.hhId) return nameOf(world, id);
  return `#${id}`;
}

function commitmentText(world: World, p: Person, c: Person['commitments'][number]): string {
  const to = nameOf(world, c.to);
  const site = c.siteId ? p.beliefs[c.siteId] : undefined;
  const siteText = site ? `the ${placeNoun(site)} ${Math.round(hyp(site.x - p.x, site.y - p.y))} tiles ${compass(site.x - p.x, site.y - p.y)}` : 'their building site';
  switch (c.kind) {
    case 'deliver':
      return `Bring ${c.amount} ${c.item ?? 'goods'} to ${to}`;
    case 'haul':
      return `Haul ${c.amount} ${c.item ?? 'goods'} to ${siteText}, as promised to ${to}`;
    case 'help_build':
      return `Help ${to} build`;
    case 'work':
      return `Do some work for ${to}${c.milestone ? ` (${c.milestone})` : ''}`;
    case 'return_tool':
      return `Return ${to}’s ${c.item ?? 'tool'}`;
    default:
      return `${c.kind} for ${to}`;
  }
}

function describeOption(world: World, p: Person, o: Option, showScores: boolean, version: number): ObservedOption {
  const selection=[o.selectionReason,o.routineReason].filter(Boolean).join(' · ');
  const out: ObservedOption = {
    key: o.key,
    kind: o.kind,
    label: cleanText(o.label, 120),
    goal: cleanText(version >= 9 && o.kind === 'build' && o.goal.startsWith('to finish ') ? 'to work on ' + o.goal.slice('to finish '.length) : o.goal + (version >= 12 && selection ? ` · ${selection}` : ''), 160),
    need: o.need,
    eta: o.eta > 0 ? durationText(o.eta, version) + (version >= 8 && o.kind === 'plan_site' ? ' (the walk there is not counted)' : '') : 'now',
    target: describeTarget(world, p, o.targetId, version),
  };
  if (showScores) out.score = Math.round(o.util * 10) / 10;
  if (version >= 12 && selection) out.selectionReason = cleanText(selection, 160);
  if (version >= 3 && o.bounds && o.bounds.length) {
    out.limits = o.bounds.map((b) => ({ field: b.field, kind: b.kind, min: b.min, max: b.max, note: cleanText(b.note, 160) }));
  }
  return out;
}

/** what of the pack a promise or a plan has already spoken for (version 7+): the union of active promises and the person's own plans. */
function spokenForItems(world: World, p: Person): Items {
  const out: Items = {};
  const kinds = new Set<ItemKind>([...Object.keys(p.inv) as ItemKind[], ...p.intentions.flatMap((i) => Object.keys(i.wants) as ItemKind[])]);
  for (const k of kinds) {
    const r = reservedFor(world, p, k);
    if (r > 0) out[k] = r;
  }
  return out;
}

/** what of the pack is free for a new purpose (version 7+): carried minus spoken-for, never negative. */
function availableItems(world: World, p: Person): Items {
  const out: Items = {};
  for (const k of Object.keys(p.inv) as ItemKind[]) {
    const v = (p.inv[k] ?? 0) - reservedFor(world, p, k);
    if (v > 0) out[k] = v;
  }
  return out;
}

/** active plans first, then recently-ended ones (version 7+); each with the materials it has spoken for and its own reason. */
function describePlans(world: World, p: Person, version: number): InhabitantObservation['plans'] {
  const chosen = p.intentions
    .filter((i) => i.status === 'active' || (i.ended > 0 && world.tick - i.ended < 6000))
    .sort((a, b) => (a.status === 'active' ? 0 : 1) - (b.status === 'active' ? 0 : 1) || b.since - a.since);
  return chosen.map((i) => ({
    goal: cleanText(i.goal, 160),
    kind: i.kind,
    status: i.status,
    step: cleanText(i.step, 160),
    wants: { ...i.wants },
    blocked: cleanText(i.blocked, 120),
    reason: cleanText(i.reason, 120),
    since: ageText(world, version, i.since),
  }));
}

/**
 * Build the observation for a person about to choose. `ranked` is the engine's offer (rankOptions(ctx), best first) and `ctx` the
 * person's own planning context; both come from the same decision the engine is making. Pure: reads, never writes, never draws a
 * random number.
 */
export function observeInhabitant(world: World, p: Person, ctx: Ctx, ranked: Option[], opts: ObserveOptions = {}): InhabitantObservation {
  const showScores = opts.showScores === true;
  const version = opts.version ?? OBSERVATION_VERSION;
  const hh = householdOf(world, p);
  const members = membersOf(world, hh).filter((m) => m.id !== p.id);
  const kinOf = (id: number): string => p.relations[id]?.kin || (p.partnerId === id ? 'partner' : p.parents.includes(id) ? 'parent' : p.children.includes(id) ? 'child' : '');
  const home = hh && hh.homeId ? world.byId.get(hh.homeId) : undefined;
  const homeBelief = hh && hh.homeId ? p.beliefs[hh.homeId] : undefined;
  const homeText = homeBelief ? `${placeNoun(homeBelief)} ${Math.round(hyp(homeBelief.x - p.x, homeBelief.y - p.y))} tiles ${compass(homeBelief.x - p.x, homeBelief.y - p.y)}${homeBelief.cond !== undefined ? ` (${Math.round(homeBelief.cond)}% sound when last seen)` : ''}` : home && home.ent === 'building' ? BUILD_DEF[home.type].label : null;

  const needs = {} as InhabitantObservation['self']['needs'];
  for (const k of NEED_KEYS) {
    const v = p.needs[k];
    needs[k] = { value: Math.round(v), state: CRITICAL[k] > 0 && v < CRITICAL[k] ? 'critical' : v < NEED_LOW[k] ? 'low' : 'ok' };
  }
  const skills: Record<string, number> = {};
  for (const k of Object.keys(p.skills) as (keyof Person['skills'])[]) skills[k] = Math.round(p.skills[k] * 100) / 100;
  const light = world.light < 0.3 ? 'dark' : world.light < 0.8 ? 'dim' : 'daylight';

  const self: InhabitantObservation['self'] = {
    name: p.name,
    sex: p.sex,
    stage: stageOf(world, p),
    ageYears: Math.floor(ageYears(world, p)),
    character: traitSummary(p.traits),
    skills,
    health: Math.round(p.health),
    ...(version>=18&&hasNourishment(world)?{nourishment:{stored:nourishmentOf(world,p),capacity:nourishmentCapacity(world,p)}}:{}),
    needs,
    ...(version >= 11 ? { aspiration: describeGoal(world, p) } : {}),
    carrying: { ...p.inv },
    load: { used: Math.round(weightOf(p.inv) * 10) / 10, cap: carryCap(world, p) },
    ...(version >= 7 ? { spokenFor: spokenForItems(world, p), available: availableItems(world, p) } : {}),
    tools: toolsHeldBy(world, p.id).map((t) => ({
      kind: t.kind,
      label: `${t.tier === 1 ? 'iron ' : ''}${TOOL_DEFS[t.kind].label}`,
      wear: Math.round(t.wear),
      loan: t.loan ? (t.loan.lender === 0 ? 'taken from a shared rack' : `borrowed from ${nameOf(world, t.loan.lender)}`) : t.ownerHh !== p.hhId ? `belongs to the ${householdName(world, t.ownerHh)} household` : null,
    })),
    pullingCart: p.cartId !== 0,
    position: { x: r1(p.x), y: r1(p.y) },
  };
  if (isRich(world) && p.mood) {
    self.mood = Math.round(p.mood.level);
    self.thoughts = thoughtsOf(world, p).map((t) => `${t.value > 0 ? '+' : ''}${Math.round(t.value)} ${cleanText(t.why, 80)}`);
  }
  if (version >= 7) {
    self.trade = p.trade ? { kind: p.trade.key, why: cleanText(p.trade.why, 120) } : null;
    self.techniques = Object.keys(p.techniques ?? {}).map((k) => (k === 'charcoal' ? 'charcoal firing' : k));
  }

  const a = p.activity;
  const doing: InhabitantObservation['doing'] = {
    activity: a
      ? {
          label: cleanText(a.label, 120),
          goal: cleanText(a.goal, 160),
          phase: a.phase,
          progress: a.duration > 0 ? Math.round(Math.min(1, a.progress / a.duration) * 100) / 100 : 0,
          target: describeTarget(world, p, a.targetId, version),
          blocked: cleanText(a.blocked, 120),
          since: ageText(world, version, a.start),
        }
      : null,
    suspended: p.suspended ? cleanText(p.suspended.label, 120) : null,
    conversation: null,
    lastResult: p.lastResult ? { label: cleanText(p.lastResult.label, 120), outcome: p.lastResult.outcome, detail: cleanText(p.lastResult.detail, 160), when: ageText(world, version, p.lastResult.tick), ...(version >= 2 ? { t: p.lastResult.tick } : {}) } : null,
    // what this person's own last exchange came to. A conversation deliberately leaves lastResult alone, so without this a
    // social action has no outcome the controller can see. Their own side only: never the other person's beliefs or plans.
    ...(version >= 3
      ? {
          lastInteraction: p.lastInteraction
            ? { purpose: String(p.lastInteraction.purpose), outcome: cleanText(p.lastInteraction.outcome, 60), detail: cleanText(p.lastInteraction.detail, 160), when: ageText(world, version, p.lastInteraction.tick), t: p.lastInteraction.tick }
            : null,
        }
      : {}),
    lastChoice: p.lastDecision && p.lastDecision.chosen ? { label: cleanText(p.lastDecision.chosen.label, 120), when: ageText(world, version, p.lastDecision.tick), trigger: p.lastDecision.trigger } : null,
  };
  if (p.convId) {
    const c = world.conversations.find((x) => x.id === p.convId);
    if (c) doing.conversation = { partner: nameOf(world, c.a === p.id ? c.b : c.a), purpose: c.purpose };
  }

  const seenPeople: ObservedPerson[] = [];
  const wolves: InhabitantObservation['seen']['wolves'] = [];
  for (const s of p.seen) {
    const dx = s.x - p.x;
    const dy = s.y - p.y;
    if (s.ent === 'animal') {
      wolves.push({ x: r1(s.x), y: r1(s.y), distance: Math.round(hyp(dx, dy)), direction: compass(dx, dy) });
      continue;
    }
    const looks: string[] = [];
    if (s.child) looks.push('a child');
    if (s.hungry) looks.push('hungry');
    if (s.thirsty) looks.push('thirsty');
    if (s.tired) looks.push('tired');
    if (s.cold) looks.push('cold');
    if (s.hurt) looks.push('hurt');
    if (s.asleep) looks.push('asleep');
    seenPeople.push({
      id: s.id,
      name: nameOf(world, s.id),
      x: r1(s.x),
      y: r1(s.y),
      distance: Math.round(hyp(dx, dy)),
      direction: compass(dx, dy),
      looks,
      doing: s.act ? ACTIVITY_NOUN[s.act] ?? s.act : '',
      carrying: s.carrying.slice(),
      talking: s.busyTalking,
      relation: relLabel(p.relations[s.id]),
    });
  }
  seenPeople.sort((m, n) => m.distance - n.distance);

  const byKind: Partial<Record<Belief['kind'], Belief[]>> = {};
  const counts: Record<string, number> = {};
  for (const k of Object.keys(p.beliefs)) {
    const b = p.beliefs[Number(k)];
    if(b.kind==='flood'&&version<15)continue;
    (byKind[b.kind] ??= []).push(b);
    counts[placeNoun({ ...b, btype: undefined })] = (counts[placeNoun({ ...b, btype: undefined })] ?? 0) + 1;
  }
  const nearest = (list: Belief[] | undefined, n: number): Belief[] => (list ? list.slice().sort((m, o) => hyp(m.x - p.x, m.y - p.y) - hyp(o.x - p.x, o.y - p.y)).slice(0, n) : []);
  const places: ObservedPlace[] = [];
  for (const kind of Object.keys(PLACE_CAPS) as Belief['kind'][]) for (const b of nearest(byKind[kind], PLACE_CAPS[kind] ?? 4)) places.push(describePlace(world, p, b, version));
  places.sort((m, n) => m.distance - n.distance);
  const water = nearest(byKind.water, 4).map((b) => describePlace(world, p, b, version));
  const dangers = (byKind.danger ?? [])
    .filter((b) => b.amount > 0 && world.tick - b.seen < 700)
    .sort((m, n) => hyp(m.x - p.x, m.y - p.y) - hyp(n.x - p.x, n.y - p.y))
    .slice(0, 6)
    .map((b) => describePlace(world, p, b, version));

  const relations: InhabitantObservation['people']['relations'] = [];
  for (const k of Object.keys(p.relations)) {
    const id = Number(k);
    const r = p.relations[id];
    if (r.familiarity < 1 && !r.kin) continue;
    relations.push({
      id,
      name: nameOf(world, id),
      label: relLabel(r),
      affinity: Math.round(r.affinity),
      trust: Math.round(r.trust),
      familiarity: Math.round(r.familiarity),
      kin: r.kin,
      lastMet: r.lastMet > 0 ? ageText(world, version, r.lastMet) : 'never',
      avoiding: r.avoidUntil > world.tick,
      owesMe: Math.round(r.debt),
      lastNote: r.history.length ? cleanText(r.history[r.history.length - 1].text, 120) : '',
      grievance: r.grievance ? `${r.grievance.cause.replace('_', ' ')}: ${cleanText(r.grievance.detail, 100)} (${Math.round(r.grievance.weight)}/100)` : null,
    });
  }
  relations.sort((m, n) => Math.abs(n.affinity) - Math.abs(m.affinity) || n.familiarity - m.familiarity);

  const inSight = new Set(p.seen.map((s) => s.id));
  const whereabouts = Object.keys(p.whereabouts)
    .map((k) => ({ id: Number(k), w: p.whereabouts[Number(k)] }))
    .filter((x) => !inSight.has(x.id) && world.tick - x.w.tick < 2400)
    .sort((m, n) => n.w.tick - m.w.tick)
    .slice(0, 10)
    .map((x) => ({ id: x.id, name: nameOf(world, x.id), x: r1(x.w.x), y: r1(x.w.y), when: ageText(world, version, x.w.tick) }));

  const worries = p.concerns.map((c) => ({
    about: nameOf(world, c.about),
    kind: c.kind === 'missing' ? 'has not been seen for a while' : `looked ${c.kind}`,
    seen: ageText(world, version, c.seen),
    source: c.src === 'seen' ? 'saw it myself' : `told by ${nameOf(world, c.from)}`,
  }));

  const requests: InhabitantObservation['people']['requests'] = [];
  for (const r of personalRequests(world,p)) {
    if (r.from !== p.id && r.to !== p.id) continue;
    if (world.tick - (r.resolved || r.created) > 3000) continue;
    const what = r.kind === 'info' ? (r.infoKind === 'person' ? `where ${describeTarget(world, p, r.destId ?? 0, version)} is` : `where to find ${r.infoKind}`) : r.kind === 'help_build' ? 'help with building' : r.kind === 'trade' ? `${r.offer} for ${r.item}` : r.kind === 'care' ? 'food (care)' : `${r.amount} ${r.item ?? r.kind}`;
    requests.push({ direction: r.from === p.id ? 'I asked' : 'asked of me', other: nameOf(world, r.from === p.id ? r.to : r.from), what, status: r.status, note: cleanText(r.note, 120), when: ageText(world, version, r.created) });
  }
  requests.reverse();

  const active = p.commitments.filter((c) => c.status === 'active');
  const ended = p.commitments.filter((c) => c.status !== 'active').slice(-4).reverse();
  const promises = [...active, ...ended].map((c) => {
    const parts: string[] = [];
    if (c.kind === 'deliver' || c.kind === 'haul') parts.push(`${c.delivered ?? 0} of ${c.amount} delivered`);
    if (c.reason) parts.push(cleanText(c.reason, 100));
    if (c.status === 'active' && c.blocked && c.blockedAt && world.tick - c.blockedAt < 600) parts.push(version >= 10 ? `last reported obstacle (${ageText(world, version, c.blockedAt)}): ${cleanText(c.blocked, 100)}` : `held up: ${cleanText(c.blocked, 100)}`);
    const due = c.deadline + (c.grace ?? 0);
    return { text: commitmentText(world, p, c), status: c.status, detail: parts.join(' · '), due: c.status === 'active' ? (due > world.tick ? `in ${durationText(due - world.tick, version)}` : 'overdue') : ageText(world, version, c.made) };
  });

  const failures: InhabitantObservation['recent']['failures'] = [];
  for (const k of Object.keys(p.failures)) {
    const id = Number(k);
    const f = p.failures[id];
    if (f.resolved || world.tick - f.tick > 900) continue;
    failures.push({ place: describeTarget(world, p, id, version) ?? `#${id}`, when: ageText(world, version, f.tick), reason: cleanText(f.reason, 100) });
  }
  failures.sort((m, n) => m.when.localeCompare(n.when));

  const publicKeys = version >= 4 ? choiceKeys(ranked) : ranked.map(o=>o.key);
  const obs: InhabitantObservation = {
    version,
    time: { tick: world.tick, day: dayNumber(world.tick), clock: clockText(world.tick), phase: phaseName(dayFraction(world.tick)), light, weather: weatherLabel(world.weather), tempC: Math.round(world.weather.temp) },
    self,
    household: {
      name: hh ? hh.name : 'none',
      members: members.map((m) => ({ name: m.name, kin: kinOf(m.id) })),
      home: homeText,
      partner: p.partnerId ? nameOf(world, p.partnerId) : null,
      parents: p.parents.map((id) => nameOf(world, id)),
      children: p.children.map((id) => nameOf(world, id)),
    },
    doing,
    seen: { people: seenPeople, wolves },
    remembered: { places, water, dangers, counts, ...(version>=15?{floods:nearest(byKind.flood,12).map(b=>describePlace(world,p,b,version))}:{}) },
    people: { relations: relations.slice(0, 14), whereabouts, worries, requests: requests.slice(0, 8), promises,
      ...(version>=16?{meetings:world.meals.filter(m=>!!m.heard?.[p.id]).slice(-6).map(m=>{const k=m.heard![p.id];return {id:m.id,host:k.hostName,place:k.placeName,agreedAt:k.at,heardAt:k.heardAt,from:k.from,...(k.conversationId?{conversationId:k.conversationId}:{}),reply:k.reply,...(k.arrivedAt!==undefined?{arrivedAt:k.arrivedAt}:{}),...(k.ateAt!==undefined?{ateAt:k.ateAt}:{}),...(k.ended?{ending:{tick:k.ended.tick,source:k.ended.source,reason:k.ended.reason}}:{}),...(k.laterExplanation?{laterExplanation:{tick:k.laterExplanation.tick,source:k.laterExplanation.source,reason:k.laterExplanation.reason}}:{})};})}:{}) },
    recent: {
      memory: p.log
        .slice(-14)
        .reverse()
        .map((l) => ({ when: ageText(world, version, l.tick), text: cleanText(l.text, 200), kind: l.kind, ...(version >= 2 ? { t: l.tick } : {}) })),
      failures: failures.slice(0, 6),
    },
    options: ranked.slice(0, 30).map((o,index) => ({...describeOption(world, p, o, showScores, version), key: publicKeys[index]})),
    setAside: [...(version >= 5 ? blockedCraftNeeds(ctx) : []), ...ctx.blocked].slice(0, 12).map((o) => ({ label: cleanText(o.label, 120), reason: cleanText(o.blocked ?? '', 160), target: describeTarget(world, p, o.targetId, version) })),
    ...(version >= 7 ? { plans: describePlans(world, p, version) } : {}),
    ...(version >= 17 ? { canPropose: { items: proposableItems(ctx), quantity: { min: 1, max: PROJECT_LIMITS.quantity }, tiers: [0, 1] } } : {}),
    ...(version >= 18 ? {canRevise:p.intentions.filter(i=>i.status==='active'&&i.kind==='batch'&&i.project&&!i.forSite&&i.makes!=='cart').map(i=>({planId:i.id,item:i.project!.goal.item,quantity:i.project!.goal.quantity,until:i.until,reconsiderationsLeft:Math.max(0,PROJECT_LIMITS.retries-i.project!.retries)}))} : {}),
  };
  return deepFreeze(obs);
}

/** a fingerprint of the observation as the controller saw it: the transcript records it and a replay checks it */
export function observationHash(obs: InhabitantObservation): string {
  return hashString(JSON.stringify(obs)).toString(16).padStart(8, '0');
}
