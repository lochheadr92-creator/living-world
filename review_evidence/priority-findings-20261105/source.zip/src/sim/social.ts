import {beginCoaching,coachingProblem,finishCoaching,interruptCoaching} from './skill_coaching';
import {isChildTime,childQuestion,childTimeName,beginChildTime,childTimeProblem,childTurn,finishChildTime,childTimeReport} from './childhood';
import {textileGiftProblem} from './clothing';
import {recordCompany} from './companionship';
import {hasChildhood} from './childhood_rules';
import {hasLivedLife} from './lived_life';
import { rememberedDry } from './water_access';
import { hasSuspendedEndings } from './suspended_endings';
import {hasMeetingKnowledge,receiveMeetingCancellation,acknowledgeMeetingCancellation} from './meeting_knowledge';
import {hasContinuityKnowledge,hearUndertaking,acknowledgeUndertaking} from './continuity_knowledge';
import {proposeHandover,answerHandover,type HandoverMode} from './work_handover';
import {hasWorkHandover} from './handover_state';
import {careJourneyReceipt} from './care_journey';
import {hasWarmthDuty,knownDutyFire,communicateFireLocation,fuelAvailable} from './warmth_duty';
import {hasCareHandback,proposeCareReturn,answerCareReturn} from './care_handback';
import {hasRepairDuty,knownDutyHome,communicateRoofLocation,repairSupplies,hasSingleRoofDuty,roofDuty} from './repair_duty';
import {hasLocationQuestions,tellWhereabouts} from './location_question';
import {repairMaterial} from './act_build';
import {hasBuildPromiseSettlement} from './promise_knowledge';
import {hasPromiseDelays,receiveDelayProposal,answerDelayProposal} from './promise_delays';
import {hasRequestCancellation,receiveCancellation,acknowledgeCancellation} from './request_cancellation';
import {hasPromiseTargets,targetOutcome} from './promise_targets';
import {hasPromiseExpectations,rememberExpectation,updateExpectations,expectedOutstanding} from './promise_expectations';
import {knowsDeath} from './death_knowledge';
import {hasPromiseOutcomes,deadlineOutcome,recordPromiseResolution,receiveOutcomeReport,acknowledgeOutcomeReport} from './promise_outcomes';
import { hasExchangeJourneys, tellTradeLead, endExchangeTalk, endExchangeApproach } from './exchange_journeys';
import { TECHNIQUES } from './techniques';
import type { TechniqueKind } from './techniques';
import { noteCustomer, customerSupplied, setCustomerDeps } from './customers';
import { noteWinterCare } from './winter_practice';
import { needsResidentCare, residentCareItems } from './resident_care';
import { isResidentCare } from './resident_contact';
import { offerLesson, answerLesson, answerRequestedLesson, finishLesson, interruptLesson, lessonProblem, LESSON_TICKS } from './techniques';
import { councilFor, nominate, oppositionReason, releaseOldSupport } from './civic_decision';
import { rememberRequest } from './social_memory';
import { recordProjectResponse, projectAt, canInvite, organiserExperience } from './townships';
import { receivedCivicBenefit } from './civic_benefit';
import { fetchableFood, hasFoodFetch } from './food_help';
import { agreedPlace } from './delivery_place';
import { hearDemand } from './local_demand';
import { outstandingForPlan, planShortfall, plannedFor } from './intent';
import { isRich, think } from './mood';
import { runsRulesVersion } from './rulesversion';
import { rememberedMaterialStores, usesMaterialStock } from './material_stock';
import { noteWedding } from './occasions';
import { noteDeed, noteDeedNear, reputationOf, shareRumour } from './reputation';
import { expose } from './illness';
import { leanOn, onMovedHousehold } from './lifechanges';
import { hears, mediate } from './mediation';
import { communicateWatchLocation, hasPracticalCare, laidUp, onDutyDeclined, settleFirePromise } from './responsibilities';
import {
  canInterruptForTalk,
  endActivity,
  faceToward,
  newActivity,
  registerHandler,
  resumeSuspended,
  endSuspended,
  startActivity,
  suspendActivity,
} from './activities';
import type { WorkResult } from './activities';
import { BUILD_DEF, CONV_REACH, DAY, GREET_COOLDOWN, LOAN_TERM, NUTRITION, PROMISE_TTL, REQUEST_TTL, homeNoun } from './constants';
import { foodUnits, pickFood, roomFor, transfer, releaseClaims } from './economy';
import { carryCap, isDependent, itemsToText, stageOf } from './people';
import { addEvent, addFx, addLog, say as speak } from './events';
import { addToHousehold, householdById, membersOf } from './households';
import { currentFailure, estimatedAmount, learn, noteFailure } from './knowledge';
import { adjustRel, relOf, spark } from './relations';
import { hashUnit } from './rng';
import * as D from './dialogue';
import { drive } from './needs';
import { BELIEF_NOUN } from './labels';
import { isFacilityType } from './recipes';
import { easeGrievance, endGrievanceOnGift, openGrievance, quarrelDamper, settleBoth } from './grievance';
import { inviteAsk, inviteRespond, mealReserved } from './meals';
import { shareConcerns } from './welfare';
import { lendTool, returnLoan } from './tools';
import { toolsHeldBy } from './toolreg';
import { isToolItem } from './toolreg';
import type { Belief, Commitment, Conversation, ConvPurpose, ItemKind, Items, Person, Request, RequestKind, Speech, ToolKind, World, BuildingType } from './types';
import { clamp, hyp } from './util';
import { hasLocalGiving } from './local_giving';
import {noteHelperReceipt} from './helper_learning';
import {hasPromiseKnowledge,recordPromiseCompletion,receiveCompletionReport,acknowledgeCompletionReport,completionContact} from './promise_knowledge';
import { noteCarePackFailure } from './care_capacity';

// ───────────────────────── small helpers ─────────────────────────
const toldKey = (listener: number, beliefId: number): number => listener * 1_000_000 + beliefId;

function bubble(world: World, p: Person, text: string, kind: Speech['kind'] = 'say', ticks = 56): void {
  speak(world, p, text, kind, ticks);
  world.stats.bubbles = (world.stats.bubbles ?? 0) + 1;
}

export function personOf(world: World, id: number): Person | null {
  const e = world.byId.get(id);
  return e && e.ent === 'person' && e.alive ? e : null;
}

const FOODS: ItemKind[] = ['berries', 'fruit', 'fish', 'grain', 'bread', 'meat', 'dried_fish', 'smoked_fish', 'dried_meat', 'smoked_meat', 'rendered_fat'];

export function isFood(k: ItemKind): boolean {
  return FOODS.includes(k);
}

/** What a person is holding back for themselves and their dependents. */
export function reserveOf(world: World, p: Person, item: ItemKind): number {
  const hh = householdById(world, p.hhId);
  const dep = membersOf(world, hh).filter((m) => m.id !== p.id && isDependent(world, m)).length;
  switch (item) {
    case 'water':
      return p.needs.thirst < 60 ? 1 : 0;
    case 'wood':
    case 'stone':
    case 'planks':
    case 'bricks':
    case 'handles':
    case 'clay':
    case 'ore':
    case 'charcoal':
    case 'iron': {
      let n = 0;
      for (const id of p.bykind.site ?? []) {
        const b = p.beliefs[id];
        if (b.hh === p.hhId || p.commitments.some((c) => c.status === 'active' && c.siteId === b.id)) n += b.need?.[item] ?? 0;
      }
      return n;
    }
    case 'seeds':
      return world.plots.filter((pl) => pl.hhId === p.hhId && pl.state === 'tilled').length;
    case 'axe':
    case 'pick':
    case 'hoe':
    case 'basket':
    case 'hammer':
    case 'saw':
    case 'jar':
      return 1;
    default:
      return 0;
  }
  void dep;
}

/**
 * Goods this person has promised to someone and not yet handed over. Nothing is stored for this: it is read off the open
 * commitments, so it vanishes the moment a promise is kept, set aside, expires, is moot, or its maker dies.
 */
import {reservedFor} from './reserved_goods';
export {reservedFor} from './reserved_goods';

/** How much of what `from` asked for (and has not yet got) is already spoken for by pending requests and promises. */
export function outstandingFor(world: World, from: number, item: ItemKind, destId = 0): number {
  if(hasPromiseExpectations(world)){const p=world.byId.get(from);return p?.ent==='person'?expectedOutstanding(world,p,item,undefined,destId):0;}
  let n = 0;
  for (const r of world.requests) {
    if (r.from !== from || r.item !== item) continue;
    if (destId && r.destId !== destId && r.siteId !== destId) continue;
    if (r.status === 'pending') n += r.amount;
    else if (r.status === 'promised') {
      const owner = world.byId.get(r.to);
      const c = owner && owner.ent === 'person' ? owner.commitments.find((x) => x.id === r.commitmentId && x.status === 'active') : undefined;
      n += c ? Math.max(0, c.amount - (c.delivered ?? 0)) : 0;
    }
  }
  return n;
}

/** People currently committed to put work or materials into a building site. */
export function helpersOn(world: World, siteId: number): number {
  let n = 0;
  for (const q of world.persons) if (q.alive && q.commitments.some((c) => c.status === 'active' && c.siteId === siteId && (c.kind === 'help_build' || c.kind === 'haul' || c.kind === 'work'))) n++;
  return n;
}

/** How much of `item` this person could part with without hurting themselves or their dependents. */
export function surplusOf(world: World, p: Person, item: ItemKind): number {
  const have = p.inv[item] ?? 0;
  if (isFood(item)) {
    const hh = householdById(world, p.hhId);
    const dep = membersOf(world, hh).filter((m) => m.id !== p.id && isDependent(world, m)).length;
    const keep = (p.needs.hunger < 55 ? 2 : 1) + dep * 2 + reservedFor(world, p, item) + mealReserved(world, p);
    const total = foodUnits(p.inv);
    return Math.max(0, Math.min(have - reservedFor(world, p, item), total - keep));
  }
  return Math.max(0, have - reserveOf(world, p, item) - reservedFor(world, p, item));
}

export function valueOf(world: World, p: Person, item: ItemKind): number {
  const base: Record<ItemKind, number> = {
  rod:5,
  beer:2,
  cutting:1.5,
  wool:2, rendered_fat:4,
  hide:5, fat:3,
  net:7,trap:8,fibre:1.2,garment:5,blanket:5,bedding:6,
    dried_fish:2.6, smoked_fish:2.8, dried_meat:2.6, smoked_meat:2.8,
    offcuts: 0.7,
    berries: 1, fruit: 1.3, fish: 2, grain: 1.6, bread: 2.4, meat: 2.2, water: 1, wood: 1.4, stone: 1.8, seeds: 2, clay: 1.5, ore: 2, planks: 2.6, handles: 2, bricks: 3, charcoal: 2.2, iron: 5,
    flour: 2, axe: 6, pick: 6, hoe: 6, basket: 5, hammer: 6, saw: 7, jar: 5, spear: 6,
  };
  let v = base[item];
  const have = p.inv[item] ?? 0;
  if (isFood(item)) {
    const total = foodUnits(p.inv);
    if (total < 3) v *= 1.9;
    else if (total > 8) v *= 0.55;
    v *= 1 + Math.max(0, 50 - p.needs.hunger) / 50;
  } else if (item === 'water') {
    v *= 1 + Math.max(0, 55 - p.needs.thirst) / 40;
  } else if (item === 'wood' || item === 'stone') {
    const need = reserveOf(world, p, item);
    if (need > have) v *= 1.8;
    else if (have > 6) v *= 0.6;
  }
  return v;
}

export function personalDriveMax(world: World, p: Person): number {
  return Math.max(drive(p.needs.hunger, 'hunger', world), drive(p.needs.thirst, 'thirst', world), drive(p.needs.warmth, 'warmth', world) * 0.8);
}

// ───────────────────────── gifts and relationships ─────────────────────────
function describeItems(items: Items): string {
  return itemsToText(items);
}

export function witness(world: World, kind: 'gift' | 'quarrel' | 'help', actor: Person, other: Person, x: number, y: number): void {
  for (const w of world.persons) {
    if (!w.alive || w === actor || w === other || w.pose === 'sleep') continue;
    if (hyp(w.x - x, w.y - y) > 7.5) continue;
    if (kind === 'gift' || kind === 'help') {
      adjustRel(w, actor.id, world.tick, { aff: 1.3, trust: 0.9, fam: 0.3, note: `saw ${actor.name} help ${other.name}` });
      noteDeed(world, w, actor, 'generous', `${actor.name} helped ${other.name}`, true);
    } else {
      adjustRel(w, actor.id, world.tick, { aff: -1.1, trust: -1.1, note: `saw ${actor.name} quarrel` });
      adjustRel(w, other.id, world.tick, { aff: -0.6, note: `saw ${other.name} quarrel` });
      noteDeed(world, w, actor, 'quarrelsome', `${actor.name} picked a quarrel with ${other.name}`, true);
    }
  }
}

/** Items have moved from `giver` to `receiver`: both remember it and onlookers notice. */
export function onGift(world: World, giver: Person, receiver: Person, items: Items, mode: string): void {
  careJourneyReceipt(world,giver,receiver.id,items);
  const hungerSev = isFoodGift(items) ? clamp((60 - receiver.needs.hunger) / 60, 0, 1) : 0;
  const thirstSev = (items.water ?? 0) > 0 ? clamp((60 - receiver.needs.thirst) / 60, 0, 1) : 0;
  const sev = Math.max(hungerSev, thirstSev, 0.2);
  const txt = describeItems(items);
  adjustRel(receiver, giver.id, world.tick, { aff: 2.5 + 7 * sev, trust: 2 + 4 * sev, fam: 1, debt: -0.5, note: `${giver.name} gave me ${txt}` });
  adjustRel(giver, receiver.id, world.tick, { aff: 1 + 1.5 * sev, fam: 0.5, debt: 0.5, note: `I gave ${receiver.name} ${txt}` });
  if (giver.hhId !== receiver.hhId) noteDeed(world, receiver, giver, 'generous', `${giver.name} gave ${receiver.name} ${txt}`, true);
  // a gift eases a quarrel in proportion to what it meant, and may end it
  endGrievanceOnGift(world, giver, receiver, sev);
  giver.stats.given += 1;
  receiver.stats.received += 1;
  // rules 53 (winter_practice.ts): a dependant fed in winter from a household that keeps stores lives the winter's meals too
  if (mode === 'care' && isFoodGift(items)) noteWinterCare(world, receiver, giver, Object.values(items).reduce((n, v) => n + (v ?? 0), 0));
  addLog(world, giver, 'social', `Gave ${txt} to ${receiver.name}${mode === 'care' ? ' (looking after them)' : ''}.`);
  addLog(world, receiver, 'social', `${giver.name} gave me ${txt}.`);
  think(world, receiver, 'gift:' + giver.id, 8, Math.round(DAY * 0.7), `${giver.name} gave me ${txt}`);
  witness(world, 'gift', giver, receiver, receiver.x, receiver.y);
  const notable = sev > 0.35 || giver.hhId !== receiver.hhId;
  if (notable && mode !== 'care') addEvent(world, 'social', `${giver.name} gave ${txt} to ${receiver.name}.`, [giver.id, receiver.id], receiver.x, receiver.y);
  else if (mode === 'care' && stageOf(world, receiver) === 'child' && hashUnit(giver.id, receiver.id, world.tick >> 6) < 0.25) addEvent(world, 'social', `${giver.name} fed ${receiver.name}.`, [giver.id, receiver.id], receiver.x, receiver.y);
  addFx(world, 'gift', receiver.x, receiver.y, 0);
  receiver.nextThink = world.tick;
}

function isFoodGift(items: Items): boolean {
  return FOODS.some((k) => (items[k] ?? 0) > 0);
}

// ───────────────────────── requests ─────────────────────────
export interface RequestOpts {
  kind: RequestKind;
  item?: ItemKind | null;
  amount?: number;
  offer?: ItemKind | null;
  offerAmount?: number;
  siteId?: number;
  infoKind?: string;
  purpose?: string;
  destKind?: Request['destKind'];
  destId?: number;
  deadline?: number;
  milestone?: string;
  toolKind?: ToolKind | null;
  /** the asker's own plan this is for (intent.ts), when it is for one */
  planId?: number;
  /** the ask was made under the rule that it should probably be answered yes (options_social.ts) */
  likely?: boolean;
}

export function createRequest(world: World, from: Person, to: Person, o: RequestOpts): Request {
  const r: Request = {
    id: world.nextId++,
    kind: o.kind,
    from: from.id,
    to: to.id,
    item: o.item ?? null,
    amount: o.amount ?? 1,
    offer: o.offer ?? null,
    offerAmount: o.offerAmount ?? 0,
    siteId: o.siteId ?? 0,
    infoKind: o.infoKind ?? '',
    planId: o.planId,
    likely: o.likely,
    created: world.tick,
    expires: world.tick + REQUEST_TTL,
    status: 'pending',
    note: '',
    resolved: 0,
    purpose: o.purpose ?? '',
    destKind: o.destKind ?? (o.siteId ? 'site' : 'person'),
    destId: o.destId ?? (o.siteId ? o.siteId : from.id),
    deadline: o.deadline ?? 0,
    milestone: o.milestone ?? '',
    toolKind: o.toolKind ?? null,
    outcome: '',
  };
  world.requests.push(r);
  if (world.requests.length > 260) {
    const idx = world.requests.findIndex((x) => x.status !== 'pending' && x.status !== 'promised');
    if (idx >= 0) world.requests.splice(idx, 1);
  }
  from.asked[to.id] = world.tick;
  return r;
}

export function settle(world: World, r: Request, status: Request['status'], note: string): void {
  r.status = status;
  r.note = note;
  r.resolved = world.tick;
  r.outcome = status === 'fulfilled' ? 'kept' : status === 'declined' ? 'refused' : status === 'expired' ? 'expired' : status === 'broken' ? 'broken' : status === 'interrupted' ? 'interrupted' : status === 'cancelled' ? 'cancelled' : status === 'failed' ? 'failed' : status;
  rememberRequest(world, r);
}

type Response =
  | { kind: 'give'; item: ItemKind; n: number }
  | { kind: 'promise'; item: ItemKind | null; n: number }
  | { kind: 'lend'; tool: import('./types').Tool }
  | { kind: 'decline'; reason: 'no_item' | 'no_place' | 'own_need' | 'unwilling' | 'disliked' | 'committed' | 'enough' | 'in_use' | 'making' };

export function willingness(world: World, B: Person, A: Person, severity: number): number {
  const rel = B.relations[A.id];
  const aff = rel?.affinity ?? 0;
  const trust = rel?.trust ?? 10;
  let w = 0.18 + 0.5 * B.traits.generosity + 0.42 * Math.max(0, aff) / 100 + 0.5 * severity + 0.1 * (trust - 10) / 100;
  if (rel?.kin) w += 0.28;
  if (B.hhId === A.hhId) w += 0.15;
  if (aff < -10) w += aff / 100;
  if (rel && rel.avoidUntil > world.tick) w -= 0.6;
  // what they have heard of the asker (rich only; 0 otherwise): a good name opens hands, a bad one closes them
  w += 0.25 * reputationOf(world, B, A.id);
  // a favour owed (rich only): whoever owes one is readier to grant a request
  if (isRich(world) && rel && rel.debt < 0) w += 0.12 * Math.min(3, -rel.debt);
  // the bereaved and new parents are helped more readily, most by those close to them (rich only; 0 otherwise)
  w += leanOn(world, B, A);
  w -= 0.45 * (personalDriveMax(world, B) / 100);
  w += (hashUnit(B.id, A.id, world.tick >> 5) - 0.5) * 0.16;
  return w;
}

/** Could B get hold of this item from somewhere they know of? (Used before promising to fetch it.) */
export function canObtain(world: World, B: Person, item: ItemKind): boolean {
  if (usesMaterialStock(world, 'promise') && rememberedMaterialStores(world, B, item).length) return true;
  const need = item === 'wood' ? 'tree' : item === 'stone' ? 'rock' : item === 'clay' ? 'clay_pit' : item === 'ore' ? 'ore_vein' : item === 'water' ? 'water' : null;
  const usable = (b: Belief): boolean => {
    const f = currentFailure(world, B, b.id);
    if (f && world.tick - f.tick < 520) return false; // they have just found it did not work
    return estimatedAmount(world, b) >= 1;
  };
  for (const k in B.beliefs) {
    const b = B.beliefs[k as unknown as number];
    if (item === 'stone' && b.kind === 'outcrop' && usable(b)) return true;
    if (need && b.kind === need && (b.kind === 'water' ? !rememberedDry(world,b) : usable(b))) return true;
    if (b.kind === 'building' && (b.items?.[item] ?? 0) >= 1 && (b.hh === B.hhId || b.hh === 0 || b.btype === 'storehouse') && !need) return true;
    if (!need && isFood(item) && (b.kind === 'berry_bush' || b.kind === 'fruit_tree' || b.kind === 'wild_grain' || b.kind === 'fish_spot') && estimatedAmount(world, b) >= 2) return true;
  }
  return false;
}

/** A tool B could lend to A without leaving themselves short: not borrowed themselves, not in use this moment. */
function lendableTool(world: World, B: Person, kind: ToolKind): import('./types').Tool | null {
  const mine = toolsHeldBy(world, B.id, kind).filter((t) => !t.loan && t.wear < 80);
  if (!mine.length) return null;
  const spare = mine.length >= 2;
  const using = B.activity && B.activity.phase === 'work' && toolInUse(B.activity.kind, kind);
  if (using && !spare) return null;
  mine.sort((a, c) => c.wear - a.wear); // lend the most worn one when there is a choice
  return spare ? mine[0] : mine[mine.length - 1];
}

function toolInUse(act: string, kind: ToolKind): boolean {
  switch (kind) {
    case 'axe':
    case 'pick':
    case 'basket':
      return act === 'gather';
    case 'hoe':
      return act === 'till' || act === 'tend';
    case 'hammer':
    case 'saw':
      return act === 'build' || act === 'repair' || act === 'operate' || act === 'craft';
    default:
      return false;
  }
}

export function evaluateRequest(world: World, B: Person, A: Person, req: Request): Response {
  const rel = B.relations[A.id];
  // a shared responsibility (responsibilities.ts; rich only): weighed against their own dependants, needs, promises and liking
  if (req.kind === 'watch' || req.kind === 'fire') {
    if (laidUp(world, B) || personalDriveMax(world, B) > 50) return { kind: 'decline', reason: 'own_need' };
    if(req.kind==='fire'&&hasWarmthDuty(world)){
      if(!req.destId||!knownDutyFire(world,A,req.destId)&&!knownDutyFire(world,B,req.destId))return {kind:'decline',reason:'no_place'};
      if(fuelAvailable(world,B,'wood')<1&&fuelAvailable(world,B,'offcuts')<1&&!canObtain(world,B,'wood')&&!canObtain(world,B,'offcuts'))return {kind:'decline',reason:'no_item'};
    }
    if (activeCommitments(B).length >= MAX_ACTIVE_COMMITMENTS) return { kind: 'decline', reason: 'committed' };
    const ownKids = membersOf(world, householdById(world, B.hhId)).filter((m) => m !== B && stageOf(world, m) === 'child').length;
    if (req.kind === 'watch' && ownKids >= 2) return { kind: 'decline', reason: 'own_need' };
    const w = willingness(world, B, A, 0.5) + (req.kind === 'watch' ? 0.1 * B.traits.generosity : 0);
    if (w < 0.5) return { kind: 'decline', reason: (rel?.affinity ?? 0) < -10 ? 'disliked' : 'unwilling' };
    return { kind: 'promise', item: null, n: 1 };
  }
  const dislike = (rel?.affinity ?? 0) < -12 || (rel && rel.avoidUntil > world.tick);
  let sev = 0.3;
  let item: ItemKind | null = req.item;
  if (req.kind === 'tool' && req.toolKind) {
    // lending is a favour with a promise to bring it back
    const w0 = willingness(world, B, A, 0.25) + 0.1 * Math.max(0, ((rel?.trust ?? 10) - 20) / 60);
    const t = lendableTool(world, B, req.toolKind);
    if (!t) return { kind: 'decline', reason: toolsHeldBy(world, B.id, req.toolKind).some((x) => !x.loan) ? 'in_use' : 'no_item' };
    if (w0 >= 0.62 && (rel?.trust ?? 10) >= 14) return { kind: 'lend', tool: t };
    return { kind: 'decline', reason: dislike ? 'disliked' : 'unwilling' };
  }
  if (req.kind === 'repair') {
    if(hasRepairDuty(world)&&(!req.destId||!knownDutyHome(world,A,req.destId)&&!knownDutyHome(world,B,req.destId)))return {kind:'decline',reason:'no_place'};
    // rules 102 (repair_duty.ts): a roof already promised is not promised again to somebody else
    if(hasSingleRoofDuty(world)&&req.destId&&roofDuty(B,req.destId))return {kind:'decline',reason:'committed'};
    const sound = stageOf(world, B) === 'adult' || stageOf(world, B) === 'youth';
    const w0 = willingness(world, B, A, 0.5) + 0.1;
    if (!sound) return { kind: 'decline', reason: 'unwilling' };
    if (activeCommitments(B).length >= MAX_ACTIVE_COMMITMENTS) return { kind: 'decline', reason: 'own_need' };
    const roof=hasRepairDuty(world)?knownDutyHome(world,B,req.destId??0)??knownDutyHome(world,A,req.destId??0):undefined;
    const has = hasRepairDuty(world)?!!repairMaterial({type:roof!.btype as BuildingType},repairSupplies(world,B,req.destId??0))||canObtain(world,B,'wood'):(B.inv.wood ?? 0) > 0 || canObtain(world, B, 'wood');
    if (!has) return { kind: 'decline', reason: 'no_item' };
    // having none to spare is not the same as having none: say which it is
    if (!hasRepairDuty(world)&&(B.inv.wood ?? 0) > 0 && surplusOf(world, B, 'wood') <= 0 && plannedFor(B, 'wood') > 0) return { kind: 'decline', reason: 'making' };
    if (w0 >= 0.62 && personalDriveMax(world, B) < 40) return { kind: 'promise', item: 'wood', n: 1 };
    return { kind: 'decline', reason: dislike ? 'disliked' : personalDriveMax(world, B) > 35 ? 'own_need' : 'unwilling' };
  }
  // a request already covered by what others have promised is not one more to answer
  if (req.item && (req.kind === 'wood' || req.kind === 'stone' || req.kind === 'goods' || req.kind === 'haul')) {
    const others = outstandingFor(world, A.id, req.item, req.destId ?? req.siteId ?? 0) - req.amount;
    const site = req.siteId ? world.byId.get(req.siteId) : undefined;
    // What the asker is REALLY short of, which is what other people's promises have to be measured against. For a building it is
    // what the site still wants; for a project of their own it is what that plan still lacks (intent.ts planShortfall, which counts
    // only the plan's own share of the pack). Measuring against this one request's size instead would refuse a perfectly good
    // top-up: two promises of one each do not cover a shortage of three.
    const lacks = site && site.ent === 'site'
      ? (site.required[req.item] ?? 0) - (site.delivered[req.item] ?? 0) - (site.used[req.item] ?? 0) - (A.inv[req.item] ?? 0)
      : req.planId
        ? planShortfall(A, req.planId, req.item)
        : req.amount;
    if (others >= Math.max(0, lacks)) return { kind: 'decline', reason: 'enough' };
    // B already owes the same thing to the same place
    const owes = B.commitments.filter((c) => c.status === 'active' && c.item === req.item && (c.destId ?? c.siteId) === (req.destId ?? req.siteId)).reduce((n, c) => n + c.amount - (c.delivered ?? 0), 0);
    if (owes >= req.amount) return { kind: 'decline', reason: 'committed' };
  }
  if (req.kind === 'food' || req.kind === 'care') {
    sev = clamp((62 - A.needs.hunger) / 62, 0.05, 1);
    item = pickFood(B.inv, A.needs.hunger) ?? null;
    // someone else’s share must not shortchange B's own dependents
    if (item && surplusOf(world, B, item) < 1) item = FOODS.find((k) => surplusOf(world, B, k) >= 1) ?? null;
  } else if (req.kind === 'water') {
    sev = clamp((66 - A.needs.thirst) / 66, 0.05, 1);
    item = 'water';
  } else if (req.kind === 'wood' || req.kind === 'stone') {
    sev = 0.35;
    item = req.kind;
  } else if (req.kind === 'goods' || req.kind === 'haul') {
    sev = 0.35;
    item = req.item;
  } else if (req.kind === 'seeds') {
    sev = 0.3;
    item = 'seeds';
  }
  const w = willingness(world, B, A, sev);
  // Rules 45 (food_help.ts): with no food to spare in the pack, which kind could B go and fetch from a source they know?
  // Null below 45, when the switch is off, or when they know of none - and then everything below is exactly as it was.
  const fetchKind = (req.kind === 'food' || req.kind === 'care') && (!item || surplusOf(world, B, item) < 1) ? fetchableFood(world, B) : null;
  if (!item && !fetchKind) return { kind: 'decline', reason: dislike ? 'disliked' : 'no_item' };
  const sur = item ? surplusOf(world, B, item) : 0;
  if (item && sur >= 1) {
    if (w >= 0.6) {
      const want = req.kind === 'food' || req.kind === 'care' ? Math.min(sur, Math.max(1, Math.ceil(sev * 3))) : Math.min(sur, req.amount);
      const n = Math.max(1, want);
      if (carriesToSite(world, B, A, req, item)) return { kind: 'promise', item, n };
      return { kind: 'give', item, n };
    }
    return { kind: 'decline', reason: dislike ? 'disliked' : personalDriveMax(world, B) > 35 ? 'own_need' : 'unwilling' };
  }
  // nothing to hand over right now: could B fetch some?
  if (fetchKind) {
    // Rules 45: the promise names the kind B knows a source of, so the foraging and the delivery bring that kind and no other
    if (w >= 0.66 && personalDriveMax(world, B) < 38 && B.commitments.filter((c) => c.status === 'active').length < 2) return { kind: 'promise', item: fetchKind, n: Math.max(1, req.amount) };
  } else if (item && !(hasFoodFetch(world) && isFood(item)) && w >= 0.66 && personalDriveMax(world, B) < 38 && B.commitments.filter((c) => c.status === 'active').length < 2 && canObtain(world, B, item) && (item === 'wood' || item === 'stone' || item === 'water' || item === 'clay' || item === 'ore' || ((item === 'planks' || item === 'bricks' || item === 'handles') && B.commitments.length < 3) || isFood(item))) {
    // (below 45 a food promise still falls back to "berries" here, as recorded; at 45 and later only a known kind is promised)
    return { kind: 'promise', item: isFood(item) ? (B.inv[item] ? item : 'berries') : item, n: Math.max(1, req.amount) };
  }
  if (!item) return { kind: 'decline', reason: dislike ? 'disliked' : personalDriveMax(world, B) > 35 ? 'own_need' : 'unwilling' };
  const have = B.inv[item] ?? 0;
  if (have > 0) {
    // They have some but none spare. In a rich world which claim is on it is known exactly, so the answer says that rather than
    // "my own needs come first": `reservedFor` is promises plus private plans, and `plannedFor` is the plans' share of it. An
    // authored world keeps the answer it always gave, because the reason a refusal gives is part of what follows from it (the
    // bubble, the log, and whether anyone takes offence).
    if (isRich(world)) {
      const planned = plannedFor(B, item);
      const owed = reservedFor(world, B, item) - planned;
      if (owed > 0) return { kind: 'decline', reason: 'committed' };
      if (planned > 0) return { kind: 'decline', reason: 'making' };
    }
    return { kind: 'decline', reason: 'own_need' };
  }
  return { kind: 'decline', reason: dislike ? 'disliked' : 'no_item' };
}


/** An accepted gift can become a real haul when the asker cannot carry even one unit.
 * Read the helper's remembered site, never its unseen current existence or stock.
 * The ordinary haul validates physical arrival and delivery; stale knowledge can still fail.
 */
function carriesToSite(world: World, B: Person, A: Person, req: Request, item: ItemKind): boolean {
  if (!isRich(world) || !runsRulesVersion(world, 11)) return false;
  if (!req.siteId || req.destKind !== 'site' || req.destId !== req.siteId || isFood(item) || item === 'water' || isToolItem(item)) return false;
  if (roomFor(A.inv, carryCap(world, A), item) >= 1) return false;
  const site = B.beliefs[req.siteId];
  if (site?.kind !== 'site' || (site.need?.[item] ?? 0) < 1) return false;
  return activeCommitments(B).length < MAX_ACTIVE_COMMITMENTS && personalDriveMax(world, B) < 38;
}

function addCommitment(world: World, B: Person, req: Request, c: Partial<Commitment>): Commitment {
  const commit: Commitment = {
    id: world.nextId++,
    requestId: req.id,
    kind: 'deliver',
    to: req.from,
    item: null,
    amount: 1,
    siteId: 0,
    made: world.tick,
    deadline: world.tick + PROMISE_TTL,
    status: 'active',
    delivered: 0,
    destKind: req.destKind,
    destId: req.destId,
    grace: 0,
    ...c,
  };
  B.commitments.push(commit);
  req.commitmentId = commit.id;
  B.nextThink = world.tick;
  return commit;
}

/** Work or materials went into a building site: whoever promised to help with it is credited. */
export function creditContribution(p: Person, siteId: number, amount: number): void {
  if (!siteId) return;
  for (const c of p.commitments) if (c.status === 'active' && c.siteId === siteId && (c.kind === 'help_build' || c.kind === 'haul' || c.kind === 'work')) c.contrib = (c.contrib ?? 0) + amount;
}

/** A hard stop on how many promises one person carries at a time. */
export const MAX_ACTIVE_COMMITMENTS = 3;
export const activeCommitments = (p: Person): Commitment[] => p.commitments.filter((c) => c.status === 'active');

/** Survival came first: promises are put aside (not neglected) while a critical need or danger is dealt with. */
export function markSetAside(world: World, p: Person): void {
  for (const c of p.commitments) if (c.status === 'active') c.setAside = world.tick;
}

/** Someone died: what they had promised is moot, what was promised to them is released, and what they had asked for is withdrawn. */
export function socialOnDeath(world: World, p: Person): void {
  for (const c of p.commitments) {
    if (c.status !== 'active') continue;
    c.status = 'moot';
    c.reason = `${p.name} died`;
    const r = world.requests.find((x) => x.id === c.requestId);
    if (r && r.status === 'promised') settle(world, r, 'cancelled', `${p.name} died before they could`);
  }
  for (const r of world.requests) {
    if (r.status !== 'pending' && r.status !== 'promised') continue;
    if (r.from === p.id) {
      settle(world, r, 'cancelled', `${p.name} died`);
      const owner = world.byId.get(r.to);
      if (owner && owner.ent === 'person'&&(!hasPromiseExpectations(world)||knowsDeath(owner,p.id))) for (const c of owner.commitments) if (c.requestId === r.id && c.status === 'active') {
        c.status = 'moot';
        c.reason = `${p.name} died`;
      }
    } else if (r.to === p.id && r.status === 'pending') settle(world, r, 'cancelled', `${p.name} died`);
  }
}

/** Called when a promised delivery arrives. */
export function fulfillCommitment(world: World, B: Person, commitmentId: number): void {
  const c = B.commitments.find((x) => x.id === commitmentId);
  if (!c || c.status !== 'active') return;
  c.status = 'done';
  const req = world.requests.find((r) => r.id === c.requestId);
  const A = personOf(world, c.to);
  if (req) {
    // The promise was kept; whether the ASK was met is a different question, and the answer is what actually arrived. (Rich only:
    // an authored world records what it always did.)
    const got = req.delivered ?? c.delivered ?? 0;
    // A watch promises time and attention, not a quantity of goods. Its actual work milestone is the evidence.
    const watched = hasPracticalCare(world) && req.kind === 'watch' && c.kind === 'work' && c.milestone === 'watched' && (c.contrib ?? 0) >= 40;
    const workDone=hasPromiseTargets(world)&&['work','help_build'].includes(c.kind)&&((c.contrib??0)>=40||c.targetEvidence?.source==='completed here');
    const full = !isRich(world) || got >= req.amount || watched || workDone;
    settle(world, req, full ? 'fulfilled' : 'partial', watched ? 'kept watch for the agreed time' : workDone ? 'completed my promised work contribution' : full ? 'promise kept' : `promise kept: ${got} of the ${req.amount} asked for`);
  }
  if(hasPromiseKnowledge(world)){
    const witnessed=req&&recordPromiseCompletion(world,A,B,req,c);
    if(witnessed&&A){bubble(world,A,D.saying(D.THANKS,A.id,B.id,world.tick>>4,{n:B.name}),'happy');addEvent(world,'social',`${A.name} saw ${B.name} complete a promised contribution.`,[A.id,B.id],A.x,A.y);}
    return;
  }
  if (A) {
    adjustRel(A, B.id, world.tick, { aff: 3, trust: 6, note: `${B.name} kept their promise` });
    adjustRel(B, A.id, world.tick, { aff: 1, trust: 1 });
    noteDeed(world, A, B, 'reliable', `${B.name} kept a promise to ${A.name}`, true);
    bubble(world, A, D.saying(D.THANKS, A.id, B.id, world.tick >> 4, { n: B.name }), 'happy');
    addEvent(world, 'social', `${B.name} kept a promise to ${A.name}.`, [A.id, B.id], A.x, A.y);
  }
}

/**
 * Upkeep of promises. A promise ends in exactly one of these ways, each with its own consequence:
 *   done         – kept (the request is fulfilled)
 *   expired      – the time ran out after some of it was done: partly kept, credit in proportion
 *   moot         – the need went away (the site was finished or abandoned, the other person died)
 *   interrupted  – the maker put it aside for their own survival until it was too late: a small mark, no blame
 *   failed       – it turned out to be impossible (nothing to give, nowhere to get it): a small mark
 *   broken       – the maker was free to do it and did not: the real penalty
 * Time asleep and time spent on survival does not count against the deadline.
 */
export function checkCommitments(world: World, p: Person): void {
  updateExpectations(world,p);
  for (const c of p.commitments) {
    if (c.status !== 'active') continue;
    if(hasPromiseTargets(world)&&settleFirePromise(world,p,c))continue;
    const targetResult=targetOutcome(world,c);
    if(targetResult){
      if(targetResult.done)fulfillCommitment(world,p,c.id);
      else {
        c.status='moot';c.reason=targetResult.reason;
        const a=p.activity;if(a&&(a.data.commitmentId===c.id||a.targetId===c.targetEvidence!.targetId&&['repair','build','haul','fuel_fire'].includes(a.kind)))endActivity(world,p,'interrupted',c.reason);
        const r=world.requests.find(r=>r.id===c.requestId);if(r){if(r.status==='promised')settle(world,r,'cancelled',c.reason);else rememberRequest(world,{...r,status:'cancelled',note:c.reason});recordPromiseResolution(world,p,r,c);}
      }
      continue;
    }
    // The accepted building share uses the same 40-tick contract as deadline settlement; a whole site is not owed.
    if(hasBuildPromiseSettlement(world)&&c.kind==='help_build'&&(c.contrib??0)>=40){fulfillCommitment(world,p,c.id);continue;}
    const A = personOf(world, c.to);
    const req = world.requests.find((r) => r.id === c.requestId);
    if(!A&&hasPromiseExpectations(world)&&!knowsDeath(p,c.to)){
      if(p.pose==='sleep'||p.activity?.need)c.grace=(c.grace??0)+40;
      const effective=c.deadline+(c.grace??0);
      if(world.tick>effective&&!(p.activity?.data.commitmentId===c.id&&world.tick<effective+300)){
        const total=c.kind==='help_build'||c.kind==='work'?40:Math.max(1,c.amount),got=c.kind==='help_build'||c.kind==='work'?c.contrib??0:c.delivered??0;
        if(got>=total)fulfillCommitment(world,p,c.id);else {deadlineOutcome(world,c,got/total);if(req){const own={...req,status:c.status as 'expired'|'interrupted'|'failed',note:c.reason!};rememberRequest(world,own);recordPromiseResolution(world,p,own,c);}}
      }
      continue;
    }
    if (!A) {
      c.status = 'moot';
      c.reason = hasPromiseExpectations(world)?'learned that the requester died':'the other person is gone';
      if(hasPromiseExpectations(world)&&p.activity?.data.commitmentId===c.id)endActivity(world,p,'interrupted',c.reason);
      if (req && (req.status === 'promised' || req.status === 'pending')) settle(world, req, 'cancelled', 'the other person is gone');
      continue;
    }
    if(hasPromiseExpectations(world)&&c.milestone==='watched'&&c.destId&&knowsDeath(p,c.destId)){
      c.status='moot';c.reason='learned that the child died';if(p.activity?.data.commitmentId===c.id)endActivity(world,p,'interrupted',c.reason);if(req&&req.status==='promised')settle(world,req,'cancelled',c.reason);continue;
    }
    if (p.pose === 'sleep' || (p.activity && p.activity.need)) c.grace = (c.grace ?? 0) + 40;
    // a building that no longer needs help. In a rich world the maker has to have found that out for themselves: while they still
    // carry a belief about the site, the promise stands (they learn it is gone by going there, which clears the belief).
    if (!hasPromiseTargets(world) && (c.kind === 'help_build' || c.kind === 'haul' || c.kind === 'work') && c.siteId && !world.byId.has(c.siteId) && !(isRich(world) && p.beliefs[c.siteId] !== undefined && world.tick < c.deadline + (c.grace ?? 0))) {
      const did = (c.contrib ?? 0) > 0 || (c.delivered ?? 0) > 0;
      c.status = did ? 'done' : 'moot';
      c.reason = did ? 'the building was finished with their help' : 'the building was finished or given up';
      if (req && req.status === 'promised') settle(world, req, did ? 'fulfilled' : 'cancelled', c.reason);
      continue;
    }
    if (c.kind === 'work' && c.destKind === 'building') {
      const target = c.destId ? world.byId.get(c.destId) : undefined;
      if (!hasPromiseTargets(world)&&(!target || target.ent !== 'building')) {
        c.status = 'moot';
        c.reason = 'the building is gone';
        if (req && req.status === 'promised') settle(world, req, 'cancelled', c.reason);
        continue;
      }
      // a promise to keep a fire going is kept by feeding it (responsibilities.ts), not by the state of a roof
      if (settleFirePromise(world, p, c)) continue;
      const seenCond = c.milestone === 'fire kept' ? -1 : isRich(world) ? p.beliefs[c.destId??0]?.cond : target?.ent==='building'?target.condition:undefined;
      if ((seenCond ?? -1) >= 62) {
        const did = (c.contrib ?? 0) > 0;
        c.status = did ? 'done' : 'moot';
        c.reason = did ? 'mended' : 'it was mended by someone else';
        if (req && req.status === 'promised') settle(world, req, did ? 'fulfilled' : 'cancelled', c.reason);
        if(did&&hasPromiseKnowledge(world)){if(req)recordPromiseCompletion(world,A,p,req,c);}
        else if (did) adjustRel(A, p.id, world.tick, { aff: 3, trust: 5, note: `${p.name} mended our roof` });
        continue;
      }
    }
    if (c.kind === 'return_tool') {
      const t = c.toolId ? toolsHeldBy(world, p.id).find((x) => x.id === c.toolId) : undefined;
      if (!t || !t.loan) {
        // returned (or gone): nothing left to keep
        c.status = 'done';
        c.reason = 'handed back';
        continue;
      }
    }
    const effective = c.deadline + (c.grace ?? 0);
    const delivering = !!p.activity && p.activity.data.commitmentId === c.id && world.tick < effective + 300;
    if (world.tick <= effective || delivering) continue;
    // the time is up
    const total = c.kind === 'help_build' || c.kind === 'work' ? 40 : Math.max(1, c.amount);
    const got = c.kind === 'help_build' || c.kind === 'work' ? Math.min(total, c.contrib ?? 0) : Math.min(total, c.delivered ?? 0);
    const frac = got / total;
    if(hasPromiseKnowledge(world)&&frac>=1){fulfillCommitment(world,p,c.id);continue;}
    if(hasPromiseOutcomes(world)&&frac<1){
      deadlineOutcome(world,c,frac);
      if(req&&req.status==='promised'){settle(world,req,c.status as 'expired'|'interrupted'|'failed',c.reason!);recordPromiseResolution(world,p,req,c);}
      continue;
    }
    if (frac >= 1) {
      c.status = 'done';
      if (req && req.status === 'promised') settle(world, req, 'fulfilled', 'did what they promised');
      adjustRel(A, p.id, world.tick, { aff: 2.5, trust: 3, note: `${p.name} helped with the building` });
    } else if (frac > 0) {
      c.status = 'expired';
      c.reason = `only ${Math.round(frac * 100)}% was done in time`;
      if (req && req.status === 'promised') settle(world, req, 'expired', c.reason);
      adjustRel(A, p.id, world.tick, { aff: 2.5 * frac - 0.5, trust: 4 * frac - 1, note: `${p.name} did part of what they promised` });
      addLog(world, p, 'social', `Only managed part of what I promised ${A.name}.`);
    } else if (c.setAside && world.tick - c.setAside < 900) {
      c.status = 'interrupted';
      c.reason = 'put aside while seeing to their own needs';
      if (req && req.status === 'promised') settle(world, req, 'interrupted', c.reason);
      adjustRel(A, p.id, world.tick, { trust: -1, aff: -0.4, note: `${p.name} could not manage what they promised` });
      addLog(world, p, 'social', `Could not get to what I promised ${A.name}: my own needs came first.`);
    } else if (c.blockedAt && world.tick - c.blockedAt < 600) {
      c.status = 'failed';
      c.reason = c.blocked ?? 'could not be done';
      if (req && req.status === 'promised') settle(world, req, 'failed', c.reason);
      adjustRel(A, p.id, world.tick, { trust: -2, aff: -0.6, note: `${p.name} found they could not do what they promised` });
      addLog(world, p, 'social', `Could not do what I promised ${A.name}: ${c.reason}.`);
    } else {
      c.status = 'broken';
      c.reason = 'not done in time';
      if (req) settle(world, req, 'broken', 'not delivered in time');
      adjustRel(A, p.id, world.tick, { aff: -5, trust: -12, note: `${p.name} did not keep a promise` });
      adjustRel(p, A.id, world.tick, { trust: -2, aff: -1 });
      noteDeed(world, A, p, 'unreliable', `${p.name} broke a promise to ${A.name}`, true);
      openGrievance(world, A, p, 'broken_promise', `${p.name} did not do what they promised`, 38);
      addLog(world, p, 'social', `Failed to keep my promise to ${A.name}.`);
      addLog(world, A, 'social', `${p.name} never came through with what they promised.`);
      addEvent(world, 'conflict', `${p.name} did not keep a promise to ${A.name}.`, [p.id, A.id], A.x, A.y);
    }
  }
  if (p.commitments.length > 10) p.commitments = p.commitments.filter((c) => c.status === 'active' || world.tick - c.made < 4000);
}

export function updateRequests(world: World): void {
  for (const r of world.requests) {
    if (r.status !== 'pending') continue;
    if (world.tick > r.expires) {
      settle(world, r, 'expired', 'never got an answer');
      continue;
    }
    keepOwnAskHonest(world, r);
  }
}

/**
 * An ask that is still waiting for an answer belongs to the person who made it, and they may have been answered another way since:
 * somebody else promised some, or the material arrived, or they spent what the project wanted on something else. So while it is
 * pending they keep it in step with their own plan and their own pack - narrowing it to what is still uncovered, or withdrawing it
 * when nothing is wanted any more. It uses nothing but what the asker knows, and it never touches a promise anyone has made: an
 * obligation once given runs its own course (the helper learns of a change by being there, not by being told from afar).
 *
 * It touches an ask that is still waiting and nothing else: a request that has been answered, withdrawn or expired is finished with,
 * and its record stays as whoever settled it left it.
 */
function keepOwnAskHonest(world: World, r: Request): void {
  if (r.status !== 'pending') return;
  if (!r.planId || !r.item) return;
  const asker = personOf(world, r.from);
  if (!asker) return;
  const plan = asker.intentions.find((i) => i.id === r.planId && i.status === 'active');
  if (!plan) {
    settle(world, r, 'cancelled', 'no longer needed: that project has ended');
    return;
  }
  const short = (plan.wants[r.item] ?? 0) - (asker.inv[r.item] ?? 0);
  // what everything OTHER than this ask already covers
  const elsewhere = outstandingForPlan(world, asker.id, r.item, plan.id) - r.amount;
  const uncovered = short - Math.max(0, elsewhere);
  if (uncovered <= 0) {
    settle(world, r, 'cancelled', 'no longer needed: it is covered now');
    return;
  }
  if (uncovered < r.amount) r.amount = uncovered; // narrowed to what is still wanted, before anybody answers it
}

export { answerInfo, pickNews, tellBelief } from './news';
import { pickNews, tellBelief, answerInfo } from './news';
import { noteContact, observeOffer } from './transmission';

// ───────────────────────── conversations ─────────────────────────
function acceptsTalk(world: World, b: Person, a: Person, purpose: ConvPurpose): { ok: boolean; why: string } {
  if (!b.alive || b.pose === 'sleep') return { ok: false, why: 'was asleep' };
  if (b.convId) return { ok: false, why: 'was already talking to someone' };
  if(hasChildhood(world)&&stageOf(world,b)==='child'&&b.activity?.kind==='alone'&&['chat','trade','invite','propose','recruit','family_time','play_together','learn_foraging','learn_technique','teach_technique'].includes(purpose))return {ok:false,why:'wanted to finish some quiet time'};
  const avail = canInterruptForTalk(b);
  if (avail <= 0) return { ok: false, why: 'was busy' };
  const rel = b.relations[a.id];
  if (rel && rel.avoidUntil > world.tick && purpose !== 'apologize' && purpose !== 'warn') return { ok: false, why: 'did not want to talk' };
  if (purpose === 'mediate' && !hears(a, b)) return { ok: false, why: 'would not hear of it' };
  if (personalDriveMax(world, b) > 62 && purpose !== 'request' && purpose !== 'warn') return { ok: false, why: 'had more pressing needs' };
  // someone visibly hungry or thirsty asking for help is hard to put off
  const visibleNeed = (a.needs.hunger < 38 || a.needs.thirst < 38) && (purpose === 'request' || purpose === 'ask_info') ? 0.3 : 0;
  const urgent = (purpose === 'warn' ? 0.4 : purpose === 'request' || purpose === 'offer' || purpose === 'invite' ? 0.12 : 0) + visibleNeed;
  const prob = clamp(avail * (0.5 + 0.45 * b.traits.sociability) + (rel?.affinity ?? 0) / 220 + urgent + (rel?.kin ? 0.2 : 0), 0, 0.97);
  if (hashUnit(b.id, a.id, world.tick >> 4) < prob) return { ok: true, why: '' };
  return { ok: false, why: 'was too busy to stop' };
}

/**
 * Key prefix for what somebody told this person about their own pack: `p.cooldowns[MAKING_NOTE + id]` stands until the tick by
 * which "my <item> is for something I am making" stops being worth remembering. It is the asker's own record of an answer they
 * were actually given, and it is what keeps them from asking the same neighbour again while they are still making it.
 */
export const MAKING_NOTE = 'making:';
/** how long that answer is remembered (half a day: about as long as the plans that cause it) */
export const MAKING_MEMORY = DAY / 2;

export interface ConvData {
  skill?: import('./types').SkillKey;
  exchangeJourney?: number;
  reqKind?: RequestKind;
  item?: ItemKind | null;
  amount?: number;
  offer?: ItemKind | null;
  offerAmount?: number;
  siteId?: number;
  infoKind?: string;
  items?: Items;
  joinKind?: 'partner' | 'roommate';
  requestId?: number;
  toolKind?: ToolKind;
  purpose?: string;
  destKind?: Request['destKind'];
  destId?: number;
  deadline?: number;
  milestone?: string;
  mealId?: number;
  replacesMealId?: number;
  mealPlan?: import('./meals').MealPlan;
  /** the asker's own plan the request is for (intent.ts) */
  planId?: number;
  handoverId?: number;
  handoverMode?: HandoverMode;
  /** the ask passed the asker's own "they would probably say yes" test when it was made (options_social.ts) */
  likely?: boolean;
  /** for a mediation: the other party of the quarrel the listener holds */
  pair?: number;
  /** why an ask got no answer: it had stopped being an ask (withdrawn, expired, already answered) by the time it was reached */
  moot?: string;
  /** rules 51 (customers.ts): the request this offer or swap supplies, so the supplier's record and the ask close together */
  customer?: number;
  /** rules 52 (techniques.ts): the procedure a lesson is about; absent for the rules-18 charcoal lesson */
  technique?: TechniqueKind;
}

function convOf(world: World, id: number): Conversation | undefined {
  return world.conversations.find((c) => c.id === id);
}

function openConversation(world: World, A: Person, B: Person, actA: import('./types').Activity, purpose: ConvPurpose, data: ConvData): void {
  const c: Conversation = { id: world.nextId++, a: A.id, b: B.id, purpose, start: world.tick, phase: 0, nextAt: world.tick, end: 0, requestId: 0, data: { ...data } };
  world.conversations.push(c);
  noteContact(world, 'conversation', A.id, B.id, c.id);
  // initiator: the 'socialize' activity becomes the conversation
  actA.kind = 'converse';
  actA.label = `Talking with ${B.name}`;
  actA.goal = purposeGoal(world, purpose, B.name);
  actA.phase = 'work';
  actA.progress = 0;
  actA.data = { convId: c.id, role: 'a' };
  actA.expire = world.tick + 500;
  actA.claims = [];
  A.convId = c.id;
  // the other person stops what they were doing
  suspendActivity(world, B);
  const actB = newActivity(world, B, { kind: 'converse', label: `Talking with ${A.name}`, goal: 'a chat', here: true, maxTicks: 500, minCommit: 400, data: { convId: c.id, role: 'b' } });
  startActivity(world, B, actB);
  B.convId = c.id;
  faceToward(A, B.x, B.y, 3);
  faceToward(B, A.x, A.y, 3);
}

function purposeGoal(world: World, purpose: ConvPurpose, name: string): string {
  if(purpose==='learn_skill')return `to ask ${name} for skill coaching`;
  if(isChildTime(purpose))return `${childTimeName(purpose)} with ${name}`;
  switch (purpose) {
    case 'return_care': return `to agree with ${name} about taking childcare back`;
    case 'handover_work': return `to agree with ${name} who continues the undertaking`;
    case 'share_work': return `to tell ${name} about my household work`;
    case 'cancel_meeting': return `to explain a cancelled meal to ${name}`;
    case 'delay_request':
      return `to explain a delay and ask ${name} for more time`;
    case 'cancel_request':
      return `to cancel obsolete work with ${name}`;
    case 'report':
      return hasPromiseOutcomes(world)?`to report on promised work to ${name}`:`to report completed work to ${name}`;
    case 'learn_technique':
      return `to ask ${name} for instruction`;
    case 'teach_technique':
      return `to teach ${name} a procedure`;
    case 'request':
      return `to ask ${name} for something`;
    case 'ask_info':
      return `to ask ${name} what they know`;
    case 'warn':
      return `to warn ${name}`;
    case 'offer':
      return `to help ${name}`;
    case 'apologize':
      return `to make peace with ${name}`;
    case 'mediate':
      return `to help ${name} make peace`;
    case 'recruit':
      return `to get ${name}'s help with a building`;
    case 'propose':
      return `to propose something to ${name}`;
    case 'trade':
      return `to swap goods with ${name}`;
    case 'invite':
      return `to invite ${name} to eat together`;
    default:
      return `to catch up with ${name}`;
  }
}

/** What a warning came to, read off the evidence the exchange recorded. Every case is a state the engine set; none is guessed. */
function warnReport(c: Conversation): { text: string; detail: string; outcome: 'success' | 'partial' } {
  if (c.data.warnDelivered === true) return { text: 'warned them', detail: 'they had not heard; they know now', outcome: 'success' };
  if (c.data.warnDelivered === false) return { text: 'they already knew', detail: 'they knew as much or more already', outcome: 'partial' };
  if (c.data.warnNothing) return { text: 'nothing to tell', detail: 'no fresh danger worth passing on', outcome: 'partial' };
  return { text: 'never got to it', detail: 'the talk ended before the warning was passed', outcome: 'partial' };
}

function endTalkActivity(world: World, p: Person, outcome: 'success' | 'interrupted', detail?:string): void {
  p.convId = 0;
  if (p.activity && p.activity.kind === 'converse') {
    p.activity.data.finished = true;
    if(detail)p.activity.data.childhoodResult=true;
    endActivity(world, p, outcome, detail ?? (outcome === 'success' ? 'finished a conversation' : 'conversation cut short'));
  }
  if (!p.activity) resumeSuspended(world, p);
}

function finishConversation(world: World, c: Conversation, outcome: 'success' | 'interrupted'): void {
  const A = personOf(world, c.a);
  const B = personOf(world, c.b);
  const i = world.conversations.indexOf(c);
  if (i >= 0) world.conversations.splice(i, 1);
  // remember how this exchange ended, for each side, as one record (the partner, purpose and result stay together)
  const req = world.requests.find((r) => r.id === c.requestId);
  // a warning carries its own evidence (news.ts tellBelief said whether the belief actually passed), and makes no request
  const told = c.purpose === 'warn' && outcome === 'success' ? warnReport(c) : null;
  // an ask that had stopped being an ask by the time it was answered: said as that, and not as a favour given or refused
  const moot = typeof c.data.moot === 'string' ? (c.data.moot as string) : '';
  const report=hasCareHandback(world)&&c.purpose==='return_care'?{text:c.data.careReturnAnswered?'childcare return answered':c.data.careReturnHeard?'childcare return heard without answer':'childcare return not proposed',detail:c.data.careReturnReply??c.data.careReturnText??'No childcare responsibility changed.'}:hasWorkHandover(world)&&c.purpose==='handover_work'?{text:c.data.handoverAnswered?'handover answered':c.data.handoverDelivered?'handover heard without answer':'handover not conveyed',detail:c.data.handoverReply??c.data.handoverText??'No responsibility changed.'}:hasContinuityKnowledge(world)&&c.purpose==='share_work'?{text:c.data.workAcknowledged?'undertaking acknowledged':c.data.workDelivered?'undertaking heard without acknowledgement':'undertaking not conveyed',detail:c.data.workText??'No undertaking passed.'}:hasMeetingKnowledge(world)&&c.purpose==='cancel_meeting'?{text:c.data.meetingAcknowledged?'meal cancellation acknowledged':c.data.meetingDelivered?'meal cancellation heard, acknowledgement not received':'meal cancellation not delivered',detail:c.data.meetingText??'No meeting update passed.'}:hasPromiseDelays(world)&&c.purpose==='delay_request'?{text:c.data.delayAnswered?'delay proposal answered':c.data.delayDelivered?'delay explained, answer not heard':'delay explanation not delivered',detail:c.data.delayReply??c.data.delayText??'No delay explanation passed.'}:hasRequestCancellation(world)&&c.purpose==='cancel_request'?{text:c.data.cancelAcknowledged?'cancellation acknowledged':c.data.cancelDelivered?'cancellation heard, acknowledgement not received':'cancellation not delivered',detail:c.data.cancelReply??c.data.cancelText??'No cancellation passed.'}:(hasPromiseKnowledge(world)||hasPromiseOutcomes(world))&&c.purpose==='report'?{text:c.data.reportAcknowledged?'report acknowledged':c.data.reportDelivered?'report heard, acknowledgement not received':'report not delivered',detail:c.data.reportText??'No completion report passed.'}:null;
  if(outcome==='interrupted'){interruptLesson(c,'the lesson was cut short');interruptCoaching(c);}
  const gift=hasLivedLife(world)&&c.purpose==='offer'?c.data.giftReceipt:null;
  const childhood=childTimeReport(c,outcome==='interrupted');
  const resultText = c.skillLesson?c.skillLesson.outcome:childhood?childhood.text:gift ? gift.outcome : c.lesson ? c.lesson.outcome : report?report.text:outcome === 'interrupted' ? 'cut short' : moot ? 'nothing was needed' : told ? told.text : req ? (req.outcome || req.status) : c.data.sour ? 'ended sourly' : 'friendly';
  const detailText = c.skillLesson?c.skillLesson.reason:childhood?childhood.detail:gift ? gift.detail : c.lesson ? c.lesson.reason : report?report.detail:outcome === 'interrupted' ? 'one of them had to go' : moot ? moot : told ? told.detail : req ? req.note : '';
  if (A) A.lastInteraction = { tick: world.tick, partner: c.b, purpose: c.purpose, role: 'asked', outcome: resultText, detail: detailText };
  if (B) B.lastInteraction = { tick: world.tick, partner: c.a, purpose: c.purpose, role: 'answered', outcome: resultText, detail: detailText };
  // a fever passes in talk (rich only; nothing in an authored world)
  if (A && B) {
    expose(world, A, B, 0.12);
    expose(world, B, A, 0.12);
  }
  if (outcome === 'success' && A && B && !childhood) {
    for (const [x, y] of [[A, B], [B, A]] as [Person, Person][]) {
      const rel = relOf(x, y.id);
      // how well do these two get along? temperaments that fit warm up quickly, ones that clash do not
      const fit = 1 - (Math.abs(x.traits.sociability - y.traits.sociability) + Math.abs(x.traits.generosity - y.traits.generosity) + Math.abs(x.traits.diligence - y.traits.diligence)) / 3;
      const early = rel.familiarity < 6 ? 1.5 : 1;
      const chem = hashUnit(Math.min(x.id, y.id), Math.max(x.id, y.id), 7) - 0.5; // some pairs click, some grate
      let gain = (fit - 0.6) * 4.6 * early + chem * 3.0 + (rel.familiarity > 3 && rel.affinity > 8 ? 0.8 : 0);
      if (y.needs.hunger < 28 || y.needs.energy < 20 || y.needs.warmth < 28) gain -= 0.7; // nobody is good company when miserable
      // two unattached adults with a spark between them warm to each other much faster
      if (gain > 0 && !x.partnerId && !y.partnerId && stageOf(world, x) !== 'child' && stageOf(world, y) !== 'child' && !rel.kin && spark(x, y)) gain += 2.6;
      if (rel.avoidUntil > world.tick || c.data.sour) gain = Math.min(gain, 0.2) * 0.4;
      adjustRel(x, y.id, world.tick, { aff: gain, fam: 1.3, trust: gain > 0 ? 0.6 : -0.2 });
      x.needs.social = Math.min(100, x.needs.social + (9 + 11 * x.traits.sociability) * (rel.affinity >= 20 ? 1.2 : 1));
      x.stats.talked++;
      x.cooldowns['talk' + y.id] = world.tick + 220;
    }
    if(!c.data.sour&&(c.purpose==='chat'||c.lesson?.outcome==='learned'||c.data.giftReceipt?.outcome==='received gift')){
      const taught=c.lesson?.outcome==='learned';
      recordCompany(world,A,B,c.data.giftReceipt?.outcome==='received gift'||taught&&c.purpose==='teach_technique');
      recordCompany(world,B,A,taught&&c.purpose==='learn_technique');
    }
    A.wave = world.tick + 20;
    B.wave = world.tick + 24;
  }
  if (A) endExchangeTalk(world,A,c.data.exchangeJourney,req,detailText||resultText);
  const childEnd=childhood?(c.childhood?.outcome==='completed'?'success':'interrupted'):outcome;
  if (A) endTalkActivity(world, A, childEnd,childhood?`${resultText}: ${detailText}`:undefined);
  if (B) endTalkActivity(world, B, childEnd,childhood?`${resultText}: ${detailText}`:undefined);
}

/** Called when someone is removed from the world mid-conversation. */
export function abortConversationFor(world: World, p: Person): void {
  if (!p.convId) return;
  const c = convOf(world, p.convId);
  if (c) finishConversation(world, c, 'interrupted');
  p.convId = 0;
}

/** Per-tick conversation director: advances scripted phases, each of which acts on real state. */
export function updateConversations(world: World): void {
  for (const c of [...world.conversations]) {
    const A = personOf(world, c.a);
    const B = personOf(world, c.b);
    if (!A || !B || A.convId !== c.id || B.convId !== c.id) {
      finishConversation(world, c, 'interrupted');
      continue;
    }
    if (hyp(A.x - B.x, A.y - B.y) > CONV_REACH + 2.5 || world.tick - c.start > 400) {
      finishConversation(world, c, 'interrupted');
      continue;
    }
    if(c.purpose==='learn_skill'&&c.skillLesson?.outcome==='learning'&&coachingProblem(world,c,A,B)){finishConversation(world,c,'interrupted');continue;}
    if(isChildTime(c.purpose)){
      if(!completionContact(world,A,B)||(c.childhood?.outcome==='sharing'&&childTimeProblem(world,c,A,B))){finishConversation(world,c,'interrupted');continue;}
      const turn=childTurn(world,c,A,B);if(turn)bubble(world,turn.p,turn.text,'happy',24);
    }
    if((hasCareHandback(world)&&c.purpose==='return_care'||hasWorkHandover(world)&&c.purpose==='handover_work'||hasContinuityKnowledge(world)&&c.purpose==='share_work'||hasMeetingKnowledge(world)&&(c.purpose==='cancel_meeting'||c.purpose==='invite')||(hasPromiseKnowledge(world)||hasPromiseOutcomes(world))&&c.purpose==='report'||hasRequestCancellation(world)&&c.purpose==='cancel_request'||hasPromiseDelays(world)&&c.purpose==='delay_request')&&!completionContact(world,A,B)){finishConversation(world,c,'interrupted');continue;}
    if(c.purpose==='teach_technique') {
      const why=lessonProblem(world,A,B,lessonKind(c));
      if(why){interruptLesson(c,why);finishConversation(world,c,'interrupted');continue;}
    }
    if(c.purpose==='learn_technique'&&c.lesson?.outcome==='learning') {
      const why=lessonProblem(world,B,A,lessonKind(c));
      if(why){interruptLesson(c,why);finishConversation(world,c,'interrupted');continue;}
    }
    if (world.tick < c.nextAt) continue;
    advance(world, c, A, B);
  }
}

function friendly(p: Person, q: Person): boolean {
  return (p.relations[q.id]?.affinity ?? 0) >= 28;
}

function advance(world: World, c: Conversation, A: Person, B: Person): void {
  const d = c.data as ConvData & { sour?: boolean; reqId?: number };
  switch (c.phase) {
    case 0: {
      // greeting
      A.wave = world.tick + 26;
      if (friendly(A, B) && hashUnit(A.id, B.id, world.tick >> 6) < 0.3) bubble(world, A, D.greeting(world, B.name, true, A.id, B.id), 'say', 44);
      c.phase = 1;
      c.nextAt = world.tick + 9;
      break;
    }
    case 1: {
      B.wave = world.tick + 24;
      phaseAsk(world, c, A, B, d);
      c.phase = 2;
      c.nextAt = world.tick + 22;
      break;
    }
    case 2: {
      phaseRespond(world, c, A, B, d);
      recordProjectResponse(world, A, B, reqOf(world, c));
      c.phase = 3;
      c.nextAt = c.skillLesson?.outcome==='learning'?c.skillLesson.until:c.childhood?.outcome==='sharing'?c.childhood.until:world.tick + (c.lesson?.outcome==='learning'?LESSON_TICKS:22);
      break;
    }
    case 3: {
      if(c.purpose==='learn_skill'){if(finishCoaching(world,c,A,B))bubble(world,A,'Thank you. I can put that practice to use.','happy',60);c.phase=4;c.nextAt=world.tick+16;break;}
      if(isChildTime(c.purpose))finishChildTime(world,c,A,B);
      if(c.purpose==='learn_technique'){
        if(finishLesson(world,c,B,A))bubble(world,A,`I can ${TECHNIQUES[lessonKind(c)].doing} for my work now.`,'happy',72);
        c.phase=4;c.nextAt=world.tick+16;break;
      }
      if(c.purpose==='teach_technique'){
        if(finishLesson(world,c,A,B))bubble(world,B,`I understand how to ${TECHNIQUES[lessonKind(c)].doing} now.`,'happy',72);
        c.phase=4;c.nextAt=world.tick+16;break;
      }
      if (!d.sour) {
        phaseNews(world, A, B);
        phaseNews(world, B, A);
      }
      c.phase = 4;
      c.nextAt = world.tick + 16;
      break;
    }
    default:
      finishConversation(world, c, 'success');
  }
}

// ── phase 1: the initiator says what they came for ──
function phaseAsk(world: World, c: Conversation, A: Person, B: Person, d: ConvData & { reqId?: number }): void {
  if(isChildTime(c.purpose)){bubble(world,A,childQuestion(c.purpose),'say',70);return;}
  const vars = { n: B.name } as Record<string, string | number>;
  switch (c.purpose) {
    case 'return_care': {
      const text=proposeCareReturn(world,A,B,d.requestId??0,c.id);c.data.careReturnHeard=!!text;c.data.careReturnText=text??'No current childcare return could be proposed.';
      if(text)bubble(world,A,text,'say',75);break;
    }
    case 'handover_work': {
      const text=proposeHandover(world,A,B,d.planId??0,c.id,d.handoverMode??'offer',d.handoverId??0);c.data.handoverDelivered=!!text;c.data.handoverText=text??'No current handover proposal could be conveyed.';
      if(text)bubble(world,A,text,'say',80);break;
    }
    case 'share_work': {
      const text=hearUndertaking(world,A,B,d.planId??0,c.id);c.data.workDelivered=!!text;c.data.workText=text??'No active household undertaking could be conveyed.';
      if(text)bubble(world,A,text,'say',70);break;
    }
    case 'cancel_meeting': {
      const text=receiveMeetingCancellation(world,A,B,d.mealId??0,c.id);c.data.meetingDelivered=!!text;c.data.meetingText=text??'No matching cancellation could be conveyed';
      if(text)bubble(world,A,text,'say',70);break;
    }
    case 'delay_request': {
      const text=receiveDelayProposal(world,A,B,d.requestId??0,c.id);c.data.delayDelivered=!!text;c.data.delayText=text??'No active failed attempt could be explained.';
      if(text)bubble(world,A,text,'say',70);break;
    }
    case 'cancel_request': {
      const heard=receiveCancellation(world,A,B,d.requestId??0,c.id);c.data.cancelDelivered=!!heard;c.data.cancelText=heard?.text??'No matching cancellation could be conveyed.';
      if(heard){
        if(heard.stopped){const held=B.suspended;
          const stillPromised=B.commitments.some(other=>other.status==='active'&&other.id!==heard.commitmentId&&(other.destId===heard.targetId||other.siteId===heard.targetId));
          const matching=held&&(held.data.commitmentId!==undefined?held.data.commitmentId===heard.commitmentId:held.targetId===heard.targetId&&['repair','build','haul','fuel_fire'].includes(held.kind)&&!stillPromised);
          if(held&&matching){releaseClaims(world,held.claims);B.suspended=null;addLog(world,B,'work','Stopped the suspended work after hearing its cancellation.');if(hasSuspendedEndings(world))endSuspended(world,B,held,'interrupted',`${A.name} cancelled the request it was for`);}
          const r=world.requests.find(r=>r.id===d.requestId&&r.from===A.id&&r.to===B.id);if(r?.status==='promised')settle(world,r,'cancelled',`${A.name} cancelled the request in person.`);
        }
        bubble(world,A,heard.text,'say',70);
      }
      break;
    }
    case 'report': {
      const text=receiveCompletionReport(world,A,B,d.requestId??0,c.id)??receiveOutcomeReport(world,A,B,d.requestId??0,c.id);c.data.reportDelivered=!!text;c.data.reportText=text??'No personally retained completion could be reported.';
      if(text)bubble(world,A,text,'say',70);break;
    }
    case 'learn_skill':
      A.cooldowns.coachAsk=world.tick+DAY/4;bubble(world,A,`Could you help me practise ${c.data.skill}?`,'ask',64);break;
    case 'learn_technique':
      A.cooldowns['learn:'+B.id]=world.tick+2*DAY;
      addLog(world,A,'social',`Asked ${B.name} to teach me ${TECHNIQUES[lessonKind(c)].name} for work I want to do.`);
      bubble(world,A,`I need to ${TECHNIQUES[lessonKind(c)].doing}. Could you teach me?`,'ask',64);break;
    case 'teach_technique':
      offerLesson(world,A,B,lessonKind(c));bubble(world,A,`Would you like to learn ${TECHNIQUES[lessonKind(c)].name}?`,'ask',64);break;
    case 'chat': {
      if (hashUnit(A.id, B.id, world.tick >> 5) < 0.4) {
        const atFire = world.buildings.some((b) => b.type === 'fire' && b.fuel > 0 && hyp(b.x + 0.5 - A.x, b.y + 0.5 - A.y) < 5);
        const hard = A.needs.hunger < 45 || B.needs.hunger < 45;
        bubble(world, A, D.smallTalk(world, A.id, B.id, atFire, A.needs.warmth < 45, hard), 'say', 50);
      }
      break;
    }
    case 'request': {
      const kind = d.reqKind ?? 'food';
      const req = createRequest(world, A, B, { kind, item: d.item ?? null, amount: d.amount ?? 1, siteId: d.siteId ?? 0, purpose: d.purpose, destKind: d.destKind, destId: d.destId, deadline: d.deadline, milestone: d.milestone, toolKind: d.toolKind ?? null, planId: d.planId, likely: d.likely });
      d.reqId = req.id;
      c.requestId = req.id;
      if (kind === 'wood' || kind === 'stone' || kind === 'goods') A.cooldowns.askMaterials = world.tick + 900;
      // asked about material for a plan of their own: whatever the answer, they do not raise that material again for a while
      if (d.planId && d.item) A.cooldowns['askPlan:' + d.item] = world.tick + 900;
      const building = d.siteId ? String((world.byId.get(d.siteId) as { type?: string } | undefined)?.type ?? 'building').replace('_', '-') : 'building';
      if (kind === 'tool') bubble(world, A, `Could I borrow your ${d.toolKind ?? 'tool'}? I’ll bring it back.`, 'ask', 62);
      else if (kind === 'goods' || kind === 'haul') bubble(world, A, `Could you bring ${d.item ?? 'some materials'} to the ${building}?`, 'ask', 62);
      else if (kind === 'repair') bubble(world, A, 'Would you be able to patch our roof? It’s not keeping the rain out.', 'ask', 64);
      else bubble(world, A, D.requestLine(A.hhId === B.hhId && A.needs.hunger < 50 && stageOf(world, A) === 'child' ? 'care' : kind, A.id, B.id, { building, child: d.destKind === 'person' && d.destId ? (personOf(world, d.destId)?.name ?? 'the little one') : 'the little one' }), 'ask', 60);
      addLog(world, A, 'social', `Asked ${B.name} for ${kind === 'food' ? 'food' : kind === 'tool' ? `the loan of a ${d.toolKind}` : (d.item ?? kind)}.`);
      break;
    }
    case 'ask_info': {
      // rules 105 (location_question.ts): a question about a person carries whom it is about
      const aboutPerson = hasLocationQuestions(world) && d.infoKind === 'person' && !!d.destId;
      const req = createRequest(world, A, B, { kind: 'info', infoKind: aboutPerson ? 'person' : d.infoKind ?? 'food', ...(aboutPerson ? { destKind: 'person' as const, destId: d.destId } : {}) });
      d.reqId = req.id;
      c.requestId = req.id;
      if (aboutPerson) { bubble(world, A, `Have you seen ${personOf(world, d.destId!)?.name ?? 'the person I promised'}? I promised them something.`, 'ask', 56); break; }
      const thing = d.infoKind === 'wood' ? 'good trees' : d.infoKind === 'stone' ? 'stone' : d.infoKind === 'water' ? 'fresh water' : 'food';
      bubble(world, A, D.requestLine('info', A.id, B.id, { thing }), 'ask', 56);
      break;
    }
    case 'warn': {
      let danger: Belief | null = null;
      for (const k in A.beliefs) {
        const b = A.beliefs[k as unknown as number];
        if (b.kind === 'danger' && b.amount > 0 && world.tick - b.seen < 900 && (!danger || b.seen > danger.seen)) danger = b;
      }
      if (danger) {
        bubble(world, A, D.saying(D.WARN_LINES, A.id, B.id, world.tick >> 5, { dir: D.dangerWords(world, danger) }), 'warn', 66);
        c.data.warnId = danger.id;
      } else c.data.warnNothing = true; // nothing fresh enough to pass on: recorded so the speaker is told the truth
      break;
    }
    case 'offer': {
      const items = d.items ?? {};
      const what = Object.keys(items)[0] ?? 'something';
      bubble(world, A, D.saying(stageOf(world, B) === 'child' ? D.CARE_LINES : D.OFFER_LINES, A.id, B.id, world.tick >> 5, { n: B.name, what }), 'say', 60);
      break;
    }
    case 'recruit': {
      const site = world.byId.get(d.siteId ?? 0);
      const building = site && site.ent === 'site' ? site.type.replace('_', '-') : 'building';
      const project=projectAt(world,d.siteId??0);
      if(project)nominate(world,A,B,project);
      const req = createRequest(world, A, B, { kind: 'help_build', siteId: d.siteId ?? 0, amount: 1 });
      d.reqId = req.id;
      c.requestId = req.id;
      bubble(world, A, project&&councilFor(world,project)?`Will you support me coordinating this ${building}?`:D.requestLine('help_build', A.id, B.id, { building }), 'ask', 60);
      break;
    }
    case 'apologize': {
      bubble(world, A, D.saying(D.APOLOGY, A.id, B.id, world.tick >> 5, vars), 'say', 58);
      break;
    }
    case 'mediate': {
      const other = d.pair ? personOf(world, d.pair) : null;
      bubble(world, A, other ? `Won't you make it up with ${other.name}? It has gone on long enough.` : 'Let it go, for all our sakes.', 'ask', 60);
      break;
    }
    case 'invite': {
      inviteAsk(world, A, B, d,c.id);
      break;
    }
    case 'propose': {
      bubble(world, A, D.saying(d.joinKind === 'partner' ? (A.hhId === B.hhId ? D.PROPOSE_PARTNER_HOME : D.PROPOSE_PARTNER) : D.PROPOSE_ROOMMATE, A.id, B.id, world.tick >> 5, vars), 'ask', 62);
      break;
    }
    case 'trade': {
      const req = createRequest(world, A, B, { kind: 'trade', item: d.item ?? null, amount: d.amount ?? 1, offer: d.offer ?? null, offerAmount: d.offerAmount ?? 1 });
      d.reqId = req.id;
      c.requestId = req.id;
      bubble(world, A, D.requestLine('trade', A.id, B.id, { offer: D.ITEM_PHRASE[d.offer ?? 'wood'], want: D.ITEM_PHRASE[d.item ?? 'berries'] }), 'ask', 62);
      break;
    }
  }
}

/** the procedure a lesson is about (charcoal unless the conversation says otherwise) */
const lessonKind = (c: Conversation): TechniqueKind => c.lesson?.kind ?? (c.data as ConvData).technique ?? 'charcoal';

function reqOf(world: World, c: Conversation): Request | undefined {
  return world.requests.find((r) => r.id === c.requestId);
}

// ── phase 2: the other person answers, and the answer has consequences ──
function phaseRespond(world: World, c: Conversation, A: Person, B: Person, d: ConvData): void {
  if(isChildTime(c.purpose)){bubble(world,B,beginChildTime(world,c,A,B),'say',70);return;}
  const req = reqOf(world, c);
  switch (c.purpose) {
    case 'return_care': {
      const text=c.data.careReturnHeard?answerCareReturn(world,A,B,d.requestId??0,c.id):null;c.data.careReturnAnswered=!!text;c.data.careReturnReply=text??'No childcare return answer was heard.';
      if(text)bubble(world,B,text,'say',75);break;
    }
    case 'handover_work': {
      const text=c.data.handoverDelivered?answerHandover(world,A,B,d.handoverMode==='offer'||!d.handoverMode?c.id:d.handoverId??0,d.handoverMode??'offer',c.id):null;c.data.handoverAnswered=!!text;c.data.handoverReply=text??'No handover answer was heard.';
      if(text)bubble(world,B,text,'say',80);break;
    }
    case 'share_work': {
      c.data.workAcknowledged=!!c.data.workDelivered&&acknowledgeUndertaking(world,A,B,d.planId??0,c.id);
      if(c.data.workAcknowledged)bubble(world,B,'I understand what you are working on. I have not promised to take it over.','say',60);break;
    }
    case 'cancel_meeting': {
      c.data.meetingAcknowledged=!!c.data.meetingDelivered&&acknowledgeMeetingCancellation(world,A,B,d.mealId??0);
      if(c.data.meetingAcknowledged)bubble(world,B,'I have heard you. Our old meal arrangement is cancelled.','say',60);break;
    }
    case 'delay_request': {
      const text=c.data.delayDelivered?answerDelayProposal(world,A,B,d.requestId??0):null;c.data.delayAnswered=!!text;c.data.delayReply=text??'The proposal received no answer.';
      if(text)bubble(world,B,text,'say',70);break;
    }
    case 'cancel_request': {
      const response=c.data.cancelDelivered?acknowledgeCancellation(world,A,B,d.requestId??0):null;c.data.cancelAcknowledged=!!response;
      if(response){let text=response==='stopped'?'I have heard you. I will stop that request.':'That obligation had already ended.';
        if(response==='already ended'){const detail=receiveCompletionReport(world,B,A,d.requestId??0,c.id)??receiveOutcomeReport(world,B,A,d.requestId??0,c.id);if(detail)text+=' '+detail;}
        c.data.cancelReply=text;bubble(world,B,text,'say',70);
      }
      break;
    }
    case 'report': {
      c.data.reportAcknowledged=!!c.data.reportDelivered&&(acknowledgeCompletionReport(world,A,B,d.requestId??0)||acknowledgeOutcomeReport(world,A,B,d.requestId??0));
      if(c.data.reportAcknowledged)bubble(world,B,'I have heard your report. Thank you for telling me.','say',65);break;
    }
    case 'learn_skill': {const why=beginCoaching(world,c,A,B);bubble(world,B,why?`Not now: ${why}.`:'Yes. Let us work through the technique together.','say',72);break;}
    case 'learn_technique': {
      const why=answerRequestedLesson(world,c,B,A);
      bubble(world,B,why?`Not now: ${why}.`:`Yes, I can teach you ${TECHNIQUES[lessonKind(c)].name}.`,'say',72);
      if(!why){if(A.activity)A.activity.label=`Learning ${TECHNIQUES[lessonKind(c)].name}`;if(B.activity)B.activity.label=`Teaching ${TECHNIQUES[lessonKind(c)].name}`;}
      break;
    }
    case 'teach_technique': {
      const why=answerLesson(world,c,A,B);
      bubble(world,B,why?`Not now: ${why}.`:`Yes, show me how to ${TECHNIQUES[lessonKind(c)].doing}.`,'say',72);
      if(!why){if(A.activity)A.activity.label=`Teaching ${TECHNIQUES[lessonKind(c)].name}`;if(B.activity)B.activity.label=`Learning ${TECHNIQUES[lessonKind(c)].name}`;}
      break;
    }
    case 'chat': {
      if (hashUnit(B.id, A.id, world.tick >> 5) < 0.3) bubble(world, B, D.smallTalk(world, B.id, A.id, false, B.needs.warmth < 45, false), 'say', 46);
      break;
    }
    case 'request': {
      if (!req) break;
      // The answer is the moment material moves or an obligation is taken on, so the ask is checked HERE and not only by the
      // periodic sweep (updateRequests): what the asker needs may have changed since they spoke, or the ask may have been
      // withdrawn or already answered. A project ask is first brought up to date against the asker's own plan and pack, and then
      // anything that is no longer pending gets no answer at all - no gift, no promise, no thanks, no change of standing.
      // Rich only: an authored world answers exactly as it always did (its golden fingerprints are the contract).
      if (isRich(world)) {
        // The order matters. An ask that has already been answered, withdrawn or expired is turned away FIRST, and its record is
        // left exactly as it was found: a second pass over the same exchange must not rewrite what the first one concluded. Only a
        // still-open ask is brought up to date against the asker's own plan and pack, and the status is then looked at again.
        const turnAway = (why: string): void => {
          c.data.moot = why;
          bubble(world, A, 'Never mind — I’ve seen to it since.', 'say', 50);
        };
        if (req.status !== 'pending') {
          turnAway(req.status === 'cancelled' ? 'it was not needed after all' : `the asking had already ended (${req.status})`);
          break;
        }
        if (req.planId) keepOwnAskHonest(world, req);
        if (req.status !== 'pending') {
          turnAway('it was not needed after all');
          break;
        }
      }
      hearDemand(world,B,A,req);
      const resp = evaluateRequest(world, B, A, req);
      // rules 51 (customers.ts): asked in person and unable to supply, B remembers A as a customer for it
      if (resp.kind === 'decline') noteCustomer(world, B, A, req, resp.reason);
      if (resp.kind === 'give') {
        const moved = transfer(world, B.inv, A.inv, carryCap(world, A), resp.item, resp.n, 'person:' + B.id, 'person:' + A.id, 'gift on request');
        if (moved > 0) {
          const items: Items = { [resp.item]: moved };
          req.delivered = (req.delivered ?? 0) + moved; // handed over here and now: this is a delivery, not a promise
          noteHelperReceipt(world,req,B,A,resp.item,moved,'conversation',c.id);
          // In a rich world the three quantities are kept apart: asked for, agreed to, actually handed over - and an ask that was
          // only partly answered is recorded as that, leaving nobody owing the difference. An authored world keeps the record it
          // always kept (the golden fingerprints are its contract), which is the one place this slice does not sharpen.
          if (isRich(world)) {
            req.offered = resp.n;
            const full = (req.delivered ?? 0) >= req.amount;
            settle(world, req, full ? 'fulfilled' : 'partial', full ? `received ${moved} ${resp.item}` : `asked for ${req.amount}, given ${resp.n}, received ${req.delivered} ${resp.item}`);
          } else settle(world, req, 'fulfilled', `received ${moved} ${resp.item}`);
          bubble(world, B, D.saying(D.RESP_GIVE, B.id, A.id, world.tick >> 5, { what: `${moved} ${resp.item}` }), 'say', 56);
          onGift(world, B, A, items, 'request');
          // the thank-you comes next phase
          c.data.thank = true;
        } else {
          settle(world, req, 'failed', 'could not carry it');
          bubble(world, B, 'You can’t carry any more.', 'say', 50);
        }
      } else if (resp.kind === 'lend') {
        const t = resp.tool;
        const due = world.tick + LOAN_TERM;
        if (lendTool(world, t, B, A, due)) {
          settle(world, req, 'fulfilled', `lent a ${t.kind} until tomorrow`);
          req.outcome = 'lent';
          const c = addCommitment(world, A, req, { kind: 'return_tool', to: B.id, item: t.kind, amount: 1, toolId: t.id, deadline: due + 400, destKind: 'person', destId: B.id });
          void c;
          bubble(world, B, `Of course. Bring it back when you’re done.`, 'say', 58);
          adjustRel(A, B.id, world.tick, { aff: 3, trust: 2.5, fam: 0.5, note: `${B.name} lent me their ${t.kind}` });
          adjustRel(B, A.id, world.tick, { aff: 0.8, trust: 1, note: `I lent ${A.name} my ${t.kind}` });
          addLog(world, B, 'social', `Lent my ${t.kind} to ${A.name}.`);
          addLog(world, A, 'social', `${B.name} lent me a ${t.kind}; I promised to return it.`);
          addEvent(world, 'social', `${B.name} lent a ${t.kind} to ${A.name}.`, [A.id, B.id], A.x, A.y);
        } else {
          settle(world, req, 'failed', 'could not hand it over');
        }
      } else if (resp.kind === 'promise') {
        const item = resp.item;
        // what is wanted at a building site is brought to the site (not to the person asking, whose pack may be full)
        const toSite = !!req.siteId && !!item && !isFood(item) && item !== 'water';
        if (req.kind === 'repair') {
          addCommitment(world, B, req, { kind: 'work', item: null, amount: 1, siteId: 0, deadline: world.tick + PROMISE_TTL + 900, destKind: 'building', destId: req.destId, milestone: req.milestone || 'sound again' });
          if(req.destId)communicateRoofLocation(world,A,B,req.destId);
        } else if (req.kind === 'watch' || req.kind === 'fire') {
          addCommitment(world, B, req, { kind: 'work', item: null, amount: 1, siteId: 0, deadline: world.tick + DAY, destKind: req.destKind, destId: req.destId, milestone: req.kind === 'watch' ? 'watched' : 'fire kept' });
          if (req.kind === 'watch' && req.destId) communicateWatchLocation(world, A, B, req.destId);
          if (req.kind === 'fire' && req.destId) communicateFireLocation(world,A,B,req.destId);
        } else {
          const kindC: Commitment['kind'] = req.kind === 'haul' || req.kind === 'goods' || toSite ? 'haul' : 'deliver';
          // rules 48 (delivery_place.ts): a promise to a person names the asker's home as the place to leave it, when the helper
          // knows that home; the hand-over in person stays the other way of keeping it
          const place = kindC === 'deliver' ? agreedPlace(world, B, A) : null;
          addCommitment(world, B, req, { kind: kindC, item, amount: resp.n, siteId: req.siteId, deadline: world.tick + (kindC === 'haul' ? PROMISE_TTL + 600 : PROMISE_TTL), destKind: kindC === 'haul' ? 'site' : place ? 'building' : 'person', destId: kindC === 'haul' ? req.siteId : place ? place.id : A.id });
          if (place) c.data.place = place.id;
        }
        req.status = 'promised';
        if (isRich(world)) req.offered = resp.n; // they agreed to this much; the rest of the ask stays the asker's own problem
        const where = c.data.place ? ` (or leave it at ${A.name}’s ${homeNoun((B.beliefs[c.data.place as number]?.btype ?? 'hut') as BuildingType)})` : '';
        req.note = (isRich(world) && resp.n < req.amount ? `${B.name} will bring ${resp.n} of the ${req.amount} ${item}` : `${B.name} will bring ${resp.n} ${item}`) + where;
        if (req.kind === 'repair') {
          if(hasRepairDuty(world))req.note=`${B.name} will patch the roof with available materials; no wood has been delivered.`;
          bubble(world, B, 'I’ll see to the roof.', 'say', 60);
          addLog(world, B, 'social', `Promised ${A.name} to mend their roof.`);
          addLog(world, A, 'social', `${B.name} promised to mend our roof.`);
          addEvent(world, 'social', `${B.name} promised to mend ${A.name}’s roof.`, [A.id, B.id], A.x, A.y);
        } else if (req.kind === 'watch' || req.kind === 'fire') {
          const what = req.kind === 'watch' ? `keep an eye on ${personOf(world, req.destId ?? 0)?.name ?? 'the children'}` : 'keep the fire going';
          req.note = `${B.name} will ${what}`;
          bubble(world, B, req.kind === 'watch' ? 'Of course. Rest; I’ll keep an eye on them.' : 'Leave the fire to me.', 'say', 60);
          addLog(world, B, 'social', `Promised ${A.name} to ${what}.`);
          addLog(world, A, 'social', `${B.name} promised to ${what} while I am laid up.`);
          addEvent(world, 'social', `${B.name} promised to ${what} for ${A.name}, who is laid up.`, [A.id, B.id], A.x, A.y);
        } else {
          bubble(world, B, D.saying(D.RESP_PROMISE_ITEM, B.id, A.id, world.tick >> 5, { what: item ?? 'it' }), 'say', 64);
          addLog(world, B, 'social', `Promised ${A.name} ${resp.n} ${item}.`);
          addLog(world, A, 'social', `${B.name} promised to bring me ${resp.n} ${item}.`);
          addEvent(world, 'social', `${B.name} promised ${A.name} ${item}.`, [A.id, B.id], A.x, A.y);
        }
        const agreed=B.commitments.find(x=>x.id===req.commitmentId);if(agreed)rememberExpectation(world,A,B,req,agreed,c.id);
        adjustRel(A, B.id, world.tick, { aff: 1.5, trust: 1 });
      } else {
        const lines = resp.reason === 'no_item' ? D.RESP_NO_ITEM : resp.reason === 'own_need' || resp.reason === 'in_use' ? D.RESP_OWN_NEED : resp.reason === 'disliked' ? D.RESP_DISLIKED : D.RESP_UNWILLING;
        if (resp.reason === 'no_place') bubble(world, B, req.kind === 'repair' ? 'I do not know which home I could reach from that old account.' : 'I do not know which fire I could reach from that old account.', 'say', 54);
        else if (resp.reason === 'enough') bubble(world, B, 'I think that’s been seen to already.', 'say', 54);
        else if (resp.reason === 'committed') bubble(world, B, hasSingleRoofDuty(world) && req.kind === 'repair' ? 'I have already promised to see to that roof.' : 'I’ve already promised that to them.', 'say', 54);
        else if (resp.reason === 'in_use') bubble(world, B, 'I’m using it just now — ask me later?', 'say', 54);
        else if (resp.reason === 'making') bubble(world, B, 'I have some, but it is for something I am making.', 'say', 56);
        else bubble(world, B, D.saying(lines, B.id, A.id, world.tick >> 5), 'say', 56);
        settle(world, req, 'declined', resp.reason.replace('_', ' '));
        if (req.kind === 'watch' || req.kind === 'fire') onDutyDeclined(world, A, B, req.kind);
        const sev = req.kind === 'food' ? clamp((62 - A.needs.hunger) / 62, 0, 1) : req.kind === 'water' ? clamp((66 - A.needs.thirst) / 66, 0, 1) : 0.3;
        if (resp.reason === 'unwilling' || resp.reason === 'disliked') {
          // a refusal is not a broken promise: it costs a little warmth, in proportion to how much was at stake
          adjustRel(A, B.id, world.tick, { aff: -(1.5 + 4.5 * sev), trust: -1.5 - 2 * sev, note: `${B.name} refused to help me` });
          adjustRel(B, A.id, world.tick, { aff: -0.3 });
          if (sev > 0.45) openGrievance(world, A, B, 'refusal', `${B.name} would not help when I really needed it`, 20 + 30 * sev);
          // only a refusal that matters (someone really needs it) makes the feed
          if (sev > 0.45 && (req.kind === 'food' || req.kind === 'water' || req.kind === 'care')) {
            addEvent(world, 'conflict', `${B.name} refused ${A.name}'s plea for ${req.kind === 'water' ? 'water' : 'food'}.`, [A.id, B.id], A.x, A.y);
          }
          c.data.sour = true;
        } else if (resp.reason === 'own_need') {
          adjustRel(A, B.id, world.tick, { aff: -0.3 });
        } else {
          // Being told "I have some, but it is for something I am making" is an answer, and the asker keeps it: it is what stops
          // them asking this neighbour for the same kind of favour again while the thing is still being made (options_social.ts).
          if (resp.reason === 'making') A.cooldowns[MAKING_NOTE + B.id] = world.tick + MAKING_MEMORY;
          // 'enough', 'committed', 'in_use', 'no_item', 'making': nobody did anything wrong
          A.asked[B.id] = world.tick - 400;
        }
        addLog(world, A, 'social', `${B.name} said no (${resp.reason.replace('_', ' ')}).`);
        addLog(world, B, 'social', `Turned down ${A.name}'s request (${resp.reason.replace('_', ' ')}).`);
        bubbleLater(world, A, D.saying(D.SHRUG, A.id, B.id, world.tick >> 5), 12);
      }
      break;
    }
    case 'ask_info': {
      if (!req) break;
      if (hasLocationQuestions(world) && d.infoKind === 'person' && d.destId) {
        // rules 105: the answer is B's own sight or dated note, kept by A only if newer than A's own, with the teller recorded
        const name = personOf(world, d.destId)?.name ?? 'them';
        const said = tellWhereabouts(world, B, A, d.destId);
        if (said) {
          bubble(world, B, `I saw ${name} near there at tick ${said.tick}; they may have moved since.`, 'say', 70);
          settle(world, req, 'fulfilled', `told where they last saw ${name}`);
          adjustRel(A, B.id, world.tick, { aff: 1.6, trust: 1.2, note: `${B.name} told me where they last saw ${name}` });
          c.data.thank = true;
        } else {
          bubble(world, B, `Sorry, I haven’t seen ${name}.`, 'say', 54);
          settle(world, req, 'failed', 'they did not know either');
          adjustRel(A, B.id, world.tick, { aff: 0.2 });
        }
        break;
      }
      const belief = answerInfo(world, B, A, d.infoKind ?? 'food');
      if (belief) {
        // One logical offer with two writes underneath: `tellBelief` may refuse on its own freshness rule and the direct `learn`
        // below writes anyway on a looser one. The diagnostics see the pair as one offer and classify what was actually written.
        observeOffer(world, 'ask_info', B, A, belief, () => {
          const told = tellBelief(world, B, A, belief);
          learn(A, { ...belief, src: 'told', from: B.id, learned: world.tick, origin: belief.origin ?? B.id, hops: (belief.hops ?? 0) + 1 });
          return told;
        });
        bubble(world, B, D.infoLine(world, belief, B.id, A.id), 'say', 70);
        settle(world, req, 'fulfilled', `told about a ${BELIEF_NOUN[belief.kind]}`);
        adjustRel(A, B.id, world.tick, { aff: 1.6, trust: 1.2, note: `${B.name} told me where to find ${d.infoKind ?? 'food'}` });
        A.errand = null;
        c.data.thank = true;
      } else {
        bubble(world, B, 'Sorry, I haven’t seen any.', 'say', 54);
        settle(world, req, 'failed', 'they did not know either');
        adjustRel(A, B.id, world.tick, { aff: 0.2 });
      }
      break;
    }
    case 'warn': {
      const id = c.data.warnId as number | undefined;
      if (id) {
        const b = A.beliefs[id];
        if (b) {
          // tellBelief's verdict is the evidence of delivery: true when B did not know, false when B knew as much already
          c.data.warnDelivered = observeOffer(world, 'warn', A, B, b, () => tellBelief(world, A, B, b));
          bubble(world, B, 'Thanks for the warning.', 'say', 50);
          adjustRel(B, A.id, world.tick, { aff: 1.8, trust: 2.2, note: `${A.name} warned me about a wolf` });
          if ((world.stats.lastWarnEvent ?? -9999) < world.tick - 900) {
            world.stats.lastWarnEvent = world.tick;
            addEvent(world, 'danger', `${A.name} warned ${B.name} about a wolf.`, [A.id, B.id], A.x, A.y);
          }
        }
      }
      break;
    }
    case 'offer': {
      const items = d.items ?? {};
      let moved = 0;
      const got: Items = {};
      for (const k of Object.keys(items) as ItemKind[]) {
        const m = transfer(world, A.inv, B.inv, carryCap(world, B), k, items[k] ?? 0, 'person:' + A.id, 'person:' + B.id, 'offered gift');
        if (m > 0) got[k] = m;
        moved += m;
      }
      if(hasLivedLife(world)){
        const asked=Object.values(items).reduce((n:number,v)=>n+Number(v),0);
        const detail=moved>0?`Received ${itemsToText(got)}${moved<asked?'; the rest could not be handed over':''}`:'No goods changed hands: the offered goods were unavailable or there was no room to receive them';
        c.data.giftReceipt={outcome:moved>0?'received gift':'nothing received',detail};
        addLog(world,A,'social',`${B.name}: ${detail}.`);addLog(world,B,'social',`${A.name} offered goods: ${detail}.`);
      }
      if (moved > 0) {
        onGift(world, A, B, got, isDependent(world, B) ? 'care' : 'offer');
        bubble(world, B, D.saying(D.THANKS, B.id, A.id, world.tick >> 5, { n: A.name }), 'happy', 52);
        if (d.customer) customerSupplied(world, A, B, got, d.customer, null);
      }
      break;
    }
    case 'recruit': {
      if (!req) break;
      const siteBelief = A.beliefs[d.siteId ?? 0];
      if (projectAt(world, d.siteId ?? 0) && !canInvite(world, A, B, d.siteId ?? 0)) {
        settle(world, req, 'declined', 'not eligible for this township project'); break;
      }
      const project=projectAt(world,d.siteId??0);
      const oppose=project?oppositionReason(world,B,A,project):'';
      if(oppose){settle(world,req,'declined',oppose);bubble(world,B,'I still support the other organiser.','say',64);break;}
      const rel = B.relations[A.id];
      const site0 = world.byId.get(d.siteId ?? 0);
      const cap = (site0 && site0.ent === 'site' ? site0.maxWorkers : 3) + 1;
      const council=project&&councilFor(world,project);
      if ((!council && helpersOn(world, d.siteId ?? 0) >= cap) || activeCommitments(B).filter(c=>!council||c.siteId!==project!.siteId).length >= MAX_ACTIVE_COMMITMENTS) {
        bubble(world, B, 'There are hands enough there already.', 'say', 52);
        settle(world, req, 'declined', 'enough hands already');
        A.asked[B.id] = world.tick - 400;
        break;
      }
      const w = (projectAt(world, d.siteId ?? 0) ? organiserExperience(B, A.id, world) : 0) + 0.2 + 0.45 * B.traits.diligence + 0.3 * B.traits.generosity + 0.4 * Math.max(0, (rel?.affinity ?? 0)) / 100 + (hashUnit(B.id, A.id, world.tick >> 5) - 0.5) * 0.15 - 0.5 * (personalDriveMax(world, B) / 100) + (rel?.kin ? 0.2 : 0);
      if (w >= 0.55 && siteBelief && (projectAt(world, d.siteId ?? 0) || world.byId.has(d.siteId ?? 0))) {
        observeOffer(world, 'recruit', A, B, siteBelief, () => tellBelief(world, A, B, siteBelief));
        if(project && councilFor(world,project))releaseOldSupport(world,B,project.siteId,'accepted another coordinator for this project');
        addCommitment(world, B, req, { kind: 'help_build', siteId: d.siteId ?? 0, amount: 1, deadline: world.tick + 1800, destKind: 'site', destId: d.siteId ?? 0, milestone: 'work on it or bring materials' });
        req.status = 'promised';
        req.note = council ? `${B.name} supports ${A.name} coordinating and will help build` : `${B.name} will help build`;
        if(project&&receivedCivicBenefit(world,B,A.id))req.note+='; remembers benefiting from their earlier shared storehouse';
        bubble(world, B, council?`I support you coordinating it, ${A.name}.`:D.saying(D.RESP_PROMISE_HELP, B.id, A.id, world.tick >> 5), 'say', 64);
        if(hasPromiseTargets(world)){const agreed=B.commitments.find(x=>x.id===req.commitmentId);if(agreed)rememberExpectation(world,A,B,req,agreed,c.id);}
        addLog(world, B, 'social', `Agreed to help ${A.name} with the building.`);
        addEvent(world, 'social', `${B.name} agreed to help ${A.name} build.`, [A.id, B.id], A.x, A.y);
      } else {
        bubble(world, B, D.saying(D.RESP_UNWILLING, B.id, A.id, world.tick >> 5), 'say', 52);
        settle(world, req, 'declined', projectAt(world, d.siteId ?? 0) ? (personalDriveMax(world, B) > 35 ? 'own needs take priority' : (rel?.affinity ?? 0) < 0 ? 'does not want to work with this organiser' : 'not willing to commit to this proposal') : 'busy');
      }
      break;
    }
    case 'apologize': {
      const gA = A.relations[B.id]?.grievance;
      const gB = B.relations[A.id]?.grievance;
      const rel = B.relations[A.id];
      const weight = Math.max(gA?.weight ?? 0, gB?.weight ?? 0);
      if (!gA && !gB) {
        // nothing to make peace over any more: the quarrel was already settled
        bubble(world, B, 'We’re fine — don’t worry about it.', 'say', 50);
        break;
      }
      const sev = clamp(weight / 70, 0, 1);
      const p = clamp(0.4 + 0.5 * B.traits.generosity - 0.32 * sev + (rel ? rel.trust / 300 : 0) + 0.12 * (gA ? gA.apologies : 0), 0.1, 0.95);
      if (gA) gA.apologies++;
      if (hashUnit(B.id, A.id, world.tick >> 4) < p) {
        bubble(world, B, D.saying(D.FORGIVE, B.id, A.id, world.tick >> 5), 'happy', 56);
        adjustRel(B, A.id, world.tick, { aff: 9, trust: 4, note: `${A.name} apologised` });
        adjustRel(A, B.id, world.tick, { aff: 4, note: `${B.name} forgave me` });
        settleBoth(world, A, B, 'an apology');
        addEvent(world, 'social', `${A.name} and ${B.name} made peace.`, [A.id, B.id], A.x, A.y);
      } else {
        bubble(world, B, D.saying(D.NOT_YET, B.id, A.id, world.tick >> 5), 'angry', 52);
        // it eases a little just for having been said; the next attempt waits
        easeGrievance(world, B, A, 6, 'an apology that was not yet accepted');
        A.cooldowns['sorry' + B.id] = world.tick + 900 * (gA && gA.apologies >= 2 ? 2 : 1);
        c.data.sour = true;
      }
      break;
    }
    case 'invite': {
      if (d.mealId) inviteRespond(world, A, B, d.mealId);
      break;
    }
    case 'mediate': {
      const other = d.pair ? personOf(world, d.pair) : null;
      if (!other) break;
      const out = mediate(world, A, B, other);
      if (out === 'peace') bubble(world, B, 'You’re right. I’ll let it lie.', 'happy', 56);
      else if (out === 'eased') bubble(world, B, 'Maybe. I’ll think on it.', 'say', 54);
      else if (out === 'worse') {
        bubble(world, B, 'Stay out of it.', 'angry', 54);
        c.data.sour = true;
      } else bubble(world, B, 'Not yet.', 'say', 50);
      break;
    }
    case 'propose': {
      const rel = B.relations[A.id];
      const aff = rel?.affinity ?? 0;
      const trust = rel?.trust ?? 0;
      const kind = d.joinKind ?? 'roommate';
      const ok = kind === 'partner' ? aff >= 28 && trust >= 20 && B.partnerId === 0 && A.partnerId === 0 && spark(A, B) : aff >= 32 && trust >= 22;
      if (ok && hashUnit(B.id, A.id, world.tick >> 6) < 0.8 + 0.2 * B.traits.sociability) {
        if (joinHouseholds(world, A, B, kind)) {
          bubble(world, B, D.saying(D.ACCEPT_PROPOSE, B.id, A.id, world.tick >> 5), 'happy', 56);
        } else {
          bubble(world, B, D.saying(D.NO_ROOM, B.id, A.id, world.tick >> 5), 'say', 56);
          A.cooldowns['propose' + B.id] = world.tick + 1500;
        }
      } else {
        bubble(world, B, D.saying(D.DECLINE_PROPOSE, B.id, A.id, world.tick >> 5), 'say', 52);
        A.cooldowns['propose' + B.id] = world.tick + 2400;
      }
      break;
    }
    case 'trade': {
      if (!req || !req.item || !req.offer) break;
      const give = req.item;
      const take = req.offer;
      const bHas = surplusOf(world, B, give);
      const gain = valueOf(world, B, take) * req.offerAmount - valueOf(world, B, give) * req.amount;
      const rel = B.relations[A.id];
      // both packs must be able to take what they are about to be handed, or the swap does not happen at all
      const roomA = roomFor(A.inv, carryCap(world, A), give) + 0;
      const roomB = roomFor(B.inv, carryCap(world, B), take);
      const fits = roomA >= req.amount && roomB >= req.offerAmount;
      if (!fits && bHas >= req.amount && (A.inv[take] ?? 0) >= req.offerAmount) {
        bubble(world, B, 'I couldn’t carry that on top of what I have.', 'say', 50);
        settle(world, req, 'declined', 'no room to carry the swap');
        A.asked[B.id] = world.tick + 1200; // a swap that cannot be carried is not proposed to them again for the best part of a day
        break;
      }
      if (bHas >= req.amount && gain > 0.15 + (rel && rel.affinity < 0 ? 0.6 : 0) && (A.inv[take] ?? 0) >= req.offerAmount) {
        const m1 = transfer(world, B.inv, A.inv, carryCap(world, A), give, req.amount, 'person:' + B.id, 'person:' + A.id, 'trade');
        const m2 = m1 > 0 ? transfer(world, A.inv, B.inv, carryCap(world, B), take, req.offerAmount, 'person:' + A.id, 'person:' + B.id, 'trade') : 0;
        if (m1 > 0 && m2 > 0) {
          settle(world, req, 'fulfilled', `swapped ${m2} ${take} for ${m1} ${give}`);
          endExchangeTalk(world,A,d.exchangeJourney,req,req.note);
          if (d.customer) customerSupplied(world, A, B, { [take]: m2 }, d.customer, { item: give, n: m1 });
          bubble(world, B, D.saying(D.TRADE_OK, B.id, A.id, world.tick >> 5), 'say', 46);
          adjustRel(A, B.id, world.tick, { aff: 1.8, trust: 1.5, fam: 0.5 });
          adjustRel(B, A.id, world.tick, { aff: 1.8, trust: 1.5, fam: 0.5 });
          addEvent(world, 'trade', `${A.name} swapped ${m2} ${take} for ${m1} ${give} with ${B.name}.`, [A.id, B.id], A.x, A.y);
          addLog(world, A, 'social', `Traded ${m2} ${take} for ${m1} ${give} with ${B.name}.`);
          addLog(world, B, 'social', `Traded ${m1} ${give} for ${m2} ${take} with ${A.name}.`);
          // undo half-done swaps if the second leg failed to move everything
        } else {
          if (m1 > 0) transfer(world, A.inv, B.inv, 9999, give, m1, 'person:' + A.id, 'person:' + B.id, 'trade rollback');
          settle(world, req, 'failed', 'could not carry the swap');
        }
      } else {
        bubble(world, B, D.saying(D.TRADE_NO, B.id, A.id, world.tick >> 5), 'say', 50);
        settle(world, req, 'declined', bHas < req.amount ? 'nothing to spare' : 'not worth it');
        A.asked[B.id] = world.tick + 1200; // told no: not asked again for a long while
      }
      break;
    }
  }
}

function bubbleLater(world: World, p: Person, text: string, after: number): void {
  world.delayed.push({ tick: world.tick + after, id: p.id, text });
}

export function flushDelayedBubbles(world: World): void {
  const delayed = world.delayed;
  for (let i = delayed.length - 1; i >= 0; i--) {
    const d = delayed[i];
    if (world.tick >= d.tick) {
      const p = personOf(world, d.id);
      if (p) bubble(world, p, d.text, 'say', 44);
      delayed.splice(i, 1);
    }
  }
}

// ── phase 3: news travels by word of mouth ──
function phaseNews(world: World, S: Person, L: Person): void {
  if(hasExchangeJourneys(world)){
    const goods:Items={};
    for(const k of ['wood','stone','berries','fruit','fish','grain','dried_fish','smoked_fish','dried_meat','smoked_meat','rendered_fat'] as ItemKind[]){const n=surplusOf(world,S,k);if(n>0)goods[k]=n;}
    tellTradeLead(world,S,L,goods);
  }
  shareConcerns(world, S, L);
  // one story about a third person, when there is one worth telling (rich only; never in an authored world)
  shareRumour(world, S, L);
  const news = pickNews(world, S, L, 2);
  let shown = false;
  let learned = 0;
  for (const b of news) {
    const isNew = observeOffer(world, 'news', S, L, b, () => tellBelief(world, S, L, b));
    if (isNew) {
      learned++;
      if (!shown && !S.speech) {
        shown = true;
        if (b.kind === 'danger') bubble(world, S, D.saying(D.WARN_LINES, S.id, L.id, world.tick >> 5, { dir: D.dangerWords(world, b) }), 'warn', 62);
        else bubble(world, S, D.infoLine(world, b, S.id, L.id), 'say', 66);
      }
    }
  }
  if (learned > 0) adjustRel(L, S.id, world.tick, { aff: 0.5 * learned, trust: 0.3 * learned });
}

// ───────────────────────── households ─────────────────────────
function joinHouseholds(world: World, A: Person, B: Person, kind: 'partner' | 'roommate'): boolean {
  const hhA = householdById(world, A.hhId);
  const hhB = householdById(world, B.hhId);
  if (!hhA || !hhB) return false;
  if (hhA === hhB) {
    if (kind === 'partner') {
      bindPartners(world, A, B);
      return true;
    }
    return false;
  }
  const home = (h: typeof hhA) => (h.homeId ? (world.byId.get(h.homeId) as { type?: string } | undefined)?.type : undefined);
  const score = (h: typeof hhA) => (home(h) === 'house' ? 4 : home(h) === 'hut' ? 3 : home(h) === 'lean_to' ? 2 : 0) + membersOf(world, h).length * 0.1;
  // the better-housed side hosts, unless there is no room there — then the other side may
  const order = score(hhA) >= score(hhB) ? [hhA, hhB] : [hhB, hhA];
  for (const dest of order) {
    const src = dest === hhA ? hhB : hhA;
    const mover = dest === hhA ? B : A;
    const destHome = dest.homeId ? (world.byId.get(dest.homeId) as { type: keyof typeof BUILD_DEF } | undefined) : undefined;
    const cap = destHome ? BUILD_DEF[destHome.type].sleepers : 99;
    const incoming = [mover, ...membersOf(world, src).filter((m) => m.id !== mover.id && m.parents.includes(mover.id) && stageOf(world, m) === 'child')];
    if (membersOf(world, dest).length + incoming.length > cap) continue;
    for (const m of incoming) addToHousehold(world, m, dest);
    onMovedHousehold(world, mover, src, dest);
    if (kind === 'partner') bindPartners(world, A, B);
    const label = kind === 'partner' ? 'moved in together' : 'now share a home';
    addEvent(world, 'social', `${A.name} and ${B.name} ${label} (${dest.name} household).`, [A.id, B.id], A.x, A.y);
    addLog(world, A, 'life', `${A.name} and ${B.name} ${label}.`);
    addLog(world, B, 'life', `${A.name} and ${B.name} ${label}.`);
    return true;
  }
  return false;
}

function bindPartners(world: World, A: Person, B: Person): void {
  A.partnerId = B.id;
  B.partnerId = A.id;
  noteWedding(world, A, B);
  noteDeedNear(world, A, 'news', `${A.name} and ${B.name} are now partners`, A.x, A.y, 12, [B.id]);
  const ra = relOf(A, B.id);
  const rb = relOf(B, A.id);
  ra.kin = 'partner';
  rb.kin = 'partner';
  ra.affinity = Math.max(ra.affinity, 68);
  rb.affinity = Math.max(rb.affinity, 68);
  ra.trust = Math.max(ra.trust, 55);
  rb.trust = Math.max(rb.trust, 55);
  addEvent(world, 'life', `${A.name} and ${B.name} became a couple.`, [A.id, B.id], A.x, A.y);
}

// ───────────────────────── conflict ─────────────────────────
/** Someone reached the last of a resource just before another person. */
export function contestLost(world: World, loser: Person, winnerId: number, src: { item: ItemKind; x: number; y: number }): void {
  const w = personOf(world, winnerId);
  if (!w) return;
  const d = hyp(loser.x - w.x, loser.y - w.y);
  if (d > 7) return;
  const desperate = loser.needs.hunger < 35 || loser.needs.thirst < 35;
  const rel = loser.relations[w.id];
  const sameHh = loser.hhId === w.hhId;
  adjustRel(loser, w.id, world.tick, { aff: -(0.8 + (desperate ? 2.2 : 0.4)), note: `${w.name} got the last ${src.item} before me` });
  addLog(world, loser, 'social', `${w.name} got to the last ${src.item} before me.`);
  // worth a line in the feed now and then (not for every missed berry)
  const isFood = src.item === 'berries' || src.item === 'fruit' || src.item === 'fish' || src.item === 'grain';
  if (isFood && loser.needs.hunger < 55 && world.tick - (loser.cooldowns.contestEvt ?? -9999) > 1200 && world.tick - (world.stats.lastContestEvt ?? -9999) > 450) {
    loser.cooldowns.contestEvt = world.tick;
    world.stats.lastContestEvt = world.tick;
    const one = src.item === 'berries' ? 'berry' : src.item;
    addEvent(world, 'conflict', `${w.name} reached the last ${one} a moment before ${loser.name}.`, [loser.id, w.id], loser.x, loser.y);
  }
  const p = clamp(0.08 + 0.4 * (1 - loser.traits.generosity) + (desperate ? 0.25 : 0) - 0.3 * Math.max(0, (rel?.affinity ?? 0)) / 100 - (sameHh ? 0.3 : 0), 0, 0.8);
  openGrievance(world, loser, w, desperate && isFood ? 'scarcity' : 'competition', `${w.name} got the last ${src.item} before me`, desperate ? 26 : 14);
  if (loser.cooldowns.argue > world.tick || loser.convId || w.convId) return;
  if (hashUnit(loser.id, w.id, world.tick >> 3) < p * quarrelDamper(world, loser, w)) startArgument(world, loser, w, `the last ${src.item}`, desperate && isFood ? 'scarcity' : 'competition');
}

export function startArgument(world: World, a: Person, b: Person, why: string, cause: import('./types').GrievanceCause = 'competition'): void {
  if (a.convId || b.convId) return;
  suspendActivity(world, a);
  suspendActivity(world, b);
  const mk = (me: Person, other: Person, first: boolean) => {
    const act = newActivity(world, me, { kind: 'argue', label: `Arguing with ${other.name}`, goal: 'a heated moment', here: true, maxTicks: 90, minCommit: 80, data: { other: other.id, first } });
    startActivity(world, me, act);
  };
  mk(a, b, true);
  mk(b, a, false);
  a.cooldowns.argue = world.tick + 700;
  b.cooldowns.argue = world.tick + 700;
  bubble(world, a, D.saying(D.ARGUE_A, a.id, b.id, world.tick >> 4), 'angry', 54);
  bubbleLater(world, b, D.saying(D.ARGUE_B, b.id, a.id, world.tick >> 4), 14);
  adjustRel(a, b.id, world.tick, { aff: -5, trust: -3, note: `argued over ${why}` });
  adjustRel(b, a.id, world.tick, { aff: -4, trust: -2, note: `argued over ${why}` });
  relOf(a, b.id).avoidUntil = world.tick + 700 + Math.floor(hashUnit(a.id, b.id, 4) * 500);
  relOf(b, a.id).avoidUntil = world.tick + 600 + Math.floor(hashUnit(b.id, a.id, 4) * 500);
  openGrievance(world, a, b, cause, `we argued over ${why}`, 46);
  openGrievance(world, b, a, cause, `we argued over ${why}`, 40);
  addEvent(world, 'conflict', `${a.name} and ${b.name} argued over ${why}.`, [a.id, b.id], a.x, a.y);
  addLog(world, a, 'social', `Argued with ${b.name} over ${why}.`);
  addLog(world, b, 'social', `Argued with ${a.name} over ${why}.`);
  addFx(world, 'anger', (a.x + b.x) / 2, (a.y + b.y) / 2, 0);
  think(world, a, 'argued:' + b.id, -12, DAY, `argued with ${b.name}`);
  think(world, b, 'argued:' + a.id, -12, DAY, `argued with ${a.name}`);
  witness(world, 'quarrel', a, b, a.x, a.y);
}

// ───────────────────────── working side by side ─────────────────────────
/** People who do the same job near each other (building together, working neighbouring plots) come to like each other. */
export function bondWorkers(world: World, p: Person): void {
  const a = p.activity;
  if (!a || a.phase !== 'work' || (world.tick + p.id) % 50 !== 0) return;
  if (!['build', 'haul', 'till', 'plant', 'tend', 'harvest', 'gather', 'repair', 'craft'].includes(a.kind)) return;
  for (const s of p.seen) {
    if (s.ent !== 'person' || s.act !== a.kind) continue;
    if (hyp(s.x - p.x, s.y - p.y) > 4.5) continue;
    const q = personOf(world, s.id);
    if (!q) continue;
    const rel = p.relations[q.id];
    if (rel && rel.avoidUntil > world.tick) continue;
    const fit = 1 - (Math.abs(p.traits.diligence - q.traits.diligence) + Math.abs(p.traits.sociability - q.traits.sociability)) / 2;
    if (fit < 0.45) continue;
    const sparked = !p.partnerId && !q.partnerId && stageOf(world, p) !== 'child' && stageOf(world, q) !== 'child' && !(rel && rel.kin) && spark(p, q);
    adjustRel(p, q.id, world.tick, { aff: 0.5 + 0.5 * fit + (sparked ? 0.7 : 0), fam: 0.5, trust: 0.4, note: `worked alongside ${q.name}` });
  }
}

// ───────────────────────── passing greetings ─────────────────────────
export function passingGreetings(world: World, p: Person): void {
  if (p.pose === 'sleep' || p.convId || p.wave > world.tick) return;
  if ((world.tick + p.id) % 14 !== 0) return;
  for (const s of p.seen) {
    if (s.ent !== 'person' || s.asleep || s.busyTalking) continue;
    if (hyp(s.x - p.x, s.y - p.y) > 2.8) continue;
    if ((p.cooldowns['greet' + s.id] ?? 0) > world.tick) continue;
    const q = personOf(world, s.id);
    if (!q) continue;
    const rel = p.relations[q.id];
    if (rel && rel.avoidUntil > world.tick) continue;
    const chance = 0.2 + 0.45 * p.traits.sociability + Math.min(0.25, (rel?.familiarity ?? 0) / 80);
    if (hashUnit(p.id, q.id, world.tick >> 4) > chance) continue;
    p.wave = world.tick + 28;
    noteContact(world, 'greeting', p.id, q.id, world.tick);
    p.cooldowns['greet' + q.id] = world.tick + GREET_COOLDOWN;
    adjustRel(p, q.id, world.tick, { aff: 0.3, fam: 0.5 });
    if (hashUnit(q.id, p.id, world.tick >> 4) < 0.75 && q.wave < world.tick) {
      q.wave = world.tick + 34;
      adjustRel(q, p.id, world.tick, { aff: 0.3, fam: 0.5 });
    }
    q.cooldowns['greet' + p.id] = world.tick + GREET_COOLDOWN;
    break;
  }
}

// ───────────────────────── activity handlers ─────────────────────────
registerHandler('socialize', {
  onEnd(w,p,a,outcome,detail){endExchangeApproach(w,p,a,detail||outcome);},
  availability: 0.6,
  pose: () => 'talk',
  begin(world, p, a) {
    const t = personOf(world, a.targetId);
    if (!t) return 'they are no longer around';
    if (hyp(t.x - p.x, t.y - p.y) > CONV_REACH + 2.5) return 'could not find them';
  },
  work(world, p, a): WorkResult {
    const t = personOf(world, a.targetId);
    if (!t) return 'fail:they are no longer around';
    if (hyp(t.x - p.x, t.y - p.y) > CONV_REACH + 1.2) return 'fail:they walked away';
    const purpose = (a.data.purpose ?? 'chat') as ConvPurpose;
    const ok = acceptsTalk(world, t, p, purpose);
    if (!ok.ok) {
      // someone who was simply busy can be tried again soon; someone who wants nothing to do with you cannot
      p.cooldowns['talk' + t.id] = world.tick + (ok.why === 'was too busy to stop' || ok.why === 'was busy' ? 120 : 420);
      addLog(world, p, 'social', `Wanted a word with ${t.name}, who ${ok.why}.`);
      return `fail:${t.name} ${ok.why}`;
    }
    openConversation(world, p, t, a, purpose, (a.data.conv ?? {}) as ConvData);
    return 'continue';
  },
});

registerHandler('converse', {
  availability: 0,
  pose: () => 'talk',
  work(world, p, a): WorkResult {
    const c = convOf(world, a.data.convId as number);
    if (!c || a.data.finished) return 'done';
    const other = personOf(world, c.a === p.id ? c.b : c.a);
    if (!other) return 'done';
    faceToward(p, other.x, other.y);
    return 'continue';
  },
  onEnd(world, p, a, outcome) {
    const c = convOf(world, a.data.convId as number);
    if (c && !a.data.finished) {
      // this person was pulled away mid-conversation (danger, urgent need…): the other is left mid-sentence
      finishConversation(world, c, 'interrupted');
    }
    p.convId = 0;
    if (!p.activity) resumeSuspended(world, p);
  },
});

registerHandler('argue', {
  availability: 0,
  pose: () => 'argue',
  begin(world, p, a) {
    a.duration = 34 + (a.data.first ? 4 : 0);
  },
  work(world, p, a): WorkResult {
    const o = personOf(world, a.data.other as number);
    if (o) faceToward(p, o.x, o.y);
    a.progress++;
    return a.progress >= a.duration ? 'done' : 'continue';
  },
  onEnd(world, p) {
    if (!p.activity) resumeSuspended(world, p);
  },
});

registerHandler('give', {
  availability: 0.4,
  pose: () => 'give',
  begin(world, p, a) {
    const textileProblem=textileGiftProblem(world,p,a);if(textileProblem)return textileProblem;
    const t = personOf(world, a.targetId);
    if (!t) {if(hasPromiseExpectations(world)&&a.data.commitmentId){delete p.whereabouts[a.targetId];return 'they were not where I expected';}return 'they are gone';}
    if (hyp(t.x - p.x, t.y - p.y) > 3.2) {
      // not where I expected: update what I know and give up for now
      delete p.whereabouts[t.id];
      return `${t.name} was not where I expected`;
    }
    if ((t.cooldowns.pause ?? 0) > world.tick) return `${t.name} is already being attended to`;
    if (!(runsRulesVersion(world,124)&&a.data.textileDelivery) && (t.cooldowns.fedUntil ?? 0) > world.tick) return `${t.name} has just been looked after`;
    a.duration = 14;
    // the other person stops for a moment to receive (one giver at a time)
    t.cooldowns.pause = world.tick + a.duration + 3;
    faceToward(p, t.x, t.y, 3);
    faceToward(t, p.x, p.y, 3);
  },
  work(world, p, a): WorkResult {
    const textileProblem=textileGiftProblem(world,p,a);if(textileProblem)return `fail:${textileProblem}`;
    const t = personOf(world, a.targetId);
    if (!t) return 'fail:they are gone';
    if (hasLocalGiving(world) && hyp(t.x - p.x, t.y - p.y) > 3.2) return 'fail:they moved out of reach before the hand-over';
    faceToward(p, t.x, t.y);
    faceToward(t, p.x, p.y, 0.5);
    a.progress++;
    if (a.progress < a.duration) return 'continue';
    const requested=(a.data.items ?? {}) as Items;
    const want = residentCareItems(world,p,t,a,requested) as Record<string,number>;
    if(isResidentCare(world,a)&&Object.keys(want).length===0){t.cooldowns.pause=0;return needsResidentCare(t,requested)?'fail:no spare supplies remain for this hand-over':'fail:they no longer need the supplies I brought';}
    const got: Items = {};
    let moved = 0;
    if ((a.data.mode as string) === 'return') {
      // a borrowed tool goes back into the lender's hands — that exact tool, not another of the same kind
      const tool = toolsHeldBy(world, p.id).find((x) => x.id === (a.data.toolId as number));
      if (!tool || !tool.loan) return 'fail:there is nothing to hand back';
      if ((t.inv[tool.kind] ?? 0) >= 1 && carryCap(world, t) < 99 && false) return 'fail:their hands are full';
      if (!returnLoan(world, tool, p, t)) return 'fail:could not hand it back';
      t.cooldowns.pause = 0;
      bubble(world, p, `Here’s your ${tool.kind} back — thank you.`, 'say', 56);
      bubbleLater(world, t, D.saying(D.THANKS, t.id, p.id, world.tick >> 5, { n: p.name }), 14);
      adjustRel(t, p.id, world.tick, { aff: 1.6, trust: 3.2, note: `${p.name} gave back my ${tool.kind}` });
      adjustRel(p, t.id, world.tick, { aff: 0.5, trust: 0.8 });
      addEvent(world, 'social', `${p.name} returned ${t.name}'s ${tool.kind}.`, [p.id, t.id], t.x, t.y);
      if (a.data.commitmentId) fulfillCommitment(world, p, a.data.commitmentId as number);
      a.cycle = 1;
      return 'done';
    }
    for (const k of Object.keys(want)) {
      const m = transfer(world, p.inv, t.inv, carryCap(world, t), k as ItemKind, Math.min(want[k], p.inv[k as ItemKind] ?? 0), 'person:' + p.id, 'person:' + t.id, 'given', runsRulesVersion(world,124)&&a.data.textileDelivery?a.data.deliveryTool:0);
      if (m > 0) got[k as ItemKind] = m;
      moved += m;
    }
    t.cooldowns.pause = 0;
    if ((!hasLocalGiving(world) || moved > 0)&&!(runsRulesVersion(world,124)&&a.data.textileDelivery)) t.cooldowns.fedUntil = world.tick + 120; // only actual food receipt gives them time to eat
    if (moved <= 0) {
      if (a.data.mode === 'care') noteCarePackFailure(world, p, t, want);
      if (a.data.commitmentId) {
        const cm = p.commitments.find((x) => x.id === (a.data.commitmentId as number));
        if (cm) {
          cm.blocked = `${t.name} had no room in their pack for it`;
          cm.blockedAt = world.tick;
        }
      }
      return 'fail:they had no room to carry it';
    }
    a.cycle = moved;
    // being handed food or water wakes a sleeper
    if (t.activity && t.activity.kind === 'sleep') endActivity(world, t, 'interrupted', runsRulesVersion(world,124)&&a.data.textileDelivery?'woken to receive a garment':'woken to be fed');
    const mode = (a.data.mode as string) ?? 'give';
    onGift(world, p, t, got, mode);
    bubble(world, p, mode==='care'&&runsRulesVersion(world,95)?`Here is ${itemsToText(got)}, ${t.name}.`:D.saying(mode === 'care' ? D.CARE_LINES : D.OFFER_LINES, p.id, t.id, world.tick >> 5, { n: t.name, what: Object.keys(got)[0] }), 'say', 56);
    bubbleLater(world, t, D.saying(D.THANKS, t.id, p.id, world.tick >> 5, { n: p.name }), 14);
    if (mode === 'promise' && a.data.commitmentId) {
      const cm = p.commitments.find((x) => x.id === (a.data.commitmentId as number));
      if (cm && cm.item) cm.delivered = (cm.delivered ?? 0) + (got[cm.item] ?? 0);
      // the request the promise answers records the same arrival, so "how much came" has one source whichever way it came
      const rq = cm ? world.requests.find((x) => x.id === cm.requestId) : undefined;
      if (rq && cm && cm.item) rq.delivered = (rq.delivered ?? 0) + (got[cm.item] ?? 0);
      if(rq&&cm?.item)noteHelperReceipt(world,rq,p,t,cm.item,got[cm.item]??0,'activity',a.id);
      if (cm && (cm.delivered ?? 0) >= cm.amount) fulfillCommitment(world, p, cm.id);
    }
    return 'done';
  },
  onEnd(world,p,a,outcome,detail){
    if(runsRulesVersion(world,124)&&a.data.textileDelivery&&outcome==='failed')noteFailure(world,p,a.targetId,detail);
  },
});

void estimatedAmount;
void NUTRITION;
void noteFailure;
void drive;

// rules 51 (customers.ts) reads the barter valuation, the spare-goods rule and the request settlement from here, bound at load
setCustomerDeps({ surplusOf, valueOf, settle });
