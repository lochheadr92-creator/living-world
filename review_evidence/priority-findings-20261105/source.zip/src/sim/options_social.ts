import {hasCoaching} from './skill_coaching';
import {CHILD_TIMES,wantsChildTime,childTimeName,childTimeTicks} from './childhood';
import {companyReason} from './companionship';
import {hasLivedLife} from './lived_life';
import {pendingMeetingUpdates} from './meeting_knowledge';
import { peopleToAskAfter } from './location_question';
import {workToTell} from './continuity_knowledge';
import {handoverOffer,handoverFollowup} from './work_handover';
import {pendingDelayProposals} from './promise_delays';
import {pendingCancellations} from './request_cancellation';
import {careReturns} from './care_handback';
import {expectsCare} from './promise_expectations';
import { exchangeJourneyOptions } from './exchange_journeys';
import {helperExperience,materialRequestKind,watchExperience} from './helper_learning';
import {accountsExperience} from './checked_accounts';
import {pendingPromiseReports} from './promise_outcomes';
import { askTrustBonus } from './delivery_place';
import { supplyOptions } from './customers';
import { heldTechniques, hasLearnerInstruction, TECHNIQUES, TECHNIQUE_KINDS, techniqueApplies, knowsTechnique, learnBlocker } from './techniques';
import { mayCoordinate, councilFor } from './civic_decision';
import { canInvite, projectAt, participation } from './townships';
import { isRich } from './mood';
import { newActivity } from './activities';
import { reputationOf } from './reputation';
import { favourOwedBy } from './misdeeds';
import { aloneOptions } from './temperament';
import { companyPull } from './lifechanges';
import { crewMates } from './crews';
import { quarrelsFor } from './mediation';
import { childrenNeedingWatch, laidUp } from './responsibilities';
import { BUILD_DEF, PRESERVED_FOODS } from './constants';
import { invRoom, pickFood } from './economy';
import { Scorer, addBlocked, addOption, beliefsByKind, countBeliefsOfKind, eta, pen, sourceUsable, traitMods } from './optutil';
import type { Ctx, Option } from './optutil';
import { fractionAvailable, hhState } from './options_work';
import { isDependent, stageOf } from './people';
import { MAKING_NOTE, MAX_ACTIVE_COMMITMENTS, activeCommitments, helpersOn, outstandingFor, surplusOf, valueOf, isFood } from './social';
import { outstandingForPlan, projectAsksOn } from './intent';
import { attendOptions } from './occasions';
import { wantsAmends } from './grievance';
import { mealOptions } from './meals';
import { welfareOptions, seekCarerOptions } from './welfare';
import { toolsHeldBy } from './toolreg';
import type { ConvData } from './social';
import { hashUnit } from './rng';
import { spark, trustOf } from './relations';
import { runsRulesVersion } from './rulesversion';
import type { ActivityKind, Belief, ConvPurpose, ItemKind, Items, Person, SeenEntity, World } from './types';
import { clamp, hyp } from './util';

interface Cand {
  s: SeenEntity;
  q: Person;
  aff: number;
  fam: number;
  d: number;
}

// Lab-only removal of the recipient choice. No relationship reward or utility bonus:
// existing personal trust chooses among helpers the ordinary eligibility checks allow.
let projectHelperChoice = true;
export const projectHelperChoiceOn = (): boolean => projectHelperChoice;
export function setProjectHelperChoice(on: boolean): void { projectHelperChoice = on; }
const hasProjectHelperChoice = (w: World): boolean => projectHelperChoice && isRich(w) && runsRulesVersion(w, 39);

function candidates(ctx: Ctx, includeAvoided = false): Cand[] {
  const { world, p } = ctx;
  const out: Cand[] = [];
  for (const s of ctx.seenPersons) {
    if (s.asleep || s.busyTalking) continue;
    if (s.act === 'flee' || s.act === 'argue' || s.act === 'converse') continue;
    const e = world.byId.get(s.id);
    if (!e || e.ent !== 'person' || !e.alive) continue;
    const rel = p.relations[s.id];
    if (!includeAvoided && rel && rel.avoidUntil > world.tick) continue;
    // the cautious keep their distance from someone plainly feverish, unless they are close (rich only: nobody is ill otherwise)
    if (e.illness && e.illness.severity >= 0.5 && p.traits.caution > 0.55 && (rel?.affinity ?? 0) < 40 && !rel?.kin) continue;
    if ((p.cooldowns['talk' + s.id] ?? 0) > world.tick) continue;
    out.push({ s, q: e, aff: rel?.affinity ?? 0, fam: rel?.familiarity ?? 0, d: hyp(s.x - p.x, s.y - p.y) });
  }
  return out;
}

function mkSocial(ctx: Ctx, c: Cand, purpose: ConvPurpose, conv: ConvData, label: string, goal: string, need: Option['need'], sc: Scorer, tag: string, keySuffix = '', selectionReason = ''): void {
  const { world, p } = ctx;
  const q = c.q;
  const e = (c.d * 1.18) / Math.max(0.03, ctx.speed);
  addOption(ctx, {
    kind: 'socialize',
    label,
    goal,
    need,
    util: sc.total,
    parts: sc.parts,
    eta: e + 70,
    key: `socialize:${q.id}:${purpose}${keySuffix}`,
    targetId: q.id,
    tag,
    ...(selectionReason ? { selectionReason } : {}),
    make: () => {
      const dx = p.x - c.s.x;
      const dy = p.y - c.s.y;
      const d = hyp(dx, dy) || 1;
      const sx = c.s.x + (dx / d) * 1.35;
      const sy = c.s.y + (dy / d) * 1.35;
      return newActivity(world, p, {
        kind: 'socialize',
        label,
        goal,
        need,
        targetId: q.id,
        targetType: 'person',
        tx: c.s.x,
        ty: c.s.y,
        spotX: sx,
        spotY: sy,
        utility: sc.total,
        minCommit: 40,
        maxTicks: 420,
        data: { purpose, conv },
      });
    },
  });
}

// ───────────────────────── chat ─────────────────────────
function optChat(ctx: Ctx): void {
  const { p } = ctx;
  if (ctx.stage === 'child' && ctx.dependents.length === 0 && false) return;
  const tm = traitMods(p);
  const sd = ctx.drives.social;
  const cands = candidates(ctx).filter((c) => (c.s.hungry || c.s.thirsty ? false : true) || c.aff > 20);
  const scored: { c: Cand; sc: Scorer }[] = [];
  for (const c of cands) {
    if (c.d > 13) continue;
    const sc = new Scorer();
    sc.add('wants company', sd * tm.social * 0.85);
    const continuing=companyReason(ctx.world,p,c.q.id);
    if(continuing&&!ctx.critical&&!ctx.dangers.length)sc.add('make time for continuing company',continuing);
    // a relaxed chat when nothing presses, mostly in the evening around the fire
    if (sd <= 0 && ctx.night) sc.add('evening company', 3.4 * (p.traits.sociability - 0.15));
    sc.add(c.aff >= 20 ? 'a friend' : c.fam < 4 ? 'someone new' : 'a neighbour', sd > 0 ? c.aff * 0.12 + (c.fam < 4 ? 3 * p.traits.curiosity : 0) : 0);
    // two unattached adults who are drawn to each other seek out one another's company
    if (!p.partnerId && !c.q.partnerId && ctx.stage !== 'child' && ctx.stage !== 'youth' && stageOf(ctx.world, c.q) !== 'child' && stageOf(ctx.world, c.q) !== 'youth' && !p.relations[c.q.id]?.kin && spark(p, c.q) && c.aff > -5) {
      sc.add('drawn to each other', (ctx.night ? 9 : 4.5) + Math.max(0, c.aff) * 0.05);
    }
    sc.add('close by', sd > 0 ? Math.max(0, 6 - c.d) * 0.6 : 0);
    const rep = reputationOf(ctx.world, p, c.q.id);
    if (rep) sc.add(rep > 0 ? 'has a good name' : 'has a bad name', 3 * rep);
    const pull = companyPull(ctx.world, p, c.q);
    if (pull) sc.add('someone to lean on', pull);
    if (crewMates(ctx.world, p, c.q)) sc.add('one of my crew', 3);
    sc.add('walking', -pen((c.d * 1.18) / Math.max(0.03, ctx.speed)));
    if (sc.total > 6) scored.push({ c, sc });
  }
  scored.sort((a, b) => b.sc.total - a.sc.total);
  for (const { c, sc } of scored.slice(0, 2)) {
    mkSocial(ctx, c, 'chat', {}, `Chat with ${c.q.name}`, 'to catch up and share news', 'social', sc, 'social');
  }
}

// What somebody is visibly doing, as it bears on whether they would hand over what they are carrying (Stage D1's ask).
// `IDLE_ACTS` is "not in the middle of anything"; `OWN_WORK_ACTS` is "working with what is in their hands".
const IDLE_ACTS: (ActivityKind | '')[] = ['', 'wander', 'rest', 'warm', 'visit', 'explore'];
const OWN_WORK_ACTS: (ActivityKind | '')[] = ['build', 'repair', 'craft', 'plan_site', 'tool_work', 'operate'];

// ───────────────────────── asking for help ─────────────────────────
function optRequest(ctx: Ctx): void {
  const { world, p } = ctx;
  const cands = candidates(ctx);
  if (!cands.length) return;
  const bestSelf = (need: 'hunger' | 'thirst'): number => {
    let best = 0;
    // only options that actually put food or water in hand count as solving it alone (searching does not)
    for (const o of ctx.options) if (o.need === need && o.util > best && (o.tag === 'food' || o.tag === 'water')) best = o.util;
    return best;
  };
  const tryNeed = (need: 'hunger' | 'thirst', reqKind: 'food' | 'water', itemCheck: (s: SeenEntity) => boolean, label: string) => {
    const dr = ctx.drives[need];
    if (dr < 26) return;
    const self = bestSelf(need);
    // only ask when there is no good way to solve it alone
    if (self > dr * 0.62) return;
    for (const c of cands) {
      if (c.d > 14) continue;
      if ((p.asked[c.q.id] ?? -9999) > world.tick - 650) {
        addBlocked(ctx, 'socialize', `Ask ${c.q.name} for ${label}`, c.q.id, 'asked them recently', 'request');
        continue;
      }
      let plaus = 0.18;
      if (itemCheck(c.s)) plaus = 1;
      else if (c.q.hhId === p.hhId) plaus = 0.7;
      else if (c.aff >= 25) plaus = 0.5;
      else if (dr >= 70) plaus = 0.32;
      if (plaus < 0.3) continue;
      const owed = favourOwedBy(world, p, c.q);
      // an ask worth making (rich only): weighed by how likely the answer is yes, from trust, their name and what they owe;
      // one that would likely be refused is not made, and the inspector says so
      if (isRich(world)) {
        const trust = p.relations[c.q.id]?.trust ?? 10;
        const likely = plaus * (0.55 + 0.45 * Math.max(0, Math.min(1, (trust + 20) / 80))) + 0.15 * reputationOf(world, p, c.q.id) + 0.1 * Math.min(2, owed);
        if (likely < 0.3 && dr < 70) {
          addBlocked(ctx, 'socialize', `Ask ${c.q.name} for ${label}`, c.q.id, 'not worth asking: they would likely say no', 'request');
          continue;
        }
      }
      const sc = new Scorer();
      sc.add(need === 'hunger' ? 'hungry' : 'thirsty', dr * 0.72 * plaus);
      sc.add(itemCheck(c.s) ? 'they are carrying some' : c.q.hhId === p.hhId ? 'family' : c.aff >= 25 ? 'a friend' : 'worth a try', plaus * 4);
      if (owed > 0) sc.add('they owe me a favour', 3 * Math.min(2, owed));
      // rules 48 (delivery_place.ts): a neighbour who kept a promise is asked first, one who broke one last
      const tb = askTrustBonus(world, p.relations[c.q.id]?.trust ?? 10);
      if (tb > 0) sc.add('they came through before', tb);
      else if (tb < 0) sc.add('they let me down before', tb);
      sc.add('walking', -pen((c.d * 1.18) / Math.max(0.03, ctx.speed)) * 0.6);
      const kind = stageOf(world, p) === 'child' ? 'care' : reqKind;
      mkSocial(ctx, c, 'request', { reqKind: kind as ConvData['reqKind'], item: reqKind === 'water' ? 'water' : null, amount: 2 }, `Ask ${c.q.name} for ${label}`, `to get ${label}`, need, sc, 'request', ':' + reqKind);
    }
  };
  tryNeed('hunger', 'food', (s) => s.carrying.some((k) => isFood(k)), 'food');
  tryNeed('thirst', 'water', (s) => s.carrying.includes('water'), 'water');

  // laid up (rich only): a neighbour to keep an eye on the children, or the fire going (responsibilities.ts)
  if (laidUp(world, p) && !expectsCare(world,p)) {
    const kids = childrenNeedingWatch(world, p);
    const fire = kids.length ? null : beliefsByKind(p, ['building']).find((b) => b.btype === 'fire' && hyp(b.x - p.x, b.y - p.y) < 12 && (b.fuel ?? 0) - (world.tick - b.seen) * 0.85 < 400 && (p.inv.wood ?? 0) < 1);
    if (kids.length || fire) {
      for (const c of cands) {
        if (c.d > 14 || c.s.child || c.q.hhId === p.hhId || stageOf(world, c.q) === 'child' || stageOf(world, c.q) === 'youth') continue;
        if ((p.cooldowns['askduty' + c.q.id] ?? 0) > world.tick || c.aff < -10) continue;
        const sc = new Scorer()
          .add(kids.length ? `laid up, and ${kids[0].name} needs seeing to` : 'laid up, and the fire is getting low', 18 + 8 * (p.illness?.severity ?? 0.5))
          .add(c.aff >= 25 ? 'a friend' : c.fam >= 4 ? 'a neighbour' : 'worth a try', c.aff >= 25 ? 5 : 2)
          .add('walking', -pen((c.d * 1.18) / Math.max(0.03, ctx.speed)) * 0.6);
        const experience=kids.length?watchExperience(world,p,c.q.id):{bonus:0,reason:''};if(experience.bonus)sc.add(experience.reason,experience.bonus);
        if (!ctx.observer) p.cooldowns['askduty' + c.q.id] = world.tick + 400; // (the wait starts when they consider it; the inspector asking must not start it)
        if (kids.length) mkSocial(ctx, c, 'request', { reqKind: 'watch', destKind: 'person', destId: kids[0].id, purpose: `keep an eye on ${kids[0].name}` }, `Ask ${c.q.name} to keep an eye on ${kids[0].name}`, `to have ${kids[0].name} seen to while I am laid up`, null, sc, 'request', ':watch', experience.reason);
        else mkSocial(ctx, c, 'request', { reqKind: 'fire', destKind: 'building', destId: fire!.id, purpose: 'keep the fire going' }, `Ask ${c.q.name} to keep the fire going`, 'to have the fire kept while I am laid up', null, sc, 'request', ':fire');
      }
    }
  }

  // a home that is failing, with nobody in the household able to mend it: ask a neighbour who can
  const homeB = ctx.home ? p.beliefs[ctx.home.id] : undefined;
  const nobodyAble = ctx.members.every((m) => stageOf(world, m) === 'child' || stageOf(world, m) === 'elder');
  if (homeB && nobodyAble && (homeB.cond ?? 100) < 55 && (p.inv.wood ?? 0) < 1 && (p.inv.planks ?? 0) < 1 && (p.cooldowns.askRepair ?? 0) <= world.tick && ctx.stage !== 'child') {
    for (const c of cands) {
      if (c.d > 12 || c.s.child) continue;
      const q = c.q;
      if (stageOf(world, q) === 'child') continue;
      if ((p.asked[q.id] ?? -9999) > world.tick - 900) continue;
      const rel = p.relations[q.id];
      if (!rel?.kin && c.aff < 5) continue;
      const sc = new Scorer().add('the roof is failing and there is no one here who can mend it', 22).add('walking', -pen(c.d * 6));
      mkSocial(ctx, c, 'request', { reqKind: 'repair', item: 'wood', amount: 1, destKind: 'building', destId: homeB.id, purpose: 'the roof is failing', milestone: 'sound again' } as ConvData, `Ask ${q.name} to mend the roof`, 'to keep a roof over our heads', null, sc, 'request', ':repair');
      if (!ctx.observer) p.cooldowns.askRepair = world.tick + 600; // (as above)
      break;
    }
  }

  // a tool that stands between me and the work I have in mind: ask to borrow one from someone seen carrying it
  const tw = ctx.toolWanted;
  if (tw && (p.cooldowns['askTool' + tw.kind] ?? 0) <= world.tick && activeCommitments(p).length < MAX_ACTIVE_COMMITMENTS) {
    for (const c of cands) {
      if (c.d > 12 || !c.s.carrying.includes(tw.kind)) continue;
      if ((p.asked[c.q.id] ?? -9999) > world.tick - 650) continue;
      const trust = p.relations[c.q.id]?.trust ?? 10;
      if (trust < 12 && c.aff < 10) continue;
      const sc = new Scorer().add(`need a ${tw.kind} to ${tw.for}`, 20 * traitMods(p).work).add('they are carrying one', 4).add('walking', -pen(c.d * 6));
      mkSocial(ctx, c, 'request', { reqKind: 'tool', toolKind: tw.kind, item: tw.kind, amount: 1, purpose: tw.for }, `Ask ${c.q.name} to lend a ${tw.kind}`, `to ${tw.for}`, null, sc, 'request', ':tool:' + tw.kind);
      if (!ctx.observer) p.cooldowns['askTool' + tw.kind] = world.tick + 300; // (as above)
    }
  }

  // Material a project of my own still lacks (Stage D1). Everything here is the asker's own: their plan says what it wants, their
  // pack says what they have, and the only people asked are ones they can see carrying the thing. Nothing is counted as arrived:
  // what has already been asked for or promised for this same plan is subtracted, so one shortage is not asked for twice.
  // In an authored world `p.intentions` is empty, so this loop does nothing at all. The lab's `rich-no-ask` branch switches the
  // ask off on its own (intent.ts setProjectAsks) and leaves the plan, and every other kind of request, as they were.
  //
  // Measured first: 143 asks a village brought 37 units, and most answers were no, because nearly everyone asked had the thing
  // and had it spoken for. So an ask is now made only when, BY THE ASKER'S OWN LIGHTS, it should be answered yes - see `spare`,
  // `idle`, `atOwnWork` and `saidMaking` below - and fetching it themselves is weighed against asking rather than ruling the ask
  // out before it has been considered at all.
  for (const plan of projectAsksOn() ? p.intentions : []) {
    if (plan.status !== 'active' || plan.kind !== 'tool') continue;
    if (ctx.criticals.length || ctx.dangers.length) break; // something is actually wrong: not the moment to be asking favours
    for (const item of Object.keys(plan.wants) as ItemKind[]) {
      const short = (plan.wants[item] ?? 0) - (p.inv[item] ?? 0);
      if (short <= 0) continue;
      // having actually asked about this material, they let it rest a while (set where the asking really happens, social.ts)
      if ((p.cooldowns['askPlan:' + item] ?? 0) > world.tick) continue;
      // What is already asked for or promised for this same plan is coverage, not material: it is subtracted from what is asked
      // for next, so two helpers are never asked for the same unit, and never counted as if it had arrived.
      const uncovered = short - outstandingForPlan(world, p.id, item, plan.id);
      if (uncovered <= 0) continue;
      if (activeCommitments(p).length >= MAX_ACTIVE_COMMITMENTS) continue;
      // A yes they could not carry is not a yes: somebody with a full pack waits until there is room in it before asking
      if (invRoom(world, p, item) < 1) {
        addBlocked(ctx, 'socialize', `Ask someone for ${item}`, 0, 'no room in my pack for it', 'request');
        continue;
      }
      // Fetching it themselves is the ordinary way, and it used to rule the ask out before it was ever considered. Now both are
      // on the table and the ask carries the cost of the alternative: a quick trip of their own beats asking a favour, a long one
      // may not.
      const quick = ctx.options.some((o) => o.yields === item && o.eta < 260);
      // Stable ties preserve sight order. This reads only the asker's relationship and personal receipts;
      // no remote helper inventory, plans, willingness or world event is consulted.
      const experience=new Map(cands.map(c=>[c.q.id,helperExperience(world,p,c.q.id,materialRequestKind(item),item)]));
      const helpers = hasProjectHelperChoice(world)
        ? cands.slice().sort((a, b) => trustOf(p, b.q.id)+experience.get(b.q.id)!.bonus-trustOf(p, a.q.id)-experience.get(a.q.id)!.bonus) : cands;
      for (const c of helpers) {
        if (c.d > 12 || !c.s.carrying.includes(item)) continue;
        if (c.s.child || stageOf(world, c.q) === 'child') continue;
        if ((p.asked[c.q.id] ?? -9999) > world.tick - 650) continue;
        // Would this person say yes? Everything weighed here is the asker's own sight and the asker's own memory:
        //  * an armful rather than their last one (`plenty`), or somebody not in the middle of anything, is likely to spare it;
        //  * somebody visibly making or building something is working with what they are carrying;
        //  * somebody who has lately told THEM that what they carry is for something they are making has already answered this.
        const spare = (c.s.plenty ?? []).includes(item);
        const idle = IDLE_ACTS.includes(c.s.act);
        const atOwnWork = OWN_WORK_ACTS.includes(c.s.act);
        const saidMaking = (p.cooldowns[MAKING_NOTE + c.q.id] ?? 0) > world.tick;
        if (!(spare || idle) || atOwnWork || saidMaking) {
          const why = saidMaking ? `they said their ${item} is for something they are making` : atOwnWork ? 'they are working with what they carry' : `they have only the one ${item} and are busy with it`;
          addBlocked(ctx, 'socialize', `Ask ${c.q.name} for ${item}`, c.q.id, why, 'request');
          continue;
        }
        const sc = new Scorer()
          .add(`${plan.goal} and the ${item} is short`, 20 * traitMods(p).work)
          .add(spare ? `they are carrying more than one ${item}` : 'they have some and are not busy', 4);
        if (quick) sc.add(`I could fetch ${item} myself soon`, -8);
        sc.add('walking', -pen(c.d * 6));
        mkSocial(
          ctx,
          c,
          'request',
          { reqKind: item === 'wood' || item === 'stone' ? item : 'goods', item, amount: Math.max(1, Math.min(uncovered, 3)), purpose: plan.goal, destKind: 'person', destId: p.id, planId: plan.id, likely: true },
          `Ask ${c.q.name} for ${item}`,
          plan.goal,
          null,
          sc,
          'request',
          ':plan:' + item,
          hasProjectHelperChoice(world) ? [trustOf(p, c.q.id) !== 10
            ? (trustOf(p, c.q.id) > 10 ? `I trust ${c.q.name}; they may still need it themselves` : `I am wary of ${c.q.name}, but can still ask`) : '',experience.get(c.q.id)!.reason].filter(Boolean).join('; ') : '',
        );
        break; // one person at a time about one thing
      }
    }
  }

  // building materials for a site I am working on (only worth asking when I cannot easily fetch them myself)
  if ((p.cooldowns.askMaterials ?? 0) > world.tick) return;
  if (activeCommitments(p).length >= MAX_ACTIVE_COMMITMENTS + 2) return;
  for (const b of beliefsByKind(p, ['site'])) {
    if (b.hh !== p.hhId) continue;
    for (const item of Object.keys(b.need ?? {}) as ItemKind[]) {
      const miss = b.need?.[item] ?? 0;
      if (miss <= 0 || (p.inv[item] ?? 0) >= miss) continue;
      // what other people have already promised to bring is not asked for again
      const already = outstandingFor(world, p.id, item, b.id);
      if (already >= miss - (p.inv[item] ?? 0)) continue;
      const selfFetch = ctx.options.some((o) => (o.kind === 'gather' || o.kind === 'operate' || o.kind === 'withdraw') && o.tag === 'site' && o.eta < 260);
      if (selfFetch) continue;
      for (const c of cands) {
        if (c.d > 12 || !c.s.carrying.includes(item)) continue;
        if ((p.asked[c.q.id] ?? -9999) > world.tick - 650) continue;
        const raw = item === 'wood' || item === 'stone';
        const sc = new Scorer().add(`the building needs ${item}`, 24 * traitMods(p).work).add('they are carrying some', 4).add('walking', -pen(c.d * 6));
        const experience=helperExperience(world,p,c.q.id,materialRequestKind(item),item);
        sc.add('personally received this material on an earlier request',experience.bonus);
        mkSocial(
          ctx,
          c,
          'request',
          { reqKind: raw ? item : 'goods', item, amount: Math.max(1, Math.min(miss - already, 4)), siteId: b.id, purpose: `for the ${(b.btype ?? 'building').replace('_', '-')}`, destKind: 'site', destId: b.id },
          `Ask ${c.q.name} for ${item}`,
          `to finish the ${(b.btype ?? 'building').replace('_', '-')}`,
          null,
          sc,
          'request',
          ':' + item,
          experience.reason,
        );
      }
    }
  }
}

// ───────────────────────── asking what people know ─────────────────────────
function optAskInfo(ctx: Ctx): void {
  const { world, p } = ctx;
  const cands = candidates(ctx);
  if (!cands.length) return;
  // what do I need but not know how to find?
  const wants: { kind: 'food' | 'wood' | 'stone' | 'water'; drive: number }[] = [];
  // do they actually lack any idea where food could be found? (a source they remember with food left counts)
  const foodBeliefs = beliefsByKind(p, ['berry_bush', 'fruit_tree', 'wild_grain', 'fish_spot']);
  const leads1 = foodBeliefs.filter((b) => sourceUsable(ctx, b, 1).ok).length;
  const leads2 = foodBeliefs.filter((b) => sourceUsable(ctx, b, 2).ok).length;
  const hs = hhState(ctx);
  // hungry now: any lead at all is enough to act on; merely worried about stocks: they want a couple of good ones
  if ((ctx.drives.hunger > 20 && leads1 < 1) || (ctx.drives.hunger <= 20 && hs.shortage > 0.45 && leads2 < 2)) wants.push({ kind: 'food', drive: Math.max(ctx.drives.hunger, 18 + 30 * hs.shortage) });
  if (ctx.drives.thirst > 18 && ctx.water < 1 && countBeliefsOfKind(p, 'water') === 0) wants.push({ kind: 'water', drive: Math.max(30, ctx.drives.thirst) });
  const needsWood = beliefsByKind(p, ['site']).some((b) => b.hh === p.hhId && (b.need?.wood ?? 0) > 0) || (!ctx.home && ctx.stage !== 'child');
  if (needsWood && countBeliefsOfKind(p, 'tree') < 2) wants.push({ kind: 'wood', drive: 22 });
  const needsStone = beliefsByKind(p, ['site']).some((b) => b.hh === p.hhId && (b.need?.stone ?? 0) > 0);
  if (needsStone && countBeliefsOfKind(p, 'rock') < 1) wants.push({ kind: 'stone', drive: 22 });
  for (const w of wants) {
    for (const c of cands) {
      if (c.d > 14) continue;
      if ((p.asked[c.q.id] ?? -9999) > world.tick - 500) continue;
      const sc = new Scorer().add(`does not know where to find ${w.kind}`, w.drive * 0.62).add(c.aff >= 20 ? 'a friend' : 'someone to ask', 2 + c.aff * 0.05).add('walking', -pen((c.d * 1.18) / Math.max(0.03, ctx.speed)) * 0.6);
      // rules 107 (checked_accounts.ts): what became of their earlier accounts of places, when I checked them myself
      const accounts = accountsExperience(world, p, c.q.id); if (accounts.bonus) sc.add(accounts.reason, accounts.bonus);
      mkSocial(ctx, c, 'ask_info', { infoKind: w.kind }, `Ask ${c.q.name} where to find ${w.kind}`, `to learn where ${w.kind} can be found`, null, sc, 'info', ':' + w.kind, accounts.reason);
    }
  }
  // rules 105 (location_question.ts): somebody I promised something to and cannot place may be asked after
  for (const who of peopleToAskAfter(world, p)) {
    for (const c of cands) {
      if (c.d > 14 || c.q.id === who.id) continue;
      if ((p.asked[c.q.id] ?? -9999) > world.tick - 500) continue;
      const sc = new Scorer().add(`does not know where to find ${who.name}, whom I promised`, 20).add(c.aff >= 20 ? 'a friend' : 'someone to ask', 2 + c.aff * 0.05).add('walking', -pen((c.d * 1.18) / Math.max(0.03, ctx.speed)) * 0.6);
      mkSocial(ctx, c, 'ask_info', { infoKind: 'person', destKind: 'person', destId: who.id }, `Ask ${c.q.name} where ${who.name} is`, `to find ${who.name} and keep my promise`, null, sc, 'info', ':person:' + who.id);
    }
  }
  void world;
}

// ───────────────────────── warning others ─────────────────────────
function optWarn(ctx: Ctx): void {
  const { world, p } = ctx;
  if (!ctx.dangers.length) return;
  // only first-hand sightings are worth running over to announce; hearsay spreads through ordinary chat
  const fresh = ctx.dangers.filter((b) => world.tick - b.seen < 600 && b.src === 'seen');
  if (!fresh.length) return;
  const tm = traitMods(p);
  for (const c of candidates(ctx, true)) {
    if (c.d > 11) continue;
    // do not repeat the warning
    const told = fresh.every((b) => p.told[c.q.id * 1_000_000 + b.id] !== undefined && world.tick - p.told[c.q.id * 1_000_000 + b.id] < 3500);
    if (told) continue;
    const sc = new Scorer().add('saw a wolf recently', 26 * tm.give * (0.8 + 0.4 * p.traits.caution)).add('walking', -pen((c.d * 1.18) / Math.max(0.03, ctx.speed)) * 0.5);
    if (c.s.child) sc.add('a child', 6);
    mkSocial(ctx, c, 'warn', {}, `Warn ${c.q.name} about the wolf`, 'to keep them safe', null, sc, 'warn');
  }
}

// ───────────────────────── spontaneous generosity ─────────────────────────
function optOffer(ctx: Ctx): void {
  const { world, p } = ctx;
  const tm = traitMods(p);
  for (const c of candidates(ctx, true)) {
    if (c.d > 12) continue;
    const q = c.q;
    const kin = p.relations[q.id]?.kin;
    const needFood = c.s.hungry;
    const needWater = c.s.thirsty;
    if (!needFood && !needWater) continue;
    if (c.s.carrying.some((k) => k === 'berries' || k === 'fruit' || k === 'fish' || k === 'grain' || PRESERVED_FOODS.some(f=>f===k)) && !c.s.child && !c.s.hurt) {
      // they have food of their own; they just have not eaten yet
      if (needFood && !needWater) continue;
    }
    const items: Items = {};
    let label = '';
    if (needFood) {
      const k = pickFood(p.inv, q.needs.hunger) as ItemKind | null;
      if (k && surplusOf(world, p, k) >= 1) {
        items[k] = Math.min(surplusOf(world, p, k), q.needs.hunger < 25 ? 3 : 2);
        label = k;
      }
    }
    if (needWater && surplusOf(world, p, 'water') >= 1) {
      items.water = 1;
      label = label ? label + ' and water' : 'water';
    }
    if (!label) continue;
    const rel = p.relations[q.id];
    const angry = rel && rel.avoidUntil > world.tick;
    if (angry && p.traits.generosity < 0.55) continue; // only the big-hearted offer to someone they have quarrelled with
    const sev = needFood ? clamp((50 - q.needs.hunger) / 50, 0, 1) : clamp((50 - q.needs.thirst) / 50, 0, 1);
    const sc = new Scorer().add(`${q.name} looks ${needFood ? 'hungry' : 'thirsty'}`, (14 + 26 * sev) * tm.give);
    if (c.s.child) sc.add('a child', 10);
    if (kin) sc.add('family', 7);
    sc.add('friendship', Math.max(0, c.aff) * 0.12);
    if (angry) sc.add('making peace', 4);
    sc.add('walking', -pen((c.d * 1.18) / Math.max(0.03, ctx.speed)) * 0.6);
    mkSocial(ctx, c, 'offer', { items }, `Offer ${label} to ${q.name}`, `to help ${q.name}`, null, sc, 'offer');
  }
  void isDependent;
}

// ───────────────────────── making peace ─────────────────────────
/**
 * Amends are only attempted while there is an open grievance with a cause, and only a few times (see grievance.ts). Once it is
 * settled there is nothing to apologise for until something new happens.
 */
function optReconcile(ctx: Ctx): void {
  const { world, p } = ctx;
  for (const c of candidates(ctx, true)) {
    const rel = p.relations[c.q.id];
    if (!rel || rel.kin) continue;
    if (!wantsAmends(world, p, c.q)) continue;
    // the quarrel has to have cooled a little first
    if (world.tick < rel.grievance!.since + 260) continue;
    if (c.d > 11) continue;
    const gentle = 0.35 + 0.65 * p.traits.generosity;
    const g = rel.grievance!;
    const sc = new Scorer().add(g.cause === 'broken_promise' ? 'wants to put right a broken promise' : 'wants to patch things up', (10 + 0.12 * g.weight) * gentle * 1.4).add('walking', -pen(c.d * 6));
    if (p.traits.sociability > 0.5) sc.add('misses the company', 3);
    if (sc.total < 7) continue;
    mkSocial(ctx, c, 'apologize', {}, `Make peace with ${c.q.name}`, `to settle things: ${g.detail}`, null, sc, 'peace');
  }
}

// ───────────────────────── stepping into a quarrel ─────────────────────────
function optMediate(ctx: Ctx): void {
  const { world, p } = ctx;
  if (ctx.stage === 'child' || ctx.drives.hunger > 30 || ctx.drives.thirst > 30) return;
  const quarrels = quarrelsFor(world, p);
  if (!quarrels.length) return;
  for (const c of candidates(ctx)) {
    const q = quarrels.find((x) => x.a === c.q);
    if (!q || c.d > 11) continue;
    const sc = new Scorer()
      .add(`${q.a.name} and ${q.b.name} have fallen out, and both are mine`, 12 + 0.1 * q.weight)
      .add('a peacemaker by nature', 6 * p.traits.generosity + 3 * p.traits.sociability)
      .add('walking', -pen(c.d * 6));
    if (sc.total < 8) continue;
    mkSocial(ctx, c, 'mediate', { pair: q.b.id }, `Talk ${q.a.name} round about ${q.b.name}`, `to help ${q.a.name} and ${q.b.name} make peace`, null, sc, 'peace', ':' + q.b.id);
  }
}

// ───────────────────────── recruiting help ─────────────────────────
function optRecruit(ctx: Ctx): void {
  const { world, p } = ctx;
  if (ctx.stage === 'child') return; // asking grown-ups to help with the building is for grown-ups
  if (ctx.drives.hunger > 30 || ctx.drives.thirst > 30) return;
  const sites = beliefsByKind(p, ['site']).filter((b) => {
    if (b.hh === p.hhId) return true;
    const project = projectAt(world, b.id);
    return project && (councilFor(world, project) ? mayCoordinate(world, p, project) : project.organiserId === p.id);
  });
  if (!sites.length) return;
  const site = sites[0] as Belief;
  const siteEnt = world.byId.get(site.id);
  const project = projectAt(world, site.id);
  const council = project && councilFor(world, project);
  // no use asking for hands where there is nothing to do with them yet: the site is waiting on materials
  if (!projectAt(world, site.id) && (site.progress ?? 0) >= Math.min(1, 0.06 + fractionAvailable(site)) - 0.02) return;
  const cap = (siteEnt && siteEnt.ent === 'site' ? siteEnt.maxWorkers : 3) + 1;
  const committedNow = helpersOn(world, site.id);
  if (!council && committedNow >= Math.min(2, cap)) return;
  for (const c of candidates(ctx)) {
    if (c.d > 12 || c.s.child) continue;
    if (!council && c.q.commitments.some((cm) => cm.status === 'active' && cm.siteId === site.id)) continue;
    if (activeCommitments(c.q).filter(cm=>!council||cm.siteId!==site.id).length >= MAX_ACTIVE_COMMITMENTS) continue;
    if ((p.asked[c.q.id] ?? -9999) > world.tick - 900) continue;
    if (projectAt(world, site.id) ? !canInvite(world, p, c.q, site.id) : c.aff < 8 && c.q.hhId !== p.hhId) continue;
    const sc = new Scorer().add('could use a hand with the building', (projectAt(world, site.id) ? 30 : 15) * traitMods(p).work + 0.1 * c.aff).add('walking', -pen(c.d * 6));
    mkSocial(ctx, c, 'recruit', { siteId: site.id }, `Ask ${c.q.name} to help with the ${(site.btype ?? 'building').replace('_', '-')}`, 'to share the building work', null, sc, 'recruit');
  }
}

// ───────────────────────── moving in together ─────────────────────────
function optPropose(ctx: Ctx): void {
  const { world, p } = ctx;
  if (world.settings.scene !== 'natural') return; // staged test scenes stay focused on what they are testing
  if (ctx.stage !== 'adult' && ctx.stage !== 'elder') return;
  if (ctx.drives.hunger > 25 || ctx.drives.thirst > 25) return;
  for (const c of candidates(ctx)) {
    const q = c.q;
    if (c.d > 10) continue;
    if (stageOf(world, q) === 'child' || stageOf(world, q) === 'youth') continue;
    if ((p.cooldowns['propose' + q.id] ?? 0) > world.tick) continue;
    const rel = p.relations[q.id];
    if (!rel || rel.familiarity < 10) continue;
    // housemates who are not family can still become a couple
    const sameHome = q.hhId === p.hhId;
    if (sameHome && (rel.kin || p.partnerId !== 0 || q.partnerId !== 0)) continue;
    const back = q.relations[p.id];
    if (!back) continue;
    let kind: 'partner' | 'roommate' | null = null;
    if (p.partnerId === 0 && q.partnerId === 0 && rel.affinity >= 30 && rel.trust >= 20 && back.affinity >= 26 && spark(p, q) && !rel.kin) kind = 'partner';
    else if (sameHome) continue;
    else if (rel.affinity >= 38 && rel.trust >= 26 && back.affinity >= 32) {
      // roommates: one of us has no real home and the other has room
      const hhP = ctx.members.length;
      const homeless = !ctx.home;
      const qHome = world.households.find((h) => h.id === q.hhId)?.homeId;
      const room = qHome ? (world.byId.get(qHome) as { type?: keyof typeof BUILD_DEF } | undefined) : undefined;
      if (homeless && room?.type && BUILD_DEF[room.type].sleepers > 0 && hhP <= 2) kind = 'roommate';
    }
    if (!kind) continue;
    const sc = new Scorer().add(kind === 'partner' ? 'wants to share a life' : 'could share a home', (kind === 'partner' ? 26 + (rel.affinity - 30) * 0.4 + (ctx.night ? 8 : 0) : 15 + (rel.affinity - 40) * 0.15)).add('walking', -pen(c.d * 6));
    mkSocial(ctx, c, 'propose', { joinKind: kind }, kind === 'partner' ? (sameHome ? `Tell ${q.name} they mean a lot` : `Ask ${q.name} to move in together`) : `Ask ${q.name} about sharing a home`, kind === 'partner' ? (sameHome ? 'to become a couple' : 'to share a household') : 'to find shelter together', null, sc, 'household');
  }
}

// ───────────────────────── swapping goods ─────────────────────────
function optTrade(ctx: Ctx): void {
  const { world, p } = ctx;
  if (ctx.drives.hunger > 55 || ctx.drives.thirst > 55) return;
  // what do I most want that I lack?
  let want: { item: ItemKind; n: number } | null = null;
  if (ctx.food < 2 && hhState(ctx).shortage > 0.3) want = { item: 'fish', n: 1 };
  for (const b of beliefsByKind(p, ['site'])) {
    if (b.hh !== p.hhId) continue;
    for (const k of ['wood', 'stone'] as const) {
      const miss = (b.need?.[k] ?? 0) - (p.inv[k] ?? 0);
      if (miss > 0) want = { item: k, n: Math.min(2, miss) };
    }
  }
  if (!want) return;
  // what can I spare?
  const spare: { item: ItemKind; n: number }[] = [];
  for (const k of ['berries', 'fruit', 'fish', 'grain', 'wood', 'stone', 'water', ...PRESERVED_FOODS] as ItemKind[]) {
    if (k === want.item) continue;
    const s = surplusOf(world, p, k);
    if (s >= 2) spare.push({ item: k, n: s });
  }
  if (!spare.length) return;
  spare.sort((a, b) => valueOf(world, p, a.item) * 0 + b.n - a.n);
  const offer = spare[0];
  exchangeJourneyOptions(ctx,want,offer);
  for (const c of candidates(ctx)) {
    if (c.d > 11) continue;
    const hasWant = want.item === 'fish' ? c.s.carrying.some((k) => isFood(k)) : c.s.carrying.includes(want.item);
    if (!hasWant) continue;
    if ((p.asked[c.q.id] ?? -9999) > world.tick - 700) continue;
    // Rules 51 (docs/CUSTOMERS.md) measured this swap: 132 proposed in three 45-day worlds, every one refused ("nothing to
    // spare" 86, "no room to carry the swap" 46); proposing it only to somebody seen carrying more than one, one for one, was
    // tried and refused just as often (155 of 155) while costing projects in the lab, so the swap stands as it was.
    const askItem: ItemKind = want.item === 'fish' ? (c.s.carrying.find((k) => isFood(k)) as ItemKind) : want.item;
    const sc = new Scorer().add('a swap could give me what I lack', 14 + 0.05 * c.aff).add('walking', -pen(c.d * 6));
    mkSocial(ctx, c, 'trade', { item: askItem, amount: want.n, offer: offer.item, offerAmount: Math.min(offer.n, want.n + 1) }, `Offer ${c.q.name} a swap: ${offer.item} for ${askItem}`, `to get ${askItem}`, null, sc, 'trade', ':' + askItem);
  }
  void hashUnit;
}

// rules 51 (customers.ts): bring a customer what they asked for, as a swap or a gift through the existing conversations
function optSupply(ctx: Ctx): void {
  const { world, p } = ctx;
  supplyOptions(ctx, (c, purpose, conv, label, goal, sc, keySuffix) => {
    const rel = p.relations[c.q.id];
    const cand: Cand = { s: ctx.seenPersons.find((s) => s.id === c.q.id)!, q: c.q, aff: rel?.affinity ?? 0, fam: rel?.familiarity ?? 0, d: c.d };
    if ((p.cooldowns['talk' + c.q.id] ?? 0) > world.tick) return;
    mkSocial(ctx, cand, purpose, conv as ConvData, label, goal, null, sc, 'trade', keySuffix);
  }, (q, item, loc, sc) => {
    const goal = `to supply ${q.name} with the ${item} they asked for`;
    addOption(ctx, {
      kind: 'visit',
      label: `Take ${item} to ${q.name}`,
      goal,
      need: null,
      util: sc.total,
      parts: sc.parts,
      eta: eta(ctx, loc.x, loc.y) + 12,
      key: `supply:${q.id}:${item}`,
      targetId: q.id,
      tag: 'trade',
      make: () => newActivity(world, p, { kind: 'visit', label: `Taking ${item} to ${q.name}`, goal, need: null, targetId: q.id, targetType: 'person', tx: loc.x, ty: loc.y, spotX: loc.x, spotY: loc.y, utility: sc.total, minCommit: 60, maxTicks: 900, data: { seek: true, about: q.id, items: {}, sticky: true } }),
    });
  });
}

// The teacher knows their own technique and family/apprentice relationship, not the other's private knowledge.
function optTeachTechnique(ctx: Ctx): void {
 const {world,p}=ctx;
 if(!heldTechniques(world)||!p.techniques||ctx.critical||ctx.night) return;
 // each held procedure in turn (rules 52: any of the tree; before it, charcoal alone), where the teacher knows the workshop it is for
 for(const kind of TECHNIQUE_KINDS){
  if(!techniqueApplies(world,kind)||!p.techniques[kind])continue;
  const def=TECHNIQUES[kind];
  const at=def.work==='kiln'?'kiln':'smithy';
  if(!beliefsByKind(p,['building']).some(b=>b.btype===at))continue;
  for(const c of candidates(ctx)) {
   if(c.d>10||(p.cooldowns['teach:'+c.q.id]??0)>world.tick)continue;
   const friend=hasLivedLife(world)&&ctx.stage==='elder'&&(p.relations[c.q.id]?.affinity??0)>=20&&!!p.relations[c.q.id]?.company;
   if(p.relations[c.q.id]?.kin!=='child'&&c.q.apprentice?.master!==p.id&&!friend)continue;
   if(stageOf(world,c.q)==='child')continue;
   // what the teacher can tell of the learner: a lesson is not offered on a procedure whose forerunner the teacher never saw them at
   // (the learner's own knowledge stays private; the offer is answered at contact, where it is read)
   const sc=new Scorer().add(friend?'pass a useful technique to a continuing companion':'pass a useful technique to family or apprentice',20+8*p.traits.generosity).add('walking',-pen(c.d*6));
   if(kind!=='charcoal')sc.add('a procedure that takes another first',-3);
   mkSocial(ctx,c,'teach_technique',kind==='charcoal'?{}:{technique:kind},`Offer ${c.q.name} ${def.name} instruction`,`pass on ${def.name}`,null,sc,'teach',kind==='charcoal'?'':':'+kind);
  }
 }
}

function optRequestTechnique(ctx: Ctx): void {
 const {world,p}=ctx;
 if(!hasLearnerInstruction(world)||!ctx.techniqueWanted||ctx.stage==='child'||ctx.critical||ctx.night)return;
 const kind=ctx.techniqueWanted.kind;
 if(knowsTechnique(world,p,kind))return;
 const def=TECHNIQUES[kind];
 // the one before it is not theirs yet: the ask would be refused, and the card says why (the forerunner is what to ask for)
 const before=learnBlocker(world,p,kind);
 if(before){addBlocked(ctx,'socialize',`Ask someone to teach ${def.name}`,0,before,'learn');return;}
 for(const c of candidates(ctx)) {
  if(c.d>10||(p.cooldowns['learn:'+c.q.id]??0)>world.tick)continue;
  if(p.relations[c.q.id]?.kin!=='parent'&&p.apprentice?.master!==c.q.id&&c.s.work!==def.work)continue;
  const sc=new Scorer().add(`I need ${def.name} for wanted work`,24+8*p.traits.curiosity).add('walking',-pen(c.d*6));
  mkSocial(ctx,c,'learn_technique',kind==='charcoal'?{}:{technique:kind},`Ask ${c.q.name} to teach ${def.name}`,`learn ${def.name}: `+ctx.techniqueWanted.for,null,sc,'learn','',`I want to ${def.doing} but have not learned how`);
  break;
 }
}

export function socialOptions(ctx: Ctx): void {
  if(hasCoaching(ctx.world)&&ctx.stage!=='child'&&!ctx.critical&&!ctx.night&&Math.min(ctx.p.needs.hunger,ctx.p.needs.thirst,ctx.p.needs.energy)>65&&(ctx.p.cooldowns.coached??0)<=ctx.world.tick&&(ctx.p.cooldowns.coachAsk??0)<=ctx.world.tick){
    for(const c of candidates(ctx)){const k=c.s.work;if(!k||c.s.child||c.d>6||ctx.p.skills[k]>=1.2)continue;
      const sc=new Scorer().add('practise a skill seen in use',14+8*ctx.p.traits.curiosity).add('walking',-pen(c.d*6));
      mkSocial(ctx,c,'learn_skill',{skill:k},`Ask ${c.q.name} for ${k} coaching`,'practise together if they agree',null,sc,'learn');break;
    }
  }
  if(ctx.stage==='child'&&!ctx.critical&&!ctx.night&&!ctx.dangers.some(b=>hyp(b.x-ctx.p.x,b.y-ctx.p.y)<10)&&Math.min(ctx.p.needs.hunger,ctx.p.needs.thirst,ctx.p.needs.energy)>42){
    for(const c of candidates(ctx))for(const kind of CHILD_TIMES){
      if(!wantsChildTime(ctx.world,ctx.p,c.q,kind))continue;
      const remembered=ctx.p.relations[c.q.id]?.childhood?.find(e=>e.kind===kind);
      const sc=new Scorer().add(kind==='learn_foraging'?'curious about learning':'time for childhood',18+(kind==='learn_foraging'?8*ctx.p.traits.curiosity:6*ctx.p.traits.sociability)).add('walking',-pen(c.d*6));
      if(remembered)sc.add('remembered time together',Math.min(3,remembered.times));
      mkSocial(ctx,c,kind,{},`${childTimeName(kind)} with ${c.q.name}`,`to ask for time together; they must agree`, 'social',sc,'childhood');
      const offered=ctx.options[ctx.options.length-1];if(offered?.key===`socialize:${c.q.id}:${kind}`)offered.eta+=childTimeTicks(kind);
    }
  }
  for(const m of careReturns(ctx.world,ctx.p)){
    const c=candidates(ctx).find(c=>c.q.id===m.otherId&&c.d<=14);if(!c)continue;
    const sc=new Scorer().add('I recovered and can ask to take childcare back',52).add('walking',-pen(c.d*6));
    mkSocial(ctx,c,'return_care',{requestId:m.requestId},`Discuss taking care back with ${c.q.name}`,'to resume care through an agreed handback',null,sc,'care-return',':'+m.requestId,'My own recovery permits an offer; the helper must agree with the child present');
  }
  for(const c of candidates(ctx)){
    if(c.d>10||c.s.child)continue;
    const follow=handoverFollowup(ctx.world,ctx.p,c.q.id),offer=c.q.hhId===ctx.p.hhId?handoverOffer(ctx.world,ctx.p,c.q.id):null;
    if(!follow&&!offer)continue;
    const mode=follow?.mode??'offer',sc=new Scorer().add(mode==='offer'?'ask for informed cover of my undertaking':'agree who continues the undertaking',32).add('walking',-pen(c.d*6));
    mkSocial(ctx,c,'handover_work',{planId:offer?.plan.id??0,handoverId:follow?.id??0,handoverMode:mode},`${mode==='offer'?'Ask for work cover from':mode==='return'?'Discuss taking work back with':'Report the work outcome to'} ${c.q.name}`,'agree responsibility through actual contact',null,sc,'work-handover',':'+(follow?.id??offer!.plan.id));
    break;
  }
  for(const c of candidates(ctx)){
    if(c.q.hhId!==ctx.p.hhId||c.d>10||c.s.child)continue;
    const work=workToTell(ctx.world,ctx.p,c.q.id);if(!work)continue;
    const sc=new Scorer().add('let a household member know what I am working on',17).add('walking',-pen(c.d*6));
    mkSocial(ctx,c,'share_work',{planId:work.id},`Tell ${c.q.name} about my ${work.kind} work`,'communicate my undertaking without assigning it',null,sc,'work-news',':'+work.id);
    break;
  }
  mealOptions(ctx);
  attendOptions(ctx);
  aloneOptions(ctx);
  welfareOptions(ctx);
  seekCarerOptions(ctx);
  let meetingsOffered=0;
  for(const update of pendingMeetingUpdates(ctx.world,ctx.p)){
    const c=candidates(ctx).find(c=>c.q.id===update.guest&&c.d<=14);if(!c)continue;
    const sc=new Scorer().add('I need to tell them our meal arrangement ended',30).add('walking',-pen(c.d*6));
    mkSocial(ctx,c,'cancel_meeting',{mealId:update.meal.id},`Explain the cancelled meal to ${c.q.name}`,'to communicate a change to our arrangement',null,sc,'meal-update',':'+update.meal.id);
    if(++meetingsOffered>=2)break;
  }
  let delaysOffered=0;
  for(const promise of pendingDelayProposals(ctx.world,ctx.p)){
    const c=candidates(ctx).find(c=>c.q.id===promise.to&&c.d<=14);if(!c)continue;
    const sc=new Scorer().add('my actual failed attempt needs explaining before the promise ends',29).add('walking',-pen(c.d*6));
    mkSocial(ctx,c,'delay_request',{requestId:promise.requestId},`Explain my delay to ${c.q.name}`,'to explain an obstacle and ask for more time',null,sc,'delay',':'+promise.requestId,'I remember trying and failing; extra time needs their agreement');
    if(++delaysOffered>=2)break;
  }
  let cancellationsOffered=0;
  for(const m of pendingCancellations(ctx.world,ctx.p)){
    const c=candidates(ctx).find(c=>c.q.id===m.otherId&&c.d<=14);if(!c)continue;
    const sc=new Scorer().add('my requested work is no longer needed; they have not acknowledged cancellation',28).add('walking',-pen(c.d*6));
    mkSocial(ctx,c,'cancel_request',{requestId:m.requestId},`Tell ${c.q.name} to stop my obsolete request`,'to cancel work I no longer need',null,sc,'cancel',':'+m.requestId,'My own target observation changed the need; I must tell the helper in person');
    if(++cancellationsOffered>=2)break;
  }
  let reportsOffered=0;
  for(const m of pendingPromiseReports(ctx.world,ctx.p)){
    const c=candidates(ctx).find(c=>c.q.id===m.otherId&&c.d<=14);if(!c)continue;
    const sc=new Scorer().add(m.resolution?'they have not heard how my promise ended':'they have not acknowledged my completed contribution',18).add('walking',-pen(c.d*6));
    mkSocial(ctx,c,'report',{requestId:m.requestId},m.resolution?`Explain to ${c.q.name} why my promised work ended`:`Tell ${c.q.name} my promised work is complete`,`report my own ${m.resolution?'outcome':'completion'} of request #${m.requestId}`,null,sc,'report',':'+m.requestId,`My retained ${m.resolution?'outcome':'completion'} of request #${m.requestId} has no acknowledgement; I can tell ${c.q.name} in person`);
    if(++reportsOffered>=2)break;
  }
  optRequest(ctx);
  optAskInfo(ctx);
  optWarn(ctx);
  optOffer(ctx);
  optReconcile(ctx);
  optMediate(ctx);
  optRecruit(ctx);
  optPropose(ctx);
  optTrade(ctx);
  optSupply(ctx);
  optTeachTechnique(ctx);
  optRequestTechnique(ctx);
  optChat(ctx);
  void eta;
}

void toolsHeldBy;
