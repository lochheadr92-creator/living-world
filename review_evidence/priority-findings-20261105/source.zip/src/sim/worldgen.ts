import {seedSheep} from './livestock';
import { depositRichness } from './geology';
import { runsRulesVersion } from './rulesversion';
import { foundMembership } from './townships';
import { DEPOSIT_TYPES, MAP_H, MAP_W, SOURCE_MAX } from './constants';
import { createBuilding } from './buildings';
import { addItem, emptyLedger, snapshotInitial } from './economy';
import { initializeWater } from './hydrology';
import { addToHousehold, createHousehold } from './households';
import { captureHouseholdCamp } from './cohortcapture';
import { ACCESS_CELL, observe, putBelief, waterBeliefId } from './knowledge';
import { createPerson } from './people';
import { relOf } from './relations';
import { layoutFor } from './profiles';
import { addSettlement, nearestHub } from './settlements';
import { makeGrid, gridQuery, isWalkable, isFreeLand, rebuildMobileGrid, solidChanged } from './registry';
import { perceive } from './perception';
import { hashString, hashUnit, RNG } from './rng';
import { makeSource } from './sources';
import { registerStartingTools } from './tools';
import { makeWolf } from './wildlife';
import type { Building, Entity, Household, Person, Settings, Source, SourceType, World } from './types';
import { T } from './types';
import { TAU, clamp, dist, hyp, smoothstep } from './util';

// ───────────────────────── noise ─────────────────────────
const fade = (t: number) => t * t * t * (t * (t * 6 - 15) + 10);
function vnoise(x: number, y: number, seed: number): number {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const xf = x - xi;
  const yf = y - yi;
  const a = hashUnit(xi, yi, seed);
  const b = hashUnit(xi + 1, yi, seed);
  const c = hashUnit(xi, yi + 1, seed);
  const d = hashUnit(xi + 1, yi + 1, seed);
  const u = fade(xf);
  const v = fade(yf);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
export function fbm(x: number, y: number, seed: number, oct = 4): number {
  let amp = 0.5;
  let f = 1;
  let sum = 0;
  let norm = 0;
  for (let i = 0; i < oct; i++) {
    sum += amp * vnoise(x * f, y * f, seed + i * 131);
    norm += amp;
    amp *= 0.5;
    f *= 2;
  }
  return sum / norm;
}

// ───────────────────────── blank world ─────────────────────────
export function defaultSettings(seed = 'meadow'): Settings {
  return { seed, population: 28, harsh: false, immigration: true, scene: 'natural' };
}

export function blankWorld(settings: Settings, W = MAP_W, H = MAP_H): World {
  const accessCW = Math.ceil(W / ACCESS_CELL);
  const accessCH = Math.ceil(H / ACCESS_CELL);
  const w: World = {
    settings: { ...settings },
    seed: settings.seed,
    sceneLabel: '',
    tick: 0,
    rng: new RNG(hashString(settings.seed + '|sim')),
    W,
    H,
    terrain: new Uint8Array(W * H).fill(T.GRASS),
    solid: new Uint8Array(W * H),
    occ: new Int32Array(W * H),
    wear: new Float32Array(W * H),
    accessCell: new Int32Array(accessCW * accessCH).fill(-1),
    waterDist: new Uint8Array(W * H).fill(255),
    stumps: [],
    nextId: 1,
    persons: [],
    deceased: [],
    sources: [],
    buildings: [],
    sites: [],
    plots: [],
    piles: [],
    graves: [],
    animals: [],
    tools: [],
    carts: [],
    meals: [],
    households: [],
    requests: [],
    conversations: [],
    reservations: new Map(),
    events: [],
    fx: [],
    delayed: [],
    weather: { kind: 'clear', rain: 0, cloud: 0.08, storm: 0, nextChange: 1500, temp: 16, wind: 0.22 },
    light: 1,
    ledger: emptyLedger(),
    camp: { x: W / 2, y: H / 2 },
    byId: new Map(),
    grid: makeGrid(W, H),
    pgrid: makeGrid(W, H),
    usedNames: new Set(),
    stats: {},
  };
  if (runsRulesVersion(w,14)) w.birthCount=0;
  return w;
}

// ───────────────────────── derived terrain data ─────────────────────────
export function computeWaterDist(world: World): void {
  const { W, H } = world;
  const dist8 = world.waterDist;
  dist8.fill(255);
  const queue: number[] = [];
  for (let i = 0; i < W * H; i++) {
    const t = world.terrain[i];
    if (t === T.DEEP || t === T.SHALLOW) {
      dist8[i] = 0;
      queue.push(i);
    }
  }
  let head = 0;
  while (head < queue.length) {
    const i = queue[head++];
    const x = i % W;
    const y = (i / W) | 0;
    const d = dist8[i];
    if (d >= 12) continue;
    const nb = [x > 0 ? i - 1 : -1, x < W - 1 ? i + 1 : -1, y > 0 ? i - W : -1, y < H - 1 ? i + W : -1];
    for (const n of nb) {
      if (n >= 0 && dist8[n] > d + 1) {
        dist8[n] = d + 1;
        queue.push(n);
      }
    }
  }
}

export function computeAccessCells(world: World): void {
  const { W, H } = world;
  const cw = Math.ceil(W / ACCESS_CELL);
  world.accessCell.fill(-1);
  for (let cy = 0; cy < Math.ceil(H / ACCESS_CELL); cy++) {
    for (let cx = 0; cx < cw; cx++) {
      let best = -1;
      let bd = 1e9;
      const mx = cx * ACCESS_CELL + ACCESS_CELL / 2;
      const my = cy * ACCESS_CELL + ACCESS_CELL / 2;
      for (let y = cy * ACCESS_CELL; y < Math.min(H, (cy + 1) * ACCESS_CELL); y++) {
        for (let x = cx * ACCESS_CELL; x < Math.min(W, (cx + 1) * ACCESS_CELL); x++) {
          if (isWaterAccessTile(world, x, y)) {
            const d = hyp(x + 0.5 - mx, y + 0.5 - my);
            if (d < bd) {
              bd = d;
              best = y * W + x;
            }
          }
        }
      }
      world.accessCell[cy * cw + cx] = best;
    }
  }
}

function isWaterAccessTile(world: World, x: number, y: number): boolean {
  const i = y * world.W + x;
  if (world.terrain[i] === T.DEEP || world.solid[i]) return false;
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      if (!dx && !dy) continue;
      const xx = x + dx;
      const yy = y + dy;
      if (xx < 0 || yy < 0 || xx >= world.W || yy >= world.H) continue;
      const t = world.terrain[yy * world.W + xx];
      if (t === T.DEEP || t === T.SHALLOW) return true;
    }
  }
  return false;
}

function floodReach(world: World, sx: number, sy: number, useSolid: boolean): Uint8Array {
  return floodReachFrom(world, [{ x: sx, y: sy }], useSolid);
}

/** every tile that can be walked to from any of the starting points */
function floodReachFrom(world: World, starts: { x: number; y: number }[], useSolid: boolean): Uint8Array {
  const { W, H } = world;
  const seen = new Uint8Array(W * H);
  const q: number[] = [];
  for (const st of starts) {
    const start = Math.floor(st.y) * W + Math.floor(st.x);
    if (seen[start]) continue;
    seen[start] = 1;
    q.push(start);
  }
  let head = 0;
  while (head < q.length) {
    const i = q[head++];
    const x = i % W;
    const y = (i / W) | 0;
    for (let k = 0; k < 4; k++) {
      const nx = x + (k === 0 ? 1 : k === 1 ? -1 : 0);
      const ny = y + (k === 2 ? 1 : k === 3 ? -1 : 0);
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const ni = ny * W + nx;
      if (seen[ni]) continue;
      if (world.terrain[ni] === T.DEEP) continue;
      if (useSolid && world.solid[ni]) continue;
      seen[ni] = 1;
      q.push(ni);
    }
  }
  return seen;
}

// ───────────────────────── natural world ─────────────────────────
interface Water {
  cx: number;
  cy: number;
  R: number;
  stretch: number;
  ax: number;
  seed: number;
  amp: number;
}

function waterValue(wt: Water, x: number, y: number): number {
  const dx = x + 0.5 - wt.cx;
  const dy = y + 0.5 - wt.cy;
  const c = Math.cos(wt.ax);
  const s = Math.sin(wt.ax);
  const u = dx * c + dy * s;
  const v = -dx * s + dy * c;
  const d = hyp(u / wt.stretch, v * wt.stretch);
  return d / wt.R + (fbm(x / 6.5, y / 6.5, wt.seed) - 0.5) * wt.amp;
}

function pickSpot(
  world: World,
  gen: RNG,
  cx: number,
  cy: number,
  rmin: number,
  rmax: number,
  pred: (x: number, y: number) => boolean,
  tries = 260,
): { x: number; y: number } | null {
  for (let i = 0; i < tries; i++) {
    const a = gen.next() * TAU;
    const r = rmin + gen.next() * (rmax - rmin);
    const x = Math.floor(cx + Math.cos(a) * r);
    const y = Math.floor(cy + Math.sin(a) * r);
    if (x < 3 || y < 3 || x >= world.W - 3 || y >= world.H - 3) continue;
    if (pred(x, y)) return { x, y };
  }
  return null;
}

/**
 * One founding group: where it settles, how many people, and how its surroundings scale against the ordinary camp of 28.
 * The ordinary world is exactly one of these (scale 1, one fire). A larger world is several, each laid out by the same recipe.
 */
export interface FoundingHub {
  x: number;
  y: number;
  founders: number;
  /** food, rock, fish, deposits, wolves, tools and the mix of ages, relative to the ordinary camp */
  scale: number;
  fires: number;
}

export interface Layout {
  W: number;
  H: number;
  hubs: FoundingHub[];
}

export function generateNatural(settings: Settings): World {
  const layout = layoutFor(settings);
  const world = blankWorld(settings, layout?.W, layout?.H);
  const { W, H } = world;
  const gen = new RNG(hashString(settings.seed + '|gen'));
  const S = hashString(settings.seed + '|noise') & 0xfffff;
  const harsh = settings.harsh;

  // camp somewhere around the middle (a larger world says where its camps are)
  let hubs: FoundingHub[];
  if (layout) hubs = layout.hubs;
  else {
    const cx = Math.floor(W / 2 + gen.range(-5, 5));
    const cy = Math.floor(H / 2 + gen.range(-5, 5));
    hubs = [{ x: cx, y: cy, founders: settings.population, scale: 1, fires: 1 }];
  }
  // Three of the rules below are corrections made for the crowded `town` profile, and all three are NEW BEHAVIOUR: the wolves the
  // ground will hold, the fishing a short shore can give, and how far out the first shelters may be set. Each is gated on rich
  // dynamics at the point where it is decided, so that an authored world of any profile generates exactly as it did before they
  // were written - by taking the old branch, not by arriving at the same answer a different way.
  const rich = settings.dynamics === 'rich';
  // How much more of everything a camp's people need than the ground they stand on would ordinarily hold. The ordinary world is one
  // camp of 28 on the whole 80x80 map, which is the unit: `crowding` is 1 for it, 1 for the Large and Huge profiles (whose camps
  // have more room than an ordinary camp, so there is nothing to make up), and about 3.6 for a town of 100 on the ordinary map.
  // One thing reads it: how many wolves the land holds (as its inverse, `room`, below), and only in a rich world.
  const ORDINARY_MAP_AREA = MAP_W * MAP_H;
  const campArea = (W * H) / hubs.length;
  const crowding = layout ? Math.max(1, ...hubs.map((h) => (h.scale * ORDINARY_MAP_AREA) / campArea)) : 1;
  const campX = hubs[0].x;
  const campY = hubs[0].y;
  world.camp = { x: campX + 0.5, y: campY + 0.5 };
  for (const h of hubs.slice(1)) addSettlement(world, h.x + 0.5, h.y + 0.5);
  const nearestDist = (x: number, y: number): number => {
    let d = Infinity;
    for (const h of hubs) d = Math.min(d, dist(x + 0.5, y + 0.5, h.x + 0.5, h.y + 0.5));
    return d;
  };

  // a lake beside each camp, ponds elsewhere
  const waters: Water[] = [];
  hubs.forEach((hub, hi) => {
    const lakeR = gen.range(10.5, 13);
    let lakeAng = gen.next() * TAU;
    const lakeAt = (ang: number) => ({
      x: clamp(hub.x + Math.cos(ang) * (lakeR + 8.5), lakeR + 4, W - lakeR - 4),
      y: clamp(hub.y + Math.sin(ang) * (lakeR + 8.5), lakeR + 4, H - lakeR - 4),
    });
    let at = lakeAt(lakeAng);
    // with several camps, turn the lake away from the others (a world with one camp never draws again here)
    for (let t = 0; hubs.length > 1 && t < 24 && hubs.some((o, oi) => oi !== hi && dist(at.x, at.y, o.x, o.y) < lakeR + 12); t++) {
      lakeAng = gen.next() * TAU;
      at = lakeAt(lakeAng);
    }
    const lcx = at.x;
    const lcy = at.y;
    waters.push({ cx: lcx, cy: lcy, R: lakeR, stretch: gen.range(0.82, 1.3), ax: gen.next() * Math.PI, seed: S + 1 + 16 * hi, amp: 0.62 });
    for (let i = 0; i < 2; i++) {
      const sp = pickSpot(world, gen, hub.x, hub.y, 22, 40, (x, y) => dist(x, y, lcx, lcy) > lakeR + 12 && x > 8 && y > 8 && x < W - 8 && y < H - 8 && (hubs.length === 1 || hubs.every((o) => dist(x, y, o.x, o.y) > 14)));
      if (sp) waters.push({ cx: sp.x, cy: sp.y, R: gen.range(3.4, 5.4), stretch: gen.range(0.85, 1.25), ax: gen.next() * Math.PI, seed: S + 5 + i + 16 * hi, amp: 0.5 });
    }
  });

  // water pass
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      let w = 9;
      if (nearestDist(x, y) >= 8.5) for (const wt of waters) w = Math.min(w, waterValue(wt, x, y));
      const i = y * W + x;
      if (w < 0.72) world.terrain[i] = T.DEEP;
      else if (w < 0.98) world.terrain[i] = T.SHALLOW;
    }
  }
  computeWaterDist(world);

  // land pass
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = y * W + x;
      if (world.terrain[i] === T.DEEP || world.terrain[i] === T.SHALLOW) continue;
      const dw = world.waterDist[i];
      const dC = nearestDist(x, y);
      const nz = fbm(x / 5.5, y / 5.5, S + 9);
      let t: number = T.GRASS;
      if (dw <= 1 || (dw === 2 && nz > 0.52) || (dw === 3 && nz > 0.78)) t = T.SAND;
      else {
        const ff = fbm(x / 11, y / 11, S + 2) + clamp((dC - 10) / 45, 0, 0.22);
        if (ff > 0.56) t = T.FOREST;
        const rf = fbm(x / 8, y / 8, S + 3);
        if (rf > 0.665 && dC > 14 && dw > 2) t = T.STONY;
      }
      world.terrain[i] = t;
    }
  }

  const terrainReach = floodReachFrom(world, hubs, false);
  const okLand = (x: number, y: number, allowForest = true): boolean => {
    const i = y * W + x;
    const t = world.terrain[i];
    if (!(t === T.GRASS || (allowForest && t === T.FOREST))) return false;
    return world.occ[i] === 0 && world.solid[i] === 0 && world.waterDist[i] >= 2 && terrainReach[i] === 1;
  };

  // ── trees ──
  const treeCountNear = (x: number, y: number) => {
    let n = 0;
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if ((dx || dy) && world.occ[(y + dy) * W + (x + dx)]) n++;
    return n;
  };
  for (let y = 2; y < H - 2; y++) {
    for (let x = 2; x < W - 2; x++) {
      const i = y * W + x;
      const t = world.terrain[i];
      if (t !== T.GRASS && t !== T.FOREST) continue;
      if (world.waterDist[i] < 3 || terrainReach[i] !== 1) continue;
      const dC = nearestDist(x, y);
      if (dC < 8.5) continue;
      const ff = fbm(x / 11, y / 11, S + 2) + clamp((dC - 10) / 45, 0, 0.22);
      const p = t === T.FOREST ? 0.06 + 0.3 * smoothstep(0.56, 0.84, ff) : 0.01;
      if (gen.next() < p && treeCountNear(x, y) <= 2) {
        const growth = gen.chance(0.12) ? gen.range(0.25, 0.7) : 1;
        const maxW = SOURCE_MAX.tree;
        makeSource(world, 'tree', x, y, Math.floor(maxW * growth + 1e-6) > 0 ? Math.max(1, Math.round(gen.range(3, maxW + 0.4) * growth)) : 0, growth);
      }
    }
  }

  // ── resource clusters ──
  const mk = (type: SourceType, x: number, y: number, amount?: number) => makeSource(world, type, x, y, amount);
  const scale = harsh ? 0.65 : 1;
  // everything below is laid out around one camp at a time (hubX, hubY), by the same recipe for each
  let hubX = campX;
  let hubY = campY;
  const cluster = (type: SourceType, rmin: number, rmax: number, count: number, spread: number, allowForest = true) => {
    const c = pickSpot(world, gen, hubX, hubY, rmin, rmax, (x, y) => okLand(x, y, allowForest));
    if (!c) return;
    let placed = 0;
    for (let k = 0; k < 40 && placed < count; k++) {
      const x = c.x + Math.round(gen.range(-spread, spread));
      const y = c.y + Math.round(gen.range(-spread, spread));
      if (x < 3 || y < 3 || x >= W - 3 || y >= H - 3 || !okLand(x, y, allowForest)) continue;
      const maxv = SOURCE_MAX[type];
      mk(type, x, y, Math.max(1, Math.round(gen.range(maxv * 0.35, maxv))));
      placed++;
    }
  };
  const nearB = harsh ? 2 : 3;
  const once = (m: number): number => Math.max(1, Math.round(m)); // the single clusters of the recipe, repeated for a larger camp

  // rock outcrops: ensure a small near cluster by carving stony ground if the noise left none
  const rockSpot = (rmin: number, rmax: number, count: number) => {
    const c = pickSpot(world, gen, hubX, hubY, rmin, rmax, (x, y) => okLand(x, y, true));
    if (!c) return;
    let placed = 0;
    for (let k = 0; k < 60 && placed < count; k++) {
      const x = c.x + Math.round(gen.range(-2.6, 2.6));
      const y = c.y + Math.round(gen.range(-2.6, 2.6));
      if (x < 3 || y < 3 || x >= W - 3 || y >= H - 3 || !okLand(x, y, true)) continue;
      mk('rock', x, y, Math.max(2, Math.round(gen.range(4, SOURCE_MAX.rock))));
      placed++;
      for (let dy = -1; dy <= 1; dy++)
        for (let dx = -1; dx <= 1; dx++) {
          const j = (y + dy) * W + (x + dx);
          if ((world.terrain[j] === T.GRASS || world.terrain[j] === T.FOREST) && world.waterDist[j] > 2) world.terrain[j] = T.STONY;
        }
    }
  };
  for (const hub of hubs) {
    hubX = hub.x;
    hubY = hub.y;
    const m = hub.scale;
    for (let i = 0; i < Math.round(nearB * m); i++) cluster('berry_bush', 7.5, 13.5, gen.int(3) + 3, 2.2);
    for (let i = 0; i < Math.round(3 * scale * m); i++) cluster('berry_bush', 16, 27, gen.int(3) + 3, 2.4);
    for (let i = 0; i < Math.round(4 * scale * m); i++) cluster('berry_bush', 28, 46, gen.int(3) + 3, 2.4);
    for (let i = 0; i < once(m); i++) cluster('fruit_tree', 14, 20, 3, 2.6);
    for (let i = 0; i < Math.round(2 * scale * m); i++) cluster('fruit_tree', 22, 32, gen.int(2) + 3, 2.8);
    for (let i = 0; i < Math.round(3 * scale * m); i++) cluster('fruit_tree', 33, 50, gen.int(3) + 2, 2.8);
    for (let i = 0; i < once(m); i++) cluster('wild_grain', 10, 17, 5, 1.8, false);
    for (let i = 0; i < Math.round(2 * scale * m); i++) cluster('wild_grain', 19, 31, gen.int(3) + 3, 2, false);
    for (let i = 0; i < Math.round(2 * scale * m); i++) cluster('wild_grain', 33, 48, gen.int(3) + 3, 2, false);
    for (let i = 0; i < once(m); i++) rockSpot(14, 21, 4);
    for (let i = 0; i < Math.round(3 * scale * m); i++) rockSpot(24, 46, 5);
  }
  // rocks on naturally stony ground
  for (let y = 3; y < H - 3; y++) {
    for (let x = 3; x < W - 3; x++) {
      const i = y * W + x;
      if (world.terrain[i] === T.STONY && world.occ[i] === 0 && gen.next() < 0.1 && terrainReach[i] === 1) {
        mk('rock', x, y, Math.max(2, Math.round(gen.range(4, SOURCE_MAX.rock))));
      }
    }
  }

  // fish spots
  const fishCand: number[] = [];
  for (let y = 2; y < H - 2; y++) {
    for (let x = 2; x < W - 2; x++) {
      const i = y * W + x;
      if (world.terrain[i] !== T.SHALLOW) continue;
      let land = false;
      let deep = false;
      for (let dy = -1; dy <= 1; dy++)
        for (let dx = -1; dx <= 1; dx++) {
          const t = world.terrain[(y + dy) * W + (x + dx)];
          if (t === T.SAND || t === T.GRASS || t === T.FOREST) land = true;
          if (t === T.DEEP) deep = true;
        }
      if (land && deep && terrainReach[i] === 1) fishCand.push(i);
    }
  }
  gen.shuffle(fishCand);
  const fishSpots: { x: number; y: number }[] = [];
  for (const hub of hubs) {
    const wantFish = Math.round(11 * scale * hub.scale);
    let got = 0;
    const placed: Source[] = [];
    fishCand.sort((a, b) => {
      const da = dist(a % W, (a / W) | 0, hub.x, hub.y);
      const db = dist(b % W, (b / W) | 0, hub.x, hub.y);
      return da - db + (hashUnit(a, 3) - hashUnit(b, 3)) * 14; // mostly near the camp but with scatter
    });
    for (const i of fishCand) {
      if (got >= wantFish) break;
      const x = i % W;
      const y = (i / W) | 0;
      if (fishSpots.some((f) => dist(f.x, f.y, x, y) < 4.2)) continue;
      fishSpots.push({ x, y });
      got++;
      placed.push(mk('fish_spot', x, y, Math.max(2, Math.round(gen.range(4, SOURCE_MAX.fish_spot)))));
    }
    // A big camp on a small shore (the town: a hundred people on the ordinary map) cannot be given its share of fishing spots, so
    // the spots it has are made to give as much as its share would: they fill again that much faster. The per-person fishing
    // of the ordinary camp is kept; only how it is laid along the shore changes. A camp that got its full count is untouched.
    // (only a camp bigger than the village's: the village itself, and the Large and Huge camps, are laid out exactly as always)
    //
    // Rich only. The spots themselves are placed above either way, from the same draws; what a rich world changes is how fast
    // they fill again, so an authored world's shore is the shore it always had, spot for spot and rate for rate.
    if (rich && hub.scale > 1.5 && got > 0 && got < wantFish) {
      const share = got / wantFish;
      for (const s of placed) s.regrowEvery = Math.max(20, Math.round(s.regrowEvery * share));
    }
  }

  // ── each camp: fire(s), first shelters, households and people ──
  for (const hub of hubs) {
    createBuilding(world, 'fire', hub.x, hub.y, 0, { fuel: 1500 });
    // one fire for about every 28 people, as in the ordinary camp (the ordinary world has exactly one)
    for (let k = 1; k < hub.fires; k++) {
      for (let a = 0; a < 12; a++) {
        const ang = (k / hub.fires + a / 12) * TAU;
        const fx = Math.floor(hub.x + 0.5 + Math.cos(ang) * 3.2);
        const fy = Math.floor(hub.y + 0.5 + Math.sin(ang) * 3.2);
        if (isFreeLand(world, fx, fy) && world.waterDist[fy * W + fx] >= 3) {
          createBuilding(world, 'fire', fx, fy, 0, { fuel: 1500 });
          break;
        }
      }
    }
    populate(world, gen, hub.founders, hub.x, hub.y, hub.scale);
  }

  // ── wolves ──
  // Wolves follow the people (a camp of 56 has twice a camp of 28's), and in a RICH world no further than the ground will hold: a
  // hundred people on the ordinary 80x80 map are not 3.6 ordinary camps' worth of country, and giving them 3.6 camps' worth of
  // wolves put eleven dens inside one village's walking distance. `room` is the inverse of the crowding above: 1 wherever a camp
  // has an ordinary camp's land or more, so the Large and Huge profiles keep exactly the wolves they had, and about 0.28 for a
  // town of 100 on the ordinary map, which gets the three dens that much ground supports.
  //
  // That correction is new behaviour, so it is rich only. An authored world of any profile keeps the wolves it always had, from
  // its people alone - and keeps them by taking the same branch, not by arriving at the same number: the count decides how many
  // times `pickSpot` draws below, so an authored world that computed `room` and then threw the answer away would still generate a
  // different world from here on. Held by tests/regions.test.ts against the counts recorded before this rule existed.
  const room = rich ? 1 / crowding : 1;
  const dens: { x: number; y: number }[] = [];
  for (const hub of hubs) {
    const wolfCount = Math.round((harsh ? 5 : 3) * hub.scale * room);
    for (let i = 0; i < wolfCount; i++) {
      const denOk = (x: number, y: number): boolean =>
        world.terrain[y * W + x] === T.FOREST && world.solid[y * W + x] === 0 && terrainReach[y * W + x] === 1 && dens.every((d) => dist(d.x, d.y, x, y) > 14) && openNeighbours(world, x, y) >= 6 && (hubs.length === 1 || hubs.every((o) => dist(o.x, o.y, x, y) >= 23));
      // a den beside the only pond would keep people from ever drinking: prefer ground well away from water
      const sp = pickSpot(world, gen, hub.x, hub.y, 23, 44, (x, y) => denOk(x, y) && world.waterDist[y * W + x] >= 10) ?? pickSpot(world, gen, hub.x, hub.y, 23, 44, denOk);
      if (sp) {
        dens.push(sp);
        makeWolf(world, sp.x + 0.5, sp.y + 0.5);
      }
    }
  }

  // ── deposits: clay by the water, ore and big outcrops in the rocky country ──
  // (drawn from their own random stream, after everything else, so the rest of the world is laid out exactly as it always was)
  placeDeposits(world, new RNG(hashString(settings.seed + '|deposits')), hubs, terrainReach);

  // the forest may recover from felling, but not grow without bound
  world.stats.treeCap = Math.round((world.stats.trees ?? 0) * 1.08);

  // drop resources that ended up unreachable
  finalizeReachability(world, hubs);
  computeAccessCells(world);
  initializeWater(world);
  seedSheep(world,terrainReach);
  seedKnowledge(world, gen);
  lookAround(world);
  snapshotInitial(world);
  return world;
}

/**
 * Finite deposits that make the later chains possible. They are not near the camp (nobody starts out knowing them):
 * clay lies along the shores, ore under stony ground a long walk out, and large cuttable outcrops between.
 */
function placeDeposits(world: World, dg: RNG, hubs: FoundingHub[], reach: Uint8Array): void {
  const { W, H } = world;
  // each camp gets its own share, laid out by the same recipe around it (the ordinary world has the one)
  let campX = hubs[0].x;
  let campY = hubs[0].y;
  const free = (x: number, y: number): boolean => x >= 4 && y >= 4 && x < W - 4 && y < H - 4 && world.occ[y * W + x] === 0 && world.solid[y * W + x] === 0 && reach[y * W + x] === 1;
  const placed: { x: number; y: number }[] = [];
  const apart = (x: number, y: number, d: number): boolean => placed.every((q) => dist(q.x, q.y, x, y) >= d);
  const stonyNear = (x: number, y: number, r: number): boolean => {
    for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) if (world.terrain[(y + dy) * W + (x + dx)] === T.STONY) return true;
    return false;
  };
  const pickFrom = (cands: number[], n: number, spacing: number, type: SourceType, lo: number, hi: number): void => {
    dg.shuffle(cands);
    cands.sort((a, b) => (dist(a % W, (a / W) | 0, campX, campY) + hashUnit(a, 9) * 10) - (dist(b % W, (b / W) | 0, campX, campY) + hashUnit(b, 9) * 10));
    let k = 0;
    for (const i of cands) {
      if (k >= n) break;
      const x = i % W;
      const y = (i / W) | 0;
      if (!free(x, y) || !apart(x, y, spacing)) continue;
      const baseline=Math.max(2,Math.round(dg.range(lo,hi)));
      const amount=Math.max(2,Math.round(baseline*depositRichness(world,type,x,y)));
      const source=makeSource(world,type,x,y,amount);source.max=Math.max(source.max,amount);
      placed.push({ x, y });
      k++;
      if (type === 'outcrop' || type === 'ore_vein') {
        for (let dy = -1; dy <= 1; dy++)
          for (let dx = -1; dx <= 1; dx++) {
            const j = (y + dy) * W + (x + dx);
            if ((world.terrain[j] === T.GRASS || world.terrain[j] === T.FOREST) && world.waterDist[j] > 2) world.terrain[j] = T.STONY;
          }
      }
    }
  };
  for (const hub of hubs) {
    campX = hub.x;
    campY = hub.y;
    const clay: number[] = [];
    const ore: number[] = [];
    const outcrop: number[] = [];
    for (let y = 4; y < H - 4; y++) {
      for (let x = 4; x < W - 4; x++) {
        const i = y * W + x;
        const t = world.terrain[i];
        const d = dist(x + 0.5, y + 0.5, campX + 0.5, campY + 0.5);
        if ((t === T.SAND || t === T.GRASS) && world.waterDist[i] >= 1 && world.waterDist[i] <= 3 && d >= 11 && d <= 36) clay.push(i);
        if ((t === T.STONY || t === T.FOREST || t === T.GRASS) && world.waterDist[i] >= 3 && stonyNear(x, y, 2) && d >= 24 && d <= 46) ore.push(i);
        if ((t === T.STONY || t === T.GRASS) && world.waterDist[i] >= 3 && stonyNear(x, y, 1) && d >= 17 && d <= 36) outcrop.push(i);
      }
    }
    pickFrom(clay, Math.round(3 * hub.scale), 9, 'clay_pit', 24, SOURCE_MAX.clay_pit);
    pickFrom(outcrop, Math.round(2 * hub.scale), 10, 'outcrop', 40, SOURCE_MAX.outcrop);
    pickFrom(ore, Math.round(2 * hub.scale), 12, 'ore_vein', 14, SOURCE_MAX.ore_vein);
  }
}

/** Everyone takes a first look at their surroundings before the first decision is made. */
export function lookAround(world: World): void {
  rebuildMobileGrid(world);
  for (const p of world.persons) perceive(world, p);
}

function openNeighbours(world: World, x: number, y: number): number {
  let n = 0;
  for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if ((dx || dy) && isWalkable(world, x + dx, y + dy)) n++;
  return n;
}

function finalizeReachability(world: World, hubs: FoundingHub[]): void {
  const reach = floodReachFrom(world, hubs, true);
  const W = world.W;
  const isReachableNear = (x: number, y: number) => {
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const xx = x + dx;
      const yy = y + dy;
      if (xx >= 0 && yy >= 0 && xx < W && yy < world.H && reach[yy * W + xx] && world.solid[yy * W + xx] === 0) return true;
    }
    return false;
  };
  const doomed: Source[] = [];
  for (const s of world.sources) {
    if (s.type === 'tree') continue;
    if (!isReachableNear(s.x, s.y)) doomed.push(s);
  }
  for (const s of doomed) {
    const i = world.sources.indexOf(s);
    world.sources.splice(i, 1);
    world.byId.delete(s.id);
    const arr = world.grid.cells.find((c) => c.includes(s));
    if (arr) arr.splice(arr.indexOf(s), 1);
    world.occ[s.y * W + s.x] = 0;
    world.solid[s.y * W + s.x] = 0;
  }
  if (doomed.length) solidChanged(world);
}

// ───────────────────────── people ─────────────────────────
interface Member {
  age: number;
  sex: 'f' | 'm';
  role: 'adult' | 'kid' | 'elder' | 'youth';
}

function buildHouseholdSpecs(gen: RNG, population: number, scale = 1): Member[][] {
  const specs: Member[][] = [];
  let remaining = population;
  // the ordinary camp has at most 3 elders and at least 3 children and 2 elders; a larger camp has proportionally more
  const elderCap = Math.max(3, Math.round(3 * scale));
  const minKids = Math.max(3, Math.round(3 * scale));
  const minElders = Math.max(2, Math.round(2 * scale));
  const sx = (): 'f' | 'm' => (gen.chance(0.5) ? 'f' : 'm');
  let kids = 0;
  let elders = 0;
  while (remaining > 0) {
    const roll = gen.next();
    let m: Member[] = [];
    if (roll < 0.34 && remaining >= 3) {
      m = [
        { age: gen.range(22, 44), sex: 'f', role: 'adult' },
        { age: gen.range(22, 46), sex: 'm', role: 'adult' },
      ];
      const nk = remaining >= 4 && gen.chance(0.55) ? 2 : 1;
      for (let i = 0; i < nk; i++) m.push({ age: gen.range(1.5, 11), sex: sx(), role: 'kid' });
      kids += nk;
    } else if (roll < 0.5 && remaining >= 2) {
      const s1 = sx();
      m = [
        { age: gen.range(18, 50), sex: s1, role: 'adult' },
        { age: gen.range(18, 50), sex: gen.chance(0.88) ? (s1 === 'f' ? 'm' : 'f') : s1, role: 'adult' },
      ];
    } else if (roll < 0.62 && remaining >= 2) {
      m = [{ age: gen.range(26, 44), sex: sx(), role: 'adult' }, { age: gen.range(2, 10), sex: sx(), role: 'kid' }];
      kids++;
    } else if (roll < 0.7 && remaining >= 2 && elders < elderCap) {
      m = [{ age: gen.range(66, 76), sex: sx(), role: 'elder' }, { age: gen.range(30, 44), sex: sx(), role: 'adult' }];
      elders++;
    } else if (roll < 0.78 && remaining >= 3) {
      const s1 = sx();
      m = [
        { age: gen.range(17, 30), sex: s1, role: 'adult' },
        { age: gen.range(17, 30), sex: gen.chance(0.85) ? (s1 === 'f' ? 'm' : 'f') : s1, role: 'adult' },
        { age: gen.range(13, 16), sex: sx(), role: 'youth' },
      ];
    } else {
      m = [{ age: gen.range(17, 55), sex: sx(), role: 'adult' }];
    }
    if (m.length > remaining) m = m.slice(0, remaining);
    specs.push(m);
    remaining -= m.length;
  }
  // make sure the band has some children and elders to show caregiving and life stages
  if (kids < minKids) {
    for (const s of specs) {
      if (s.length === 1 && s[0].role === 'adult' && s[0].age > 24 && kids < minKids) {
        s.push({ age: gen.range(2, 9), sex: sx(), role: 'kid' });
        kids++;
      }
    }
  }
  if (elders < minElders) {
    for (const s of specs) {
      if (s.length === 1 && elders < minElders) {
        s[0] = { age: gen.range(66, 75), sex: s[0].sex, role: 'elder' };
        elders++;
      }
    }
  }
  return specs;
}

function populate(world: World, gen: RNG, population: number, campX: number, campY: number, scale = 1): void {
  const firstPerson = world.persons.length; // a camp is one band: its people know each other, and not the people of other camps
  const specs = buildHouseholdSpecs(gen, population, scale);
  // trim if oversized after the fix-ups
  let total = specs.reduce((s, m) => s + m.length, 0);
  while (total > population) {
    const last = specs[specs.length - 1];
    last.pop();
    if (!last.length) specs.pop();
    total--;
  }
  const shelterCount = Math.max(1, Math.round(specs.length * 0.6));
  const used = new Set<number>();
  const households: Household[] = [];
  const homes: { x: number; y: number }[] = [];

  // Lean-to ring around the camp. A big camp needs more rings than the village's six, or a third of its first shelters find no
  // room - but that is a correction made for the town, and so it is rich only: an authored camp of any size keeps the six rings
  // it always had, and with them the shelters it always ended up with.
  const rings = world.settings.dynamics === 'rich' ? Math.round(6 * Math.max(1, Math.sqrt(scale))) : 6;
  for (let h = 0; h < shelterCount; h++) {
    const ang0 = (h / shelterCount) * TAU + gen.range(-0.2, 0.2);
    let placed = false;
    for (let ring = 0; ring < rings && !placed; ring++) {
      for (let a = 0; a < 16 && !placed; a++) {
        const ang = ang0 + (a % 2 ? 1 : -1) * Math.floor((a + 1) / 2) * 0.22;
        const r = 5.2 + ring * 0.9;
        const x = Math.floor(campX + 0.5 + Math.cos(ang) * r);
        const y = Math.floor(campY + 0.5 + Math.sin(ang) * r);
        if (!isFreeLand(world, x, y) || world.waterDist[y * world.W + x] < 3) continue;
        if (!isFreeLand(world, x, y + 1)) continue;
        if (homes.some((hm) => dist(hm.x, hm.y, x, y) < 3.4)) continue;
        homes.push({ x, y });
        placed = true;
      }
    }
    if (!placed) homes.push({ x: -1, y: -1 });
  }

  specs.forEach((members, hIdx) => {
    const hh = createHousehold(world, gen);
    captureHouseholdCamp(world, hh, campX, campY);
    foundMembership(world, hh, campX, campY);
    households.push(hh);
    const home = hIdx < shelterCount && homes[hIdx].x >= 0 ? homes[hIdx] : null;
    let lean: Building | null = null;
    if (home) {
      lean = createBuilding(world, 'lean_to', home.x, home.y, hh.id, { condition: 70 + gen.range(0, 30) });
      hh.homeId = lean.id;
    }
    const ax = lean ? lean.doorX + 0.5 : campX + 0.5 + gen.range(-4, 4);
    const ay = lean ? lean.doorY + 0.5 : campY + 0.5 + gen.range(3, 7);
    const persons: Person[] = [];
    members.forEach((m, mi) => {
      let x = ax + gen.range(-1.4, 1.4);
      let y = ay + gen.range(-1.0, 1.4) + (mi > 0 ? 0.3 : 0);
      for (let tries = 0; tries < 12 && !isWalkable(world, Math.floor(x), Math.floor(y)); tries++) {
        x = ax + gen.range(-2.2, 2.2);
        y = ay + gen.range(-2.2, 2.2);
      }
      const p = createPerson(world, gen, { age: m.age, sex: m.sex, hhId: hh.id, x, y });
      if (m.role === 'elder') p.health = 82;
      addToHousehold(world, p, hh);
      world.persons.push(p);
      world.byId.set(p.id, p);
      persons.push(p);
      used.add(p.id);
    });
    // kinship: adults who live together as couples, kids belong to adults
    const kids = persons.filter((_, i) => members[i].role === 'kid' || members[i].role === 'youth');
    const elders = persons.filter((_, i) => members[i].role === 'elder');
    const workers = persons.filter((_, i) => members[i].role === 'adult');
    if (workers.length >= 2 && elders.length === 0) {
      const [a, b] = workers;
      a.partnerId = b.id;
      b.partnerId = a.id;
      link(a, b, 'partner', 'partner');
    }
    const parents = workers.length >= 2 && elders.length === 0 ? [workers[0], workers[1]] : workers.length ? [workers[0]] : [];
    for (const k of kids) {
      for (const par of parents) {
        k.parents.push(par.id);
        par.children.push(k.id);
        link(par, k, 'child', 'parent');
      }
    }
    for (const e of elders) {
      for (const w of workers) {
        e.children.push(w.id);
        w.parents.push(e.id);
        link(e, w, 'child', 'parent');
      }
    }
    for (let i = 0; i < kids.length; i++) for (let j = i + 1; j < kids.length; j++) link(kids[i], kids[j], 'sibling', 'sibling');
    // initial belongings
    const size = persons.length;
    const store = lean ? lean.store.items : null;
    for (const p of persons) {
      if (members[persons.indexOf(p)].role === 'kid') continue;
      const foods = ['berries', 'fruit', 'grain'] as const;
      addItem(p.inv, foods[gen.int(3)], 1 + gen.int(3));
      if (gen.chance(0.5)) addItem(p.inv, 'water', 1);
    }
    if (store) {
      addItem(store, 'berries', world.settings.harsh ? 1 : 2 + size);
      addItem(store, 'fruit', world.settings.harsh ? 0 : 1 + Math.floor(size / 2));
      if (gen.chance(0.6)) addItem(store, 'wood', 2);
    }
    hh.headId = (workers[0] ?? persons[0]).id;
  });

  // tools and seeds are unevenly distributed: some households own them, others do not
  const heads = households.map((h) => world.byId.get(h.headId) as Person);
  const pickHead = () => heads[gen.int(heads.length)];
  // (the ordinary camp has 2 axes, 1 hoe, 2 baskets, 1 pick and 4 packets of seed; a larger camp has proportionally more)
  const kit = (base: number): number => Math.max(base, Math.round(base * scale));
  for (let i = 0; i < kit(2); i++) addItem(pickHead().inv, 'axe', 1);
  for (let i = 0; i < kit(1); i++) addItem(pickHead().inv, 'hoe', 1);
  for (let i = 0; i < kit(2); i++) addItem(pickHead().inv, 'basket', 1);
  for (let i = 0; i < kit(1); i++) addItem(pickHead().inv, 'pick', 1);
  for (let i = 0; i < kit(4); i++) addItem(pickHead().inv, 'seeds', 2 + gen.int(2));
  // dedupe-cap tools to one per person
  for (const p of world.persons) for (const t of ['axe', 'pick', 'hoe', 'basket'] as const) if ((p.inv[t] ?? 0) > 1) p.inv[t] = 1;
  registerStartingTools(world);

  // acquaintance among band members
  const ps = world.persons.slice(firstPerson);
  for (let i = 0; i < ps.length; i++) {
    for (let j = i + 1; j < ps.length; j++) {
      const a = ps[i];
      const b = ps[j];
      if (a.relations[b.id]) continue;
      const aff = clamp(gen.gauss() * 15 + 8, -26, 46);
      const fam = 2 + gen.int(7);
      const ra = relOf(a, b.id);
      const rb = relOf(b, a.id);
      ra.affinity = aff + gen.range(-3, 3);
      rb.affinity = aff + gen.range(-3, 3);
      ra.trust = clamp(16 + aff * 0.5 + gen.range(-6, 10), 2, 60);
      rb.trust = clamp(16 + aff * 0.5 + gen.range(-6, 10), 2, 60);
      ra.familiarity = fam;
      rb.familiarity = fam;
      ra.lastMet = -300 - gen.int(1500);
      rb.lastMet = ra.lastMet;
    }
  }
}

function link(a: Person, b: Person, aToB: 'partner' | 'child' | 'parent' | 'sibling', bToA: 'partner' | 'child' | 'parent' | 'sibling'): void {
  const strong = aToB === 'partner' || aToB === 'parent' || aToB === 'child' ? 82 : 62;
  const ra = relOf(a, b.id);
  const rb = relOf(b, a.id);
  ra.kin = aToB;
  rb.kin = bToA;
  ra.affinity = strong;
  rb.affinity = strong;
  ra.trust = 78;
  rb.trust = 78;
  ra.familiarity = 40;
  rb.familiarity = 40;
}

// ───────────────────────── starting knowledge ─────────────────────────
function seedKnowledge(world: World, gen: RNG): void {
  const R = 13.5;
  // everyone starts out knowing the surroundings of their own camp (the ordinary world has the one)
  const camps = [world.camp, ...(world.extraSettlements ?? [])];
  const around = camps.map((camp) => {
    const near: Entity[] = [];
    gridQuery(world.grid, camp.x, camp.y, R + 3, (e) => {
      const cx = e.ent === 'building' || e.ent === 'site' ? e.x + e.w / 2 : (e as { x: number }).x + 0.5;
      const cy = e.ent === 'building' || e.ent === 'site' ? e.y + e.h / 2 : (e as { y: number }).y + 0.5;
      if (dist(cx, cy, camp.x, camp.y) <= R) near.push(e);
    });
    // places noticed on the way here: with several camps, only those in one's own part of the map
    const farthest = camps.length > 1 ? 50 : Infinity;
    const far = world.sources.filter((s) => s.type !== 'tree' && !DEPOSIT_TYPES.includes(s.type) && dist(s.x, s.y, camp.x, camp.y) > R + 1 && dist(s.x, s.y, camp.x, camp.y) <= farthest);
    return { near, far };
  });
  const cw = Math.ceil(world.W / ACCESS_CELL);
  const W = world.W;
  for (const p of world.persons) {
    const camp = nearestHub(world, p.x, p.y);
    const { near, far } = around[camps.indexOf(camp)];
    for (const e of near) {
      observe(world, p, e);
      const b = p.beliefs[e.id];
      if (b) b.seen = -Math.floor(gen.range(40, 500));
    }
    // trees near camp matter for wood
    for (const s of world.sources) {
      if (s.type === 'tree' && s.amount >= 1 && dist(s.x, s.y, camp.x, camp.y) <= R + 4) {
        observe(world, p, s);
        const b = p.beliefs[s.id];
        if (b) b.seen = -Math.floor(gen.range(40, 500));
      }
    }
    // water cells near camp
    for (let cy = 0; cy < Math.ceil(world.H / ACCESS_CELL); cy++) {
      for (let cx = 0; cx < cw; cx++) {
        const t = world.accessCell[cy * cw + cx];
        if (t < 0) continue;
        const tx = t % W;
        const ty = (t / W) | 0;
        if (dist(tx + 0.5, ty + 0.5, camp.x, camp.y) <= R + 6) {
          const id = waterBeliefId(cy * cw + cx);
          putBelief(p, { id, kind: 'water', x: tx + 0.5, y: ty + 0.5, amount: 0, max: 0, seen: -50, src: 'seen', from: 0, learned: -50 });
        }
      }
    }
    // each traveller noticed a few distant places on the way here (more for the curious)
    const nFar = Math.round(1 + 4 * p.traits.curiosity);
    for (let k = 0; k < nFar && far.length; k++) {
      const s = far[gen.int(far.length)];
      observe(world, p, s);
      const b = p.beliefs[s.id];
      if (b) b.seen = -Math.floor(gen.range(900, 4200));
      // they remember that stretch of land
      const R2 = 5;
      for (let dy = -R2; dy <= R2; dy++)
        for (let dx = -R2; dx <= R2; dx++) {
          const xx = s.x + dx;
          const yy = s.y + dy;
          if (xx >= 0 && yy >= 0 && xx < world.W && yy < world.H && dx * dx + dy * dy <= R2 * R2) p.explored[yy * W + xx] = 1;
        }
    }
    // explored mask around the camp
    const Rx = Math.ceil(R + 2);
    for (let dy = -Rx; dy <= Rx; dy++)
      for (let dx = -Rx; dx <= Rx; dx++) {
        const xx = Math.floor(camp.x) + dx;
        const yy = Math.floor(camp.y) + dy;
        if (xx >= 0 && yy >= 0 && xx < world.W && yy < world.H && dx * dx + dy * dy <= (R + 2) * (R + 2)) p.explored[yy * W + xx] = 1;
      }
  }
}

