import { isThreat } from './wildlife';
import { isBoundedNightWait } from './night_wait';
import {runsRulesVersion} from './rulesversion';
import { distToFootprint } from './registry';
import { faceToward, registerHandler } from './activities';
import type { WorkResult } from './activities';
import { addLog } from './events';
import { countBeliefs } from './knowledge';
import { noteHaunt } from './leisure';
import { nearLitFire } from './perception';

import { hyp } from './util';
// ───────────────────────── sleep ─────────────────────────
registerHandler('sleep', {
  availability: 0,
  pose: () => 'sleep',
  begin(world, p, a) {
    a.data.energy0 = p.needs.energy;
  },
  work(world, p, a): WorkResult {
    a.progress++;
    const n = p.needs;
    // a controller may ask to wake at a lower recovery target than the usual 94
    const lim = a.data.limit as Record<string, number> | undefined;
    if (lim && lim.untilEnergy !== undefined && n.energy >= lim.untilEnergy) {
      a.blocked = 'rested enough';
      return 'done';
    }
    if (n.energy >= 94) {
      a.blocked = 'rested';
      return 'done';
    }
    if (world.light > 0.55 && n.energy >= 62 && a.progress > 120) {
      a.blocked = 'morning came';
      return 'done';
    }
    if (n.thirst < 9) return 'partial:woke up parched';
    if (n.hunger < 7) return 'partial:woke up starving';
    if (n.warmth < 20) return 'partial:too cold to sleep';
    return 'continue';
  },
  onEnd(world, p, a) {
    const gained = Math.round(p.needs.energy - (a.data.energy0 ?? p.needs.energy));
    if (gained > 8) addLog(world, p, 'need', `Slept and recovered ${gained} energy.`);
  },
});

// ───────────────────────── rest / warm ─────────────────────────
registerHandler('rest', {
  availability: 0.9,
  pose: () => 'sit',
  begin(world, p, a) {
    a.duration = a.amount > 0 ? a.amount : 150;
  },
  work(world, p, a): WorkResult {
    if (isBoundedNightWait(world, a)) {
      const shelter = world.byId.get(a.targetId);
      if (!shelter || shelter.ent !== 'building') return 'fail:the shelter is no longer there';
      if (distToFootprint(shelter, p.x, p.y) > 3) return 'partial:no longer at the shelter';
      if (shelter.type === 'fire' && shelter.fuel <= 0) return 'partial:the fire went out';
      if (world.tick >= a.data.daylightAt) { a.blocked = 'daylight arrived'; return 'done'; }
      a.progress++;
      return 'continue';
    }
    if(a.data.projectWait&&runsRulesVersion(world,69)){
      const plan=p.intentions.find(i=>i.id===a.data.forPlan&&i.status==='active'&&i.project);
      if(!plan)return 'partial:the project is no longer active';
      const known=p.beliefs[a.targetId]?.ops;
      if(!known||known.client!==p.id||!known.burn)return 'partial:no longer expecting that batch';
      if(world.tick>=known.readyAt){a.blocked='time to check the batch';return 'done';}
    }
    a.progress++;
    if (a.progress >= a.duration) return 'done';
    // Resting for energy ends once the person is rested. Waiting out the weather in a home (need 'warmth') is also a `rest`, but is not
    // about energy: ending it because the person happens to be rested made them finish after one tick and decide again, every tick.
    if (a.need !== 'warmth' && !(a.data.projectWait&&runsRulesVersion(world,69)) && p.needs.energy >= 98) return 'done';
    return 'continue';
  },
});

registerHandler('warm', {
  availability: 0.95,
  pose: () => 'sit',
  begin(world, p, a) {
    a.duration = a.amount > 0 ? a.amount : 220;
    const f = nearLitFire(world, p.x, p.y, 8);
    if (f) {
      a.tx = f.x + 0.5;
      a.ty = f.y + 0.5;
    }
  },
  work(world, p, a): WorkResult {
    faceToward(p, a.tx, a.ty);
    a.progress++;
    if (a.progress >= a.duration) return 'done';
    if (!nearLitFire(world, p.x, p.y, 6)) return 'partial:the fire went out';
    return 'continue';
  },
});

// ───────────────────────── wander ─────────────────────────
registerHandler('wander', {
  availability: 1,
  pose: () => 'stand',
  begin(world, p, a) {
    a.duration = 18 + Math.floor(((p.id * 31 + world.tick) % 40));
    // version 27: they have arrived at a place they chose for spare time, so it counts as somewhere they have been lately
    if (a.data.haunt) noteHaunt(world, p, a.data.haunt);
  },
  work(world, p, a): WorkResult {
    a.progress++;
    return a.progress >= a.duration ? 'done' : 'continue';
  },
});

// ───────────────────────── explore ─────────────────────────
registerHandler('explore', {
  availability: 0.5,
  pose: () => 'stand',
  begin(world, p, a) {
    a.duration = 14;
    a.data.known0 = a.data.known0 ?? countBeliefs(p);
  },
  work(world, p, a): WorkResult {
    a.progress++;
    // look around
    p.heading += 0.09;
    return a.progress >= a.duration ? 'done' : 'continue';
  },
  onEnd(world, p, a, outcome) {
    p.lastExploreTick = world.tick;
    const gained = countBeliefs(p) - (a.data.known0 ?? 0);
    if (outcome === 'success' || outcome === 'partial') {
      addLog(world, p, 'info', gained > 0 ? `Explored ${a.data.where ?? 'new ground'} and noticed ${gained} new place${gained > 1 ? 's' : ''}.` : `Explored ${a.data.where ?? 'new ground'}; nothing new turned up.`);
    }
  },
});

// ───────────────────────── flee ─────────────────────────
registerHandler('flee', {
  availability: 0,
  pose: () => 'fear',
  begin(world, p, a) {
    a.duration = 90;
  },
  work(world, p, a): WorkResult {
    a.progress++;
    let threat = false;
    for (const s of p.seen) if (isThreat(world, s) && hyp(s.x - p.x, s.y - p.y) < 11) threat = true;
    if (!threat && (p.needs.safety > 55 || a.progress > a.duration)) return 'done';
    if (threat) {
      a.progress = Math.max(0, a.progress - 1);
      if (a.progress < 0) a.progress = 0;
    }
    return 'continue';
  },
  onEnd(world, p, a) {
    addLog(world, p, 'danger', 'Made it to safety.');
  },
});

// ───────────────────────── search / visit ─────────────────────────
registerHandler('search', {
  availability: 0.7,
  pose: () => 'stand',
  begin(world, p, a) {
    a.duration = 8;
  },
  work(world, p, a): WorkResult {
    a.progress++;
    p.heading += 0.12;
    return a.progress >= a.duration ? 'done' : 'continue';
  },
});
