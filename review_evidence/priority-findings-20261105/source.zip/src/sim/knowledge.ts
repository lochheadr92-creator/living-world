import {rememberGrave} from './personal_places';
import {ownedGearRules,ownedGearAt} from './gear_stock';
import { biological, conditionAt, ecologicalSign, hasEcology, rememberedGrowth } from './ecology';
import { deathStory, hasLocalDeath } from './death_knowledge';
import { SOURCE_REGROW } from './constants';
import {correctSourceExperience} from './source_learning';
import { checkAccount } from './checked_accounts';
import { cloneItems } from './economy';
import { facilitySnapshot,usableUnits } from './facilities';
import {textileGoods} from './textile_stock';
import { toolsHeldBy } from './toolreg';
import { noteBeliefWrite } from './transmission';
import { addLog } from './events';
import { SOURCE_NOUN } from './labels';
import { runsRulesVersion } from './rulesversion';
import type { Belief, BeliefKind, Entity, Items, Person, Source, World } from './types';

/** synthetic belief ids for coarse water-access cells (ids below 1e6 are real entities) */
export const WATER_ID_BASE = 1_000_000;
export const ACCESS_CELL = 4;

export function waterBeliefId(cellIdx: number): number {
  return WATER_ID_BASE + cellIdx;
}

export function isWaterBeliefId(id: number): boolean {
  return id >= WATER_ID_BASE;
}

function blank(id: number, kind: BeliefKind, x: number, y: number, tick: number): Belief {
  return { id, kind, x, y, amount: 0, max: 0, seen: tick, src: 'seen', from: 0, learned: tick };
}

/** Snapshot an entity as it is right now. Used when a person actually observes it. */
export function snapshotEntity(world: World, e: Entity, tick: number): Belief | null {
  switch (e.ent) {
    case 'source': {
      const b = blank(e.id, e.type, e.x + 0.5, e.y + 0.5, tick);
      b.amount = e.amount;
      b.max = e.max;
      if (hasEcology(world) && biological(e)) b.ecology = ecologicalSign(conditionAt(world, e.x, e.y));
      return b;
    }
    case 'building': {
      const b = blank(e.id, 'building', e.x + e.w / 2, e.y + e.h / 2, tick);
      b.btype = e.type;
      b.hh = e.hhId;
      b.cond = e.condition;
      b.fuel = e.fuel;
      if(e.hearth)b.hearth={fuel:null,heat:null,seen:tick};
      b.items = cloneItems(e.store.items);
      if (e.ops) b.ops = facilitySnapshot(world, e);
      const racked = toolsHeldBy(world, e.id);
      if (racked.length) b.tools = racked.map((t) => t.kind);
      return b;
    }
    case 'cart': {
      const b = blank(e.id, 'cart', e.x, e.y, tick);
      b.items = cloneItems(e.load);
      b.state = e.puller ? 'pulled' : 'parked';
      b.hh = e.ownerHh;
      return b;
    }
    case 'site': {
      const b = blank(e.id, 'site', e.x + e.w / 2, e.y + e.h / 2, tick);
      b.btype = e.type;
      b.hh = e.hhId;
      b.need = missingMaterials(e);
      b.progress = e.workTotal > 0 ? e.work / e.workTotal : 0;
      return b;
    }
    case 'plot': {
      const b = blank(e.id, 'plot', e.x + 0.5, e.y + 0.5, tick);
      b.state = e.state;
      b.progress = e.progress;
      b.hh = e.hhId;
      b.amount = e.stock;
      if (hasEcology(world)) {
        b.ecology = ecologicalSign(conditionAt(world, e.x, e.y));
        if (e.fallowUntil !== undefined) b.fallowUntil = e.fallowUntil;
      }
      return b;
    }
    case 'pile': {
      const b = blank(e.id, 'pile', e.x + 0.5, e.y + 0.5, tick);
      b.items = cloneItems(e.items);
      if(e.gear){const g=e.gear,t=world.tools.find(t=>t.id===g.toolId);b.items={};b.hh=g.hhId;b.state='gear';b.gear={kind:g.kind,toolId:g.toolId,hhId:g.hhId,readyAt:g.readyAt,state:g.state,checked:g.checked,bodyId:g.bodyId,wear:t?.wear??100,catch:e.items.fish??0};}
      if(e.carcass){b.state='carcass';b.hh=e.carcass.hhId;b.carcassParts={...e.carcass.remaining};}
      if(e.mealFood)b.hh=e.mealFood.hhId;
      if(e.estate)b.hh=e.estate.hhId;
      return b;
    }
    case 'grave': {
      return blank(e.id, 'grave', e.x + 0.5, e.y + 0.5, tick);
    }
    case 'animal': {
      if(e.sheep){const s=e.sheep,b=blank(e.id,'livestock',e.x,e.y,tick);b.sheep={hhId:s.hhId,sex:s.sex,adult:s.growth>=19200,hungry:s.food<=22,thirsty:s.water<=1,wool:s.wool,tether:s.tether?.condition??0,pregnant:!!s.pregnancy,breedAfter:s.breedAfter};return b;}
      if(e.type==='deer'&&world.settings.dynamics==='rich'&&runsRulesVersion(world,127)){const b=blank(e.id,'prey',e.x,e.y,tick);b.amount=1;b.max=1;return b;}
      const b = blank(e.id, 'danger', e.x, e.y, tick);
      b.amount = 1;
      return b;
    }
    default:
      return null;
  }
}

/** What a site still lacks (required minus delivered minus already used). */
export function missingMaterials(site: { required: Items; delivered: Items; used: Items }): Items {
  const need: Items = {};
  for (const k in site.required) {
    const key = k as keyof Items;
    const m = (site.required[key] ?? 0) - (site.delivered[key] ?? 0) - (site.used[key] ?? 0);
    if (m > 0) need[key] = m;
  }
  return need;
}

/** Store a belief and keep the per-kind index in step. All writes go through here. */
export function putBelief(p: Person, b: Belief): void {
  noteBeliefWrite(); // diagnostics only (transmission.ts); a no-op unless a run has switched them on
  const old = p.beliefs[b.id];
  p.beliefs[b.id] = b;
  if (!old) {
    (p.bykind[b.kind] ??= []).push(b.id);
  } else if (old.kind !== b.kind) {
    const arr = p.bykind[old.kind];
    if (arr) arr.splice(arr.indexOf(b.id), 1);
    (p.bykind[b.kind] ??= []).push(b.id);
  }
  // Moving animals are remembered as four dated sightings, not a growing global herd map.
  if(b.kind==='livestock'){const sightings=Object.values(p.beliefs).filter(x=>x.kind==='livestock').sort((a,b)=>b.seen-a.seen||b.id-a.id);for(const old of sightings.slice(12))delBelief(p,old.id);}
  if(b.kind==='prey'){const sightings=Object.values(p.beliefs).filter(x=>x.kind==='prey').sort((a,b)=>b.seen-a.seen||b.id-a.id);for(const old of sightings.slice(4))delBelief(p,old.id);}
}

export function delBelief(p: Person, id: number): void {
  const old = p.beliefs[id];
  if (!old) return;
  delete p.beliefs[id];
  const arr = p.bykind[old.kind];
  if (arr) {
    const i = arr.indexOf(id);
    if (i >= 0) arr.splice(i, 1);
  }
}

/** Insert or refresh a belief. Fresher information wins; hearsay never overrides a fresher personal observation. */
export function learn(p: Person, b: Belief): boolean {
  const old = p.beliefs[b.id];
  if (!old) {
    putBelief(p, b);
    return true;
  }
  if (b.seen >= old.seen) putBelief(p, b);
  return false;
}

export function forget(p: Person, id: number): void {
  delBelief(p, id);
}

/** rules 32+: log it when a source the person believed held 2+ units turns out bare or at most half full. */
function noteDepletedSource(world: World, p: Person, e: Source, b: Belief): void {
  const old = p.beliefs[e.id];
  if (!old || old.amount < 2) return;
  if (b.amount * 2 > old.amount) return; // still more than half of what they believed
  const age = ((world.tick - old.seen) / 600).toFixed(1);
  const who = old.src === 'told'
    ? `${old.from ? (world.byId.get(old.from) as Person | undefined)?.name ?? 'someone' : 'someone'} had described`
    : 'I had remembered';
  const state = b.amount <= 0 ? 'was bare' : `was down to ${b.amount}`;
  addLog(world, p, 'info', `The ${SOURCE_NOUN[e.type] ?? e.type} ${who} (about ${old.amount}, ${age} min old) ${state} when I got close.`);
}

/** Direct observation of one entity by one person. Returns true if this was new to them. */
export function observe(world: World, p: Person, e: Entity): boolean {
  if (hasLocalDeath(world) && e.ent==='grave' && e.death && !p.indoors && p.pose!=='sleep' && Math.hypot(p.x-e.x,p.y-e.y)<=10) deathStory(world,p,e.death,'grave');
  if(e.ent==='grave')rememberGrave(world,p,e);
  const b = snapshotEntity(world, e, world.tick);
  if (!b) return false;
  if(e.ent==='building'&&world.settings.dynamics==='rich'&&runsRulesVersion(world,124)&&textileGoods(world).some(k=>(e.store.items[k]??0)>0)){
    b.textileStock={observer:p.id,items:Object.fromEntries(textileGoods(world).map(k=>[k,usableUnits(world,e,p,k)]))};
  }
  if(e.ent==='building'&&e.hearth){
    if(p.indoors===e.id)b.hearth={...e.hearth,seen:world.tick};
    else if(p.beliefs[e.id]?.hearth)b.hearth={...p.beliefs[e.id].hearth!};
  }
  if(ownedGearRules(world,'net')&&(e.ent==='building'||e.ent==='cart'||e.ent==='pile')&&!(e.ent==='pile'&&e.gear)){
    b.gearStock={observer:p.id,items:Object.fromEntries((['net','trap'] as const).map(k=>[k,Math.min(ownedGearAt(world,p,e.id,k).length,e.ent==='building'?usableUnits(world,e,p,k):Infinity)]))};
  }
  b.origin = p.id;
  b.hops = 0;
  if(e.ent==='source')correctSourceExperience(world,p,e.id,e.amount);
  // rules 107 (checked_accounts.ts): a told account of this place, now seen in person, is held to its teller on grounds
  if (e.ent === 'source') { const told = p.beliefs[e.id]; if (told && told.src === 'told') checkAccount(world, p, told, e.amount, estimatedAmount(world, told)); }
  if (runsRulesVersion(world, 32) && e.ent === 'source') noteDepletedSource(world, p, e, b);
  return learn(p, b);
}

/** People understand roughly how fast things regrow, so a stale "empty" memory slowly turns hopeful. */
export function estimatedAmount(world: World, b: Belief): number {
  if (b.kind === 'berry_bush' || b.kind === 'fruit_tree' || b.kind === 'wild_grain' || b.kind === 'fish_spot' || b.kind === 'rock') {
    const every = SOURCE_REGROW[b.kind as Source['type']];
    if (every > 0) {
      const gained = Math.floor((world.tick - b.seen) * rememberedGrowth(world, b) / every);
      return Math.min(b.max, b.amount + Math.max(0, gained));
    }
  }
  return b.amount;
}

export function beliefAge(world: World, b: Belief): number {
  return world.tick - b.seen;
}

export function noteFailure(world: World, p: Person, id: number, reason: string): void {
  const f = p.failures[id];
  if (f) {
    delete f.resolved;
    f.tick = world.tick;
    f.reason = reason;
    f.count++;
  } else {
    p.failures[id] = { tick: world.tick, reason, count: 1 };
  }
}

export function recentFailure(world: World, p: Person, id: number, within: number): { tick: number; reason: string; count: number } | undefined {
  const f = p.failures[id];
  if (f && !f.resolved && world.tick - f.tick < within) return f;
  return undefined;
}

/** Operational readers must not mistake retained, corrected route history for a present failure. */
export function currentFailure(world: World, p: Person, id: number): Person['failures'][number] | undefined {
  const f = p.failures[id];
  return f?.resolved && runsRulesVersion(world, 77) ? undefined : f;
}

export function clearFailure(p: Person, id: number): void {
  if(p.failures[id]?.route){p.failures[id].resolved=true;return;}
  delete p.failures[id];
}

export function beliefsOfKind(p: Person, ...kinds: BeliefKind[]): Belief[] {
  const out: Belief[] = [];
  for (const kind of kinds) {
    const ids = p.bykind[kind];
    if (ids) for (const id of ids) out.push(p.beliefs[id]);
  }
  return out;
}

export function countBeliefs(p: Person): number {
  let n = 0;
  for (const k in p.bykind) n += p.bykind[k as BeliefKind]?.length ?? 0;
  return n;
}

/** Is there an entity-world mismatch the person would notice on arrival? */
export function beliefStale(world: World, b: Belief): boolean {
  return !isWaterBeliefId(b.id) && !world.byId.has(b.id);
}
