import {mayShareType} from './shared_projects';
import {rodCraftBlock} from './fishing_rods';
import {hasBrewing} from './brewing';
import {workshopSiteProblem} from './recovered_workshops';
import {cellarSiteConflict} from './cellars';
import {wellSiteConflict} from './wells';
import {isTextile} from './clothing';
import {hasLivedLife} from './lived_life';
import {hearthInstallBlock,isHearthAction,hearthFuelBegin,hearthFuelWork} from './hearth';
import {hasPromiseTargets,observePromiseTarget,finishedSiteHere} from './promise_targets';
import {hasPromiseKnowledge} from './promise_knowledge';
import {homeLayoutConflict} from './home_replacement';
import { preservesAccess, allSitesNeedAccess } from './construction_access';
import { footprintOccupied, hasLayoutClaims, layoutClaimBlock, LAYOUT_OCCUPANCY_WAIT } from './layout_claims';
import { proposeProject, creditProject, mayWorkProject, hasTownships } from './townships';
import { faceToward, registerHandler } from './activities';
import type { WorkResult } from './activities';
import { BUILD_DEF, FIRE_MAX_FUEL, REPAIR_FALLBACK_GAIN, REPAIR_GAIN, REPAIR_USES, SKILL_MAX, TOOL_RECIPE, WEIGHT, WORK, isHomeType, isSolidHome } from './constants';
import { buildingLabel, completeSite, createSite } from './buildings';
import { notePractice, onSharedWork } from './apprentice';
import { riskOfHarm } from './life';
import { addItem, claimSlot, consume, invRoom, ledgerCreate, weightOf } from './economy';
import { runsRulesVersion } from './rulesversion';
import { addEvent, addFx, addLog } from './events';
import { creditMade, creditRepair } from './intent';
import { noteSpearMade } from './defence';
import { householdOf } from './buildings';
import { missingMaterials, observe, delBelief } from './knowledge';
import { isFacilityType } from './recipes';
import { isFreeLand } from './registry';
import { ORDINARY_RULES, rulesOf, within } from './rules';
import { mintTool, taskMultiplier, wearFor } from './tools';
import { carryCap } from './people';
import type { Building, Items, ItemKind, Person, Site, ToolKind, World } from './types';
import {fuelItem,fuelValue,hasOffcuts} from './offcuts';
import {hasWarmthDuty,fuelAvailable} from './warmth_duty';
import {hasRepairDuty,repairSupplies} from './repair_duty';
import {settleFirePromise} from './responsibilities';
import { clamp } from './util';
import { itemsToText } from './people';
import {projectAvailable} from './project_step';

// ───────────────────────── build ─────────────────────────
function allowedFraction(site: Site): number {
  let f = 1;
  for (const k in site.required) {
    const need = site.required[k as ItemKind] ?? 0;
    if (need <= 0) continue;
    const have = (site.delivered[k as ItemKind] ?? 0) + (site.used[k as ItemKind] ?? 0);
    f = Math.min(f, have / need);
  }
  return clamp(f, 0, 1);
}

function consumeForProgress(world: World, site: Site): void {
  const frac = site.work / site.workTotal;
  for (const k in site.required) {
    const key = k as ItemKind;
    const want = Math.ceil(frac * (site.required[key] ?? 0) - 1e-9);
    const toUse = Math.min(want - (site.used[key] ?? 0), site.delivered[key] ?? 0);
    if (toUse > 0) {
      consume(world, site.delivered, key, toUse, 'construction: ' + site.type.replace('_', ' '));
      addItem(site.used, key, toUse);
    }
  }
}

export function siteStatus(site: Site): string {
  const miss = missingMaterials(site);
  const txt = Object.keys(miss).length ? itemsToText(miss) : '';
  return txt;
}

registerHandler('build', {
  availability: 0.3,
  pose: () => 'build',
  begin(world, p, a) {
    const site = world.byId.get(a.targetId);
    if (!site || site.ent !== 'site') {
      const finished=finishedSiteHere(world,p,a.targetId,a.tx,a.ty);
      observePromiseTarget(world,p,a.targetId,a.tx,a.ty);
      delBelief(p, a.targetId);
      return finished?'the building is already complete; no further construction is needed':'the site is already finished or gone';
    }
    if (!mayWorkProject(world, p, site.id)) return 'has not agreed to this public project';
    observe(world, p, site);
    const id = claimSlot(world, p.id, site, a.expire - world.tick + 10);
    if (!id) return 'too many people are already working there';
    a.claims.push(id);
    a.tx = site.x + site.w / 2;
    a.ty = site.y + site.h / 2;
    a.data.waited = 0;
    if(hasLivedLife(world))a.data.siteType=site.type;
  },
  work(world, p, a): WorkResult {
    const site = world.byId.get(a.targetId);
    if (!site || site.ent !== 'site') {
      if(hasPromiseTargets(world)){
        const finished=finishedSiteHere(world,p,a.targetId,a.tx,a.ty);
        observePromiseTarget(world,p,a.targetId,a.tx,a.ty);if(hasLivedLife(world))delBelief(p,a.targetId);
        const reason=finished?'the building is complete; my contribution is the work I actually did':'the site is no longer here; its fate is unknown';
        return a.cycle>0?`partial:${reason}`:`fail:${reason}`;
      }
      return a.cycle > 0 ? 'done' : 'fail:the site is gone';
    }
    if (!mayWorkProject(world, p, site.id)) return 'fail:participation withdrawn';
    if(site.improvement==='hearth'){
      const block=hearthInstallBlock(world,p,site.upgradeOf??0);
      if(block)return `fail:${block}`;
    }
    faceToward(p, a.tx, a.ty);
    const cap = site.workTotal * Math.min(1, 0.06 + allowedFraction(site));
    if (site.work >= cap - 1e-9) {
      const miss = siteStatus(site);
      a.blocked = miss ? `waiting for ${miss}` : 'waiting';
      site.status = a.blocked;
      a.data.waited++;
      if (a.data.waited > 80) return `partial:no materials to work with (${miss})`;
      // standing about is still an honest, visible state
      return 'continue';
    }
    a.data.waited = 0;
    a.blocked = '';
    const rate = (p.skills.build * (p.needs.energy < 25 ? 0.75 : 1) * (1 - 0.1 * world.weather.rain)) / taskMultiplier(world, p, 'build');
    const previousWork = site.work;
    site.work = Math.min(site.workTotal, site.work + rate);
    creditProject(world, p, site.id, null, site.work - previousWork);
    site.lastWorkTick = world.tick;
    site.status = 'under construction';
    a.progress++;
    a.cycle++;
    wearFor(world, p, 'build', 1);
    if (a.cycle % 50 === 0) riskOfHarm(world, p, 'build', 0.003);
    if (site.contrib) site.contrib[p.hhId] = (site.contrib[p.hhId] ?? 0) + 1 / 25;
    p.skills.build = Math.min(SKILL_MAX, p.skills.build + 0.0004);
    notePractice(world, p, 'build', 0.0004);
    consumeForProgress(world, site);
    for (const c of p.commitments) if (c.status === 'active' && c.siteId === site.id) c.contrib = (c.contrib ?? 0) + 1;
    if (a.progress % 14 === 7) addFx(world, 'hammer', site.x + site.w / 2, site.y + site.h / 2, 0);
    if (site.work >= site.workTotal - 1e-9) {
      const b = completeSite(world, site, p);
      p.stats.built++;
      // everyone who put work into it finished it together (rich only: where a builder may take on an apprentice)
      const crew = world.persons.filter((q) => q.alive && (q === p || q.commitments.some((c) => c.siteId === site.id && (c.contrib ?? 0) > 0)));
      onSharedWork(world, crew, 'build');
      addLog(world, p, 'work', site.improvement==='hearth'?`Finished fitting a hearth in the ${buildingLabel(b.type)}.`:`Finished building the ${buildingLabel(b.type)}.`);
      observe(world, p, b);
      observePromiseTarget(world,p,site.id,site.x+site.w/2,site.y+site.h/2,'completed here');
      delBelief(p, site.id);
      return 'done';
    }
    return 'continue';
  },
  onEnd(world, p, a, outcome, detail) {
    if (a.cycle > 0 && outcome !== 'success') addLog(world, p, 'work', `Worked on the building site for a while (${detail}).`);
  },
});

// ───────────────────────── repair ─────────────────────────
/** Which of their materials a person would mend this building with: the proper one if they have it, else plain wood (poorer work on a finer building). */
export function repairMaterial(b: { type: Building['type'] }, inv: Items): { item: ItemKind; gain: number } | null {
  const pref = REPAIR_USES[b.type];
  if (pref && (inv[pref] ?? 0) > 0) return { item: pref, gain: REPAIR_GAIN };
  if ((inv.wood ?? 0) > 0) return { item: 'wood', gain: pref ? REPAIR_FALLBACK_GAIN : REPAIR_GAIN };
  return null;
}

registerHandler('repair', {
  availability: 0.35,
  pose: () => 'build',
  begin(world, p, a) {
    const b = world.byId.get(a.targetId);
    if (!b || b.ent !== 'building') {
      observePromiseTarget(world,p,a.targetId,a.tx,a.ty);
      delBelief(p, a.targetId);
      return 'it is gone';
    }
    observe(world, p, b);
    if (!repairMaterial(b, hasRepairDuty(world)?repairSupplies(world,p,b.id):p.inv)) return hasRepairDuty(world)?'nothing available to patch it with':'nothing to patch it with';
    if (b.condition > 90) return 'it is in good shape already';
    a.tx = b.x + b.w / 2;
    a.ty = b.y + b.h / 2;
    a.duration = Math.round((WORK.repair * taskMultiplier(world, p, 'repair')) / p.skills.build);
  },
  work(world, p, a): WorkResult {
    const b = world.byId.get(a.targetId);
    if (!b || b.ent !== 'building') {observePromiseTarget(world,p,a.targetId,a.tx,a.ty);return 'fail:it is gone';}
    if(hasRepairDuty(world)&&b.condition>90)return a.cycle>0?'partial:it is in good shape already':'fail:it is in good shape already';
    faceToward(p, a.tx, a.ty);
    a.progress++;
    if (a.progress % 14 === 7) addFx(world, 'hammer', a.tx, a.ty, 0);
    if (a.progress < a.duration) return 'continue';
    const mat = repairMaterial(b, hasRepairDuty(world)?repairSupplies(world,p,b.id):p.inv);
    if (!mat) {const reason=hasRepairDuty(world)&&repairMaterial(b,p.inv)?'repair materials are reserved':'ran out of materials';return a.cycle>0?`partial:${reason}`:`fail:${reason}`;}
    consume(world, p.inv, mat.item, 1, 'repairs');
    const before = b.condition;
    b.condition = Math.min(100, b.condition + mat.gain);
    // the plan learns what this person's own hands actually put back, where it happens
    creditRepair(p, b.id, b.condition - before);
    wearFor(world, p, 'repair', a.duration);
    a.cycle++;
    if(hasPromiseKnowledge(world))for(const c of p.commitments)if(c.status==='active'&&c.kind==='work'&&c.destKind==='building'&&c.destId===b.id&&c.milestone!=='fire kept')c.contrib=(c.contrib??0)+40;
    a.progress = 0;
    p.skills.build = Math.min(SKILL_MAX, p.skills.build + 0.003);
    notePractice(world, p, 'build', 0.003);
    observe(world, p, b);
    if (b.condition >= 92) return 'done';
    if (!repairMaterial(b, hasRepairDuty(world)?repairSupplies(world,p,b.id):p.inv)) return hasRepairDuty(world)&&repairMaterial(b,p.inv)?'partial:remaining repair materials are reserved':'partial:ran out of materials';
    return 'continue';
  },
  onEnd(world, p, a) {
    const b = world.byId.get(a.targetId);
    if (a.cycle > 0 && b && b.ent === 'building') {
      if(!hasPromiseKnowledge(world))for (const c of p.commitments) if (c.status === 'active' && c.kind === 'work' && c.destKind === 'building' && c.destId === b.id) c.contrib = (c.contrib ?? 0) + 40 * a.cycle;
      addLog(world, p, 'work', `Repaired the ${buildingLabel(b.type)} (now ${Math.round(b.condition)}% sound).`);
      if (b.condition >= 92) addEvent(world, 'build', `${p.name} repaired a ${buildingLabel(b.type)}.`, [p.id], b.x, b.y);
    }
  },
});

// ───────────────────────── craft ─────────────────────────
let craftCapacity = true;
export const craftCapacityOn = (): boolean => craftCapacity;
export function setCraftCapacity(on: boolean): void { craftCapacity = on; }
/** The completed tool replaces its consumed materials. No goods move during this check. */
export function craftedToolFits(world: World, p: Person, tool: ToolKind): boolean {
  if (!craftCapacity || world.settings.dynamics !== 'rich' || !runsRulesVersion(world, 58)) return invRoom(world, p, tool) >= 1;
  const r = TOOL_RECIPE[tool];
  return weightOf(p.inv) - r.wood * WEIGHT.wood - r.stone * WEIGHT.stone + WEIGHT[tool] <= carryCap(world, p) + 1e-9;
}

registerHandler('craft', {
  availability: 0.35,
  pose: () => 'craft',
  begin(world, p, a) {
    const tool = a.data.tool as ToolKind;
    if(tool==='rod'){const block=rodCraftBlock(world,p,a);if(block)return block;}
    if(isTextile(tool))return 'textiles must be woven at a timber yard';
    const r = TOOL_RECIPE[tool];
    if ((p.inv.wood ?? 0) < r.wood || (p.inv.stone ?? 0) < r.stone) return 'missing materials';
    const b = world.byId.get(a.targetId);
    if (!b || b.ent !== 'building') return 'no workspace';
    a.tx = b.x + b.w / 2;
    a.ty = b.y + b.h / 2;
    a.duration = Math.round(r.work / p.skills.craft);
  },
  work(world, p, a): WorkResult {
    faceToward(p, a.tx, a.ty);
    a.progress++;
    if (a.progress % 12 === 6) addFx(world, 'hammer', p.x, p.y, 0);
    if (a.progress < a.duration) return 'continue';
    const tool = a.data.tool as ToolKind;
    if(tool==='rod'){const block=rodCraftBlock(world,p,a);if(block)return `fail:${block}`;}
    if(isTextile(tool))return 'fail:textiles must be woven at a timber yard';
    const r = TOOL_RECIPE[tool];
    if ((p.inv.wood ?? 0) < r.wood || (p.inv.stone ?? 0) < r.stone) return 'fail:the materials went missing';
    if(a.data.projectCraft&&runsRulesVersion(world,69)){
      const plan=p.intentions.find(i=>i.id===a.data.projectCraft&&i.status==='active'&&i.project);
      if(!plan)return 'fail:the project was cancelled';
      if(!plan.project!.nodes.some(n=>n.method==='hand'&&n.item===tool))return 'fail:that tool is not a project prerequisite';
      if(projectAvailable(world,p,plan,'wood')<r.wood||projectAvailable(world,p,plan,'stone')<r.stone)return 'fail:the materials are needed for another plan or promise';
    }
    if (!craftedToolFits(world, p, tool)) return 'fail:no room to carry it';
    consume(world, p.inv, 'wood', r.wood, 'crafting: ' + tool);
    consume(world, p.inv, 'stone', r.stone, 'crafting: ' + tool);
    mintTool(world, tool, 0, p.hhId, p.id, p.inv, p.id, 'crafted: ' + tool);
    // a plan that meant to make this learns that these hands made it, here, where it happened
    creditMade(p, tool);
    if (tool === 'spear') noteSpearMade();
    p.stats.crafted++;
    p.skills.craft = Math.min(SKILL_MAX, p.skills.craft + 0.02);
    notePractice(world, p, 'craft', 0.02);
    addLog(world, p, 'work', `Made ${/^[aeiou]/.test(tool) ? 'an' : 'a'} ${tool}.`);
    if (world.tick - (world.stats.lastCraftEvent ?? -9999) > 500) {
      world.stats.lastCraftEvent = world.tick;
      addEvent(world, 'build', `${p.name} made ${/^[aeiou]/.test(tool) ? 'an' : 'a'} ${tool}.`, [p.id], p.x, p.y);
    }
    addFx(world, 'sparkle', p.x, p.y, 0);
    return 'done';
  },
});

// ───────────────────────── lay out a site ─────────────────────────
/**
 * Homes, fires and the storehouse: as many as four at a time, so the roof over a household never waits on a workshop.
 * That is the ordinary world's limit; a world with scaled rules (rules.ts) allows more, and counts them near where a new one would go.
 */
export const MAX_BASIC_SITES = ORDINARY_RULES.maxBasicSites;
/** Workshops, halls, granaries and house rebuilds are a settlement's improvement projects; only so many can be carried at once. */
export function projectLimit(world: World): number {
  const r = rulesOf(world);
  return world.persons.length >= r.projectsRaisedAt ? r.projectsRaised : r.projectsBase;
}
export const isProjectSite = (s: { type: Building['type']; upgradeOf?: number }): boolean => isFacilityType(s.type) || !!s.upgradeOf;
/** communal projects (workshops, halls, granaries) and household house rebuilds are counted apart: neither crowds out the other */
export function projectsUnderWay(world: World, upgrades = false, near?: Spot): number {
  return sitesNear(world, near, (s) => isProjectSite(s) && !!s.upgradeOf === upgrades);
}

export interface Spot {
  x: number;
  y: number;
}

/** sites matching `pick` that count as being in the same settlement as `near` (every site, if there is no `near` or the rules count the whole world) */
function sitesNear(world: World, near: Spot | undefined, pick: (s: Site) => boolean): number {
  const radius = near ? rulesOf(world).siteRadius : Infinity;
  let n = 0;
  for (const s of world.sites) if (pick(s) && (radius === Infinity || within(radius, near!.x, near!.y, s.x + s.w / 2, s.y + s.h / 2))) n++;
  return n;
}

/** open sites of any kind in the same settlement as `near` */
export function openSitesNear(world: World, near?: Spot): number {
  return sitesNear(world, near, () => true);
}

/** The settlement is only so big: the rules that stop a duplicate or a pile-up of projects. Returns why not, or null. */
export function siteConflict(world: World, type: Building['type'], hh: number, upgradeOf = 0, depositId = 0, at?: Spot): string | null {
  if(type==='brewery'&&!hasBrewing(world))return 'brewing is unavailable in these rules';
  {const block=workshopSiteProblem(world,type,depositId,at?.x??NaN,at?.y??NaN);if(block)return block;}
  if(type==='cellar'){const why=cellarSiteConflict(world,hh);if(why)return why;}
  if(type==='well'){const why=wellSiteConflict(world,at?.x??NaN,at?.y??NaN);if(why)return why;}
  const housing=homeLayoutConflict(world,type,hh,upgradeOf);if(housing)return housing;
  const rules = rulesOf(world);
  if (isFacilityType(type) || upgradeOf) {
    if (projectsUnderWay(world, !!upgradeOf, at) >= projectLimit(world)) return 'enough improvement projects are under way already';
  } else if (sitesNear(world, at, (s) => !isProjectSite(s)) >= rules.maxBasicSites) return 'too many projects under way already';
  if (upgradeOf) {
    const old = world.byId.get(upgradeOf);
    if (!old || old.ent !== 'building') return 'the home is gone';
    if (old.upgrading) return 'it is already being rebuilt';
    return null;
  }
  if (isFacilityType(type) || type === 'storehouse') {
    // As many of each kind of workplace as the settlement is allowed, and no more (a second quarry only at a different outcrop).
    // With scaled rules only what stands within the settlement radius of where this one would go counts, and the allowance is one
    // for every ordinary camp's worth of founders: the ordinary world's allowance is 1, which is the rule it always had.
    const radius = at ? rules.facilityRadius : Infinity;
    const allowed = at ? rules.facilityAllowance : 1;
    const near = (x: number, y: number): boolean => radius === Infinity || within(radius, at!.x, at!.y, x, y);
    let standing = 0;
    let started = 0;
    for (const b of world.buildings) if (b.type === type && (type !== 'quarry' && type !== 'mine' || (b.ops?.depositId ?? 0) === depositId) && near(b.x + b.w / 2, b.y + b.h / 2)) standing++;
    for (const s of world.sites) if (s.type === type && (type !== 'quarry' && type !== 'mine' || (s.depositId ?? 0) === depositId) && near(s.x + s.w / 2, s.y + s.h / 2)) started++;
    if (standing + started >= allowed) return standing >= allowed ? `there is already a ${BUILD_DEF[type].label}` : `a ${BUILD_DEF[type].label} is already being built`;
    return null;
  }
  // homes and fires: one project at a time per household
  if (world.sites.some((s) => s.hhId === hh && (isHomeType(s.type) || s.type === 'fire') && !s.upgradeOf)) return 'someone in the household already started building';
  return null;
}

registerHandler('plan_site', {
  availability: 0.4,
  pose: () => 'build',
  begin(world, p, a) {
    const claimBlock = layoutClaimBlock(world, p, a);
    if (claimBlock) return claimBlock;
    const type = a.data.type as Building['type'];
    const d = BUILD_DEF[type];
    const sx = a.data.sx as number;
    const sy = a.data.sy as number;
    const up = (a.data.upgradeOf as number) ?? 0;
    if(a.data.improvement==='hearth'){
      const block=hearthInstallBlock(world,p,up);if(block)return block;
    }
    if (!up) for (let yy = sy; yy < sy + d.h; yy++) for (let xx = sx; xx < sx + d.w; xx++) if (!isFreeLand(world, xx, yy)) return 'the spot is no longer free';
    // someone may have started a project while this person was walking over
    const why = siteConflict(world, type, a.data.hh as number, up, (a.data.depositId as number) ?? 0, { x: sx + d.w / 2, y: sy + d.h / 2 });
    if (why) return why;
    a.duration = 26;
    a.tx = sx + d.w / 2;
    a.ty = sy + d.h / 2;
  },
  work(world, p, a): WorkResult {
    faceToward(p, a.tx, a.ty);
    a.progress++;
    if (a.progress < a.duration) return 'continue';
    const type = a.data.type as Building['type'];
    const d = BUILD_DEF[type];
    const sx = a.data.sx as number;
    const sy = a.data.sy as number;
    const up = (a.data.upgradeOf as number) ?? 0;
    if (!up) for (let yy = sy; yy < sy + d.h; yy++) for (let xx = sx; xx < sx + d.w; xx++) if (!isFreeLand(world, xx, yy)) return 'fail:someone built there first';
    const why = siteConflict(world, type, a.data.hh as number, up, (a.data.depositId as number) ?? 0, { x: sx + d.w / 2, y: sy + d.h / 2 });
    if (why) return `fail:${why}`;
    const claimBlock = layoutClaimBlock(world, p, a);
    if (claimBlock) return `fail:${claimBlock}`;
    if (!up && (allSitesNeedAccess(world) || (type === 'storehouse' && hasTownships(world))) && !preservesAccess(world, sx, sy, d.w, d.h)) {
      if (hasLayoutClaims(world) && footprintOccupied(world, sx, sy, d.w, d.h)) {
        a.progress = a.duration;
        a.data.layoutWaitSince ??= world.tick;
        a.blocked = 'waiting for someone to clear the proposed footprint';
        if (world.tick - a.data.layoutWaitSince < LAYOUT_OCCUPANCY_WAIT) return 'continue';
        return 'fail:the proposed footprint stayed occupied; a new layout is needed';
      }
      return 'fail:the footprint would obstruct access';
    }
    if (hasLayoutClaims(world)) { delete a.data.layoutWaitSince; a.blocked = ''; }
    if(a.data.improvement==='hearth'){
      const block=hearthInstallBlock(world,p,up);if(block)return `fail:${block}`;
    }
    if(a.data.communal&&!mayShareType(world,type))return 'fail:this building cannot be a shared project';
    const site = createSite(world, type, sx, sy, type==='well'||a.data.communal?0:a.data.hh as number, p.id, { upgradeOf: up || undefined, depositId: (a.data.depositId as number) || undefined,...(a.data.improvement==='hearth'?{improvement:'hearth' as const}:{}) });
    proposeProject(world, p, site, a.goal, a.data.communal===true);
    observe(world, p, site);
    const hh = householdOf(world, p);
    const verb = site.improvement==='hearth'?'marked out an indoor hearth for the':up ? `marked out the rebuilding of their ${buildingLabel((world.byId.get(up) as Building).type)} as a` : 'marked out a';
    addEvent(world, 'build', `${p.name} ${verb} ${buildingLabel(type)}${a.data.communal&&runsRulesVersion(world,144)?' for shared use':hh ? ` for the ${hh.name} household` : ''}.`.replace('a a ', 'a '), [p.id], sx, sy);
    addLog(world, p, 'work', site.improvement==='hearth'?'Marked out an indoor hearth for our home.':up ? `Marked out the ${buildingLabel(type)} that will replace our home.` : `Marked out a spot for a ${buildingLabel(type)}.`);
    addFx(world, 'built', site.x + site.w / 2, site.y + site.h / 2, 0);
    a.targetId = site.id;
    return 'done';
  },
});

// ───────────────────────── keep a fire going ─────────────────────────
registerHandler('fuel_fire', {
  availability: 0.5,
  pose: () => 'store',
  begin(world, p, a) {
    if(isHearthAction(world,a))return hearthFuelBegin(world,p,a);
    const f = world.byId.get(a.targetId);
    if (!f || f.ent !== 'building' || f.type !== 'fire') {
      observePromiseTarget(world,p,a.targetId,a.tx,a.ty);
      delBelief(p, a.targetId);
      return 'the fire is gone';
    }
    if(a.data.fuelItem!==undefined&&(!hasOffcuts(world)||a.data.fuelItem!=='offcuts'))return 'invalid fire fuel';
    if ((p.inv[fuelItem(world,a)] ?? 0) < 1) return 'no '+fuelItem(world,a)+' to add';
    if(hasWarmthDuty(world)&&fuelAvailable(world,p,fuelItem(world,a))<1)return 'the fuel is reserved for another plan or promise';
    if (f.fuel >= FIRE_MAX_FUEL * 0.8) {
      observe(world, p, f); // someone has already seen to it
      return 'it is burning well already';
    }
    a.tx = f.x + 0.5;
    a.ty = f.y + 0.5;
    a.duration = 12;
    a.data.wasOut = f.fuel <= 0;
    observe(world, p, f);
  },
  work(world, p, a): WorkResult {
    if(isHearthAction(world,a))return hearthFuelWork(world,p,a);
    const f = world.byId.get(a.targetId);
    if (!f || f.ent !== 'building') {observePromiseTarget(world,p,a.targetId,a.tx,a.ty);return 'fail:the fire is gone';}
    faceToward(p, a.tx, a.ty);
    a.progress++;
    if (a.progress < a.duration) return 'continue';
    const item=fuelItem(world,a);
    if(hasWarmthDuty(world)&&f.fuel>=FIRE_MAX_FUEL*0.8){observe(world,p,f);return a.cycle>0?'done':'fail:it is burning well already';}
    if(hasWarmthDuty(world)&&fuelAvailable(world,p,item)<1)return a.cycle>0?'partial:remaining fuel is reserved':'fail:the fuel is reserved for another plan or promise';
    if (consume(world, p.inv, item, 1, 'fuel for the fire') < 1) return a.cycle > 0 ? 'done' : `fail:no ${item} to add`;
    f.fuel = Math.min(FIRE_MAX_FUEL, f.fuel + fuelValue(item));
    if(hasPromiseTargets(world))p.cooldowns['fedfire'+f.id]=world.tick;
    a.cycle++;
    a.progress = 0;
    addFx(world, 'ember', f.x + 0.5, f.y + 0.5, 0);
    observe(world, p, f);
    if(hasWarmthDuty(world))for(const c of p.commitments)if(c.destId===f.id)settleFirePromise(world,p,c);
    if (a.cycle >= a.amount || f.fuel >= FIRE_MAX_FUEL * 0.8 || (p.inv[item] ?? 0) < 1) return 'done';
    return 'continue';
  },
  onEnd(world, p, a) {
    if(isHearthAction(world,a)){
      if(a.cycle>0)addLog(world,p,'work',`Fed the indoor hearth with ${a.cycle} ${fuelItem(world,a)}.`);
      return;
    }
    const f = world.byId.get(a.targetId);
    if (a.cycle > 0 && f && f.ent === 'building') {
      addLog(world, p, 'work', fuelItem(world,a)==='offcuts'?`Fed the fire with ${a.cycle} recovered offcut fuel bundle${a.cycle>1?'s':''}.`:`Fed the fire with ${a.cycle} log${a.cycle > 1 ? 's' : ''}.`);
      // noted for a promise to keep the fire going (responsibilities.ts; rich only, so an authored world's record is untouched)
      if (world.settings.dynamics === 'rich') p.cooldowns['fedfire' + f.id] = world.tick;
      if (a.data.wasOut) addEvent(world, 'survival', `${p.name} relit the fire.`, [p.id], f.x, f.y);
    }
  },
});

// ───────────────────────── move in to an empty house ─────────────────────────
registerHandler('claim_home', {
  availability: 0.4,
  pose: () => 'stand',
  begin(world, p, a) {
    const b = world.byId.get(a.targetId);
    if (!b || b.ent !== 'building') return 'it is gone';
    if (b.hhId !== 0) return 'someone has already moved in';
    a.duration = 16;
    a.tx = b.x + b.w / 2;
    a.ty = b.y + b.h / 2;
  },
  work(world, p, a): WorkResult {
    faceToward(p, a.tx, a.ty);
    a.progress++;
    if (a.progress < a.duration) return 'continue';
    const b = world.byId.get(a.targetId);
    if (!b || b.ent !== 'building' || b.hhId !== 0) return 'fail:someone has already moved in';
    const hh = householdOf(world, p);
    if (!hh) return 'fail:no household';
    b.hhId = hh.id;
    const cur = hh.homeId ? world.byId.get(hh.homeId) : null;
    if (!cur || (cur.ent === 'building' && (cur.type === 'lean_to' || isSolidHome(b.type)))) hh.homeId = b.id;
    addEvent(world, 'survival', `${p.name} moved into an empty ${buildingLabel(b.type)}.`, [p.id], b.x, b.y);
    observe(world, p, b);
    return 'done';
  },
});

void carryCap;
void ((): Person | null => null);
