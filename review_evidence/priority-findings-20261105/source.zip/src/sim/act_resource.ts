import {hasRods} from './fishing_rods';
import {communalSpare,communalStockBlock,communalRoom} from './communal_stock';
import {cellarAccess} from './cellars';
import {isWellAction,wellSource} from './wells';
import {takeNutrition} from './nourishment';
import {ownedGearRules,ownedGearAt} from './gear_stock';
import {pileAccessBlocker} from './pile_access';
import {runsPreservation,preservationCollectionReason,PRESERVATION_COLLECTION_WAIT} from './preservation';
import {saveSeedFromGrain} from './wild_seed';
import { harvestPressure } from './ecology';
import { hasFloodAccess } from './flood';
import { drawWater, hasWaterBudget } from './hydrology';
import { observeShore, waterContact, workingWater } from './water_access';
import {isStoredDrink,storedWaterSource} from './stored_water_access';
import {projectAvailable} from './project_step';
import { relocationPackingBlocker } from './relocation';
import { spareSeed } from './seed_storage';
import { careFoodAvailable, careWaterAvailable, careStoreBlocker } from './care_capacity';
import {careJourneyReceipt} from './care_journey';
import { runsRulesVersion } from './rulesversion';
import { mayCollectMaterialStock } from './material_stock';
import { creditProject, mayWorkProject } from './townships';
import { endActivity, faceToward, registerHandler } from './activities';
import type { WorkResult } from './activities';
import { LOAN_TERM, NUTRITION, SOURCE_SKILL, SKILL_MAX, WATER_VALUE, WORK, isHomeType } from './constants';
import { notePractice } from './apprentice';
import { riskOfHarm } from './life';
import { onTheft } from './misdeeds';
import {
  addItem,
  claimUnits,
  consume,
  foodUnits,
  gatherFromSource,
  invRoom,
  ledgerConsume,
  ledgerCreate,
  pickFood,
  produce,
  releaseClaims,
  roomFor,
  takeFrom,
  transfer,
} from './economy';
import { addFx, addLog } from './events';
import { clearFailure, noteFailure, observe, delBelief, isWaterBeliefId } from './knowledge';
import { mayDeposit, noteDeposit, noteWithdraw, withdrawAllowance } from './facilities';
import { hasCivicFoodBenefit, recordCivicBenefit, recordCivicFoodBenefit } from './civic_benefit';
import { carryCap } from './people';
import { taskMultiplier, wearFor } from './tools';
import type { ToolTask } from './tools';
import { adjustRel } from './relations';
import { contestLost, creditContribution, fulfillCommitment } from './social';
import { fellTree } from './sources';
import { distToFootprint, isWater } from './registry';
import { isToolItem } from './toolreg';
import { creditHauled, creditStocked } from './intent';
import { noteHauled } from './transport';
import { customerSuppliedAtSite } from './customers';
import { noteWinterMeal } from './winter_practice';
import { hasWinterReserve, isFoodKind } from './provision';
import { hasDeliveryPlace } from './delivery_place';
import { personById } from './registry';
import { eatsAtTheStore } from './tableeating';
import type { Activity, FoodKind, Items, ItemKind, Person, Source, ToolKind, World } from './types';
import { clamp, hyp } from './util';

// ───────────────────────── helpers ─────────────────────────
function skillOf(p: Person, s: Source): number {
  return p.skills[SOURCE_SKILL[s.type]];
}

function toolTask(s: Source,world:World): ToolTask | null {
  if(s.type==='fish_spot'&&hasRods(world))return 'fish';
  switch (s.type) {
    case 'tree':
      return 'chop';
    case 'rock':
    case 'outcrop':
    case 'clay_pit':
    case 'ore_vein':
      return 'mine';
    case 'berry_bush':
    case 'fruit_tree':
    case 'wild_grain':
      return 'forage';
    default:
      return null;
  }
}

function toolMult(world: World, p: Person, s: Source): number {
  const t = toolTask(s,world);
  return t ? taskMultiplier(world, p, t) : 1;
}

function cycleDuration(world: World, p: Person, s: Source): number {
  const base = WORK[s.type] ?? 30;
  let d = (base * toolMult(world, p, s)) / skillOf(p, s);
  d *= 1 + 0.12 * world.weather.rain + 0.1 * world.weather.storm;
  if (p.needs.energy < 25) d *= 1.2;
  return Math.max(6, Math.round(d));
}

function sourceOf(world: World, a: Activity): Source | null {
  const e = world.byId.get(a.targetId);
  return e && e.ent === 'source' ? e : null;
}

// ───────────────────────── gather ─────────────────────────
function startCycle(world: World, p: Person, a: Activity, s: Source): string | null {
  if (s.type === 'tree' && s.amount < 1) return 'nothing to take yet';
  const id = claimUnits(world, p.id, s, 1, cycleDuration(world, p, s) + 40);
  if (!id) {
    return s.amount <= 0 ? 'nothing left' : 'someone else is already taking it';
  }
  a.claims.push(id);
  a.progress = 0;
  a.pprogress = 0;
  a.duration = cycleDuration(world, p, s);
  return null;
}

function gatherPose(a: Activity) {
  switch (a.data.stype as string) {
    case 'tree':
      return 'chop' as const;
    case 'rock':
      return 'mine' as const;
    case 'fish_spot':
      return 'fish' as const;
    default:
      return 'pick' as const;
  }
}

registerHandler('gather', {
  availability: 0.38,
  pose: gatherPose,
  begin(world, p, a) {
    const s = sourceOf(world, a);
    if (!s) {
      delBelief(p, a.targetId);
      return 'it is gone';
    }
    a.data.stype = s.type;
    observe(world, p, s); // arriving, they see its real state
    faceToward(p, s.x + 0.5, s.y + 0.5, 3);
    const err = startCycle(world, p, a, s);
    if (err) {
      a.blocked = err;
      if (err.startsWith('someone')) a.data.contest = true;
      // Resuming after company re-enters begin. Earlier paid units still belong
      // to this activity, just as when a later cycle runs out during work.
      if (world.settings.dynamics==='rich' && runsRulesVersion(world,121) && a.cycle>0) {
        endActivity(world,p,'partial',err);return;
      }
      return err;
    }
  },
  work(world, p, a): WorkResult {
    const s = sourceOf(world, a);
    if (!s) return a.cycle > 0 ? 'partial:the source disappeared' : 'fail:the source disappeared';
    faceToward(p, s.x + 0.5, s.y + 0.5);
    a.progress++;
    if (a.progress === Math.floor(a.duration * 0.55)) {
      addFx(world, s.type === 'tree' ? 'chop' : s.type === 'rock' ? 'mine' : s.type === 'fish_spot' ? 'splash' : 'pick', s.x + 0.5, s.y + 0.5, 0);
    }
    if (a.progress < a.duration) return 'continue';

    // the claimed unit is taken from the source and put into the pack
    releaseClaims(world, a.claims);
    let got = 0;
    if (a.data.purpose === 'eat' && invRoom(world, p, s.item) < 1 && NUTRITION[s.item as FoodKind] !== undefined && p.needs.hunger < 85 && s.amount >= 1) {
      // a full pack must not mean going hungry: eat it right there (the unit leaves the source and is consumed)
      s.amount -= 1;
      harvestPressure(world, s, 1);
      ledgerConsume(world, s.item, 1, 'eaten at the source');
      takeNutrition(world,p,NUTRITION[s.item as FoodKind]);
      p.lastAteTick = world.tick;
      addFx(world, 'eat', p.x, p.y, 0);
      got = 1;
    } else {
      got = gatherFromSource(world, s, p, 1);
    }
    if (got <= 0) {
      a.blocked = invRoom(world, p, s.item) < 1 ? 'pack is full' : 'nothing left';
      return a.cycle > 0 ? `partial:${a.blocked}` : `fail:${a.blocked}`;
    }
    s.lastTaker = p.id;
    s.lastTakeTick = world.tick;
    a.cycle++;
    p.stats.gathered++;
    const task = toolTask(s,world);
    if (task) wearFor(world, p, task, a.duration);
    const sk = SOURCE_SKILL[s.type];
    if (s.type === 'tree' || s.type === 'rock') riskOfHarm(world, p, s.type, 0.004);
    p.skills[sk] = Math.min(SKILL_MAX, p.skills[sk] + 0.004);
    notePractice(world, p, sk, 0.004);
    let retained=got;
    if (s.type === 'wild_grain' && world.rng.chance(0.2)) {
      // shell some of the grain heads for seed
      retained-=saveSeedFromGrain(world,p);
    }
    if(a.data.careSupply)a.data.careAcquired=(a.data.careAcquired??0)+retained;
    observe(world, p, s);
    clearFailure(p, s.id);
    if (s.type === 'tree' && s.amount <= 0 && s.growth >= 0.55) {
      fellTree(world, s);
      delBelief(p, s.id);
      a.blocked = 'felled the tree';
      return a.cycle >= a.amount ? 'done' : 'partial:the tree is used up';
    }
    if (a.cycle >= a.amount || (a.data.purpose === 'eat' && p.needs.hunger >= 88)) {
      a.blocked = '';
      return 'done';
    }
    if (invRoom(world, p, s.item) < 1 && !(a.data.purpose === 'eat' && NUTRITION[s.item as FoodKind] !== undefined)) {
      a.blocked = 'pack is full';
      return 'partial:pack is full';
    }
    const err = startCycle(world, p, a, s);
    if (err) {
      a.blocked = err;
      return `partial:${err}`;
    }
    return 'continue';
  },
  onEnd(world, p, a, outcome, detail) {
    const s = sourceOf(world, a);
    const name = a.data.stype ? String(a.data.stype).replace('_', ' ') : 'source';
    if (outcome === 'failed' || (outcome === 'partial' && a.cycle === 0)) {
      if (a.targetId) noteFailure(world, p, a.targetId, detail);
      const arrived=!runsRulesVersion(world,75)||a.phase==='work';
      if (s&&arrived) observe(world, p, s);
      a.data.logged = true;
      addLog(world, p, 'work', `${detail === 'nothing left' ? 'The ' + name + ' was empty when I got there' : 'Could not use the ' + name + ': ' + detail}.${arrived?'':' I did not reach it; its current stock is unknown.'}`);
      if (arrived&&(a.data.contest || detail.startsWith('someone'))) {
        if (s && s.lastTaker && s.lastTaker !== p.id && world.tick - s.lastTakeTick < 60) contestLost(world, p, s.lastTaker, s);
      }
    } else if (a.cycle > 0) {
      addLog(world, p, 'work', `Gathered ${a.cycle} ${s ? s.item : 'items'} from the ${name}.`);
      if (s && s.amount <= 0 && s.type !== 'tree') addLog(world, p, 'info', `The ${name} has been picked clean.`);
    }
  },
});

// ───────────────────────── eat ─────────────────────────
/** What a meal AT a store (`a.data.table`, rules version 9; tableeating.ts) is taken from: the store or pile itself, or null once it is gone. */
function tableItems(world: World, a: Activity): Items | null {
  const e = world.byId.get(a.targetId);
  return e && e.ent === 'building' ? e.store.items : e && e.ent === 'pile' ? e.items : null;
}

function eatTick(world: World, p: Person, a: Activity): WorkResult {
  if(a.data.table){const block=cellarAccess(world,p,world.byId.get(a.targetId));if(block)return `fail:${block}`;}
  if(a.data.table){const blocked=pileAccessBlocker(p,world.byId.get(a.targetId));if(blocked)return `fail:${blocked}`;}
  a.progress++;
  if (a.progress < a.duration) return 'continue';
  const k = a.data.food as FoodKind;
  // a meal at a store is eaten out of the store, through the same ledger entry as a bite out of a pack
  const table = a.data.table ? tableItems(world, a) : null;
  if (a.data.table && !table) return a.cycle > 0 ? 'done' : 'fail:the store is gone';
  const from = table ?? p.inv;
  // rules 46: a bite taken at the granary's bins is a bite out of the household's share (or the ration), and stops at it
  const store = a.data.table ? world.byId.get(a.targetId) : undefined;
  const rack = !!store&&store.ent==='building'&&store.type==='food_rack'&&runsPreservation(world);
  const bins = !!store && store.ent === 'building' && (store.type === 'granary' && hasWinterReserve(world) || rack);
  if(bins&&runsPreservation(world)&&withdrawAllowance(world,store,p,k,1)<1)return a.cycle>0?'done':'fail:the food is no longer ours to take';
  if (bins && ((a.data.ration as number) ?? 0) < 1) return a.cycle > 0 ? 'done' : 'fail:nothing of ours left in the bins';
  const eaten = consume(world, from, k, 1, 'eaten');
  if (bins && eaten > 0) {
    noteWithdraw(world, store, p, k, eaten);
    a.data.ration = ((a.data.ration as number) ?? 0) - eaten;
  }
  if (a.data.table && eaten === 0 && a.cycle === 0) return 'fail:somebody else had finished the food';
  if (eaten > 0) {
    takeNutrition(world,p,NUTRITION[k]);
    p.lastAteTick = world.tick;
    a.cycle++;
    addFx(world, 'eat', p.x, p.y, 0);
  }
  // a controller may have asked for a bounded meal: these only ever stop the meal sooner than it would have ended
  const lim = a.data.limit as Record<string, number> | undefined;
  if (lim) {
    if (lim.portions !== undefined && a.cycle >= lim.portions) return 'done';
    if (lim.untilHunger !== undefined && p.needs.hunger >= lim.untilHunger) return 'done';
  }
  const next = pickFood(bins&&runsPreservation(world)?Object.fromEntries(Object.entries(from).filter(([key])=>withdrawAllowance(world,store,p,key as ItemKind,1)>=1)):from, p.needs.hunger);
  const keepFood = (a.data.keep as number) ?? 0;
  const foodLeft = Object.keys(p.inv).reduce((s, key) => s + (NUTRITION[key as FoodKind] ? (p.inv[key as ItemKind] ?? 0) : 0), 0);
  if (!next || p.needs.hunger >= 88 || (keepFood > 0 && foodLeft <= keepFood && p.needs.hunger > 55)) return 'done';
  a.data.food = next;
  a.progress = 0;
  a.duration = WORK.eat;
  return 'continue';
}

registerHandler('eat', {
  availability: 0.55,
  pose: () => 'eat',
  begin(world, p, a) {
    const k = pickFood(p.inv, p.needs.hunger);
    if (!k) return 'no food on me';
    a.data.food = k;
    a.duration = WORK.eat;
  },
  work: (world, p, a) => eatTick(world, p, a),
});

registerHandler('eat_store', {
  availability: 0.4,
  pose: () => 'eat',
  begin(world, p, a) {
    {const block=cellarAccess(world,p,world.byId.get(a.targetId));if(block)return block;}
    const e = world.byId.get(a.targetId);
    if (!e || (e.ent !== 'building' && e.ent !== 'pile')) {
      delBelief(p, a.targetId);
      return 'it is gone';
    }
    {const blocked=pileAccessBlocker(p,e);if(blocked)return blocked;}
    observe(world, p, e);
    const items = e.ent === 'building' ? e.store.items : e.items;
    let want = Math.ceil((92 - p.needs.hunger) / 18);
    // rules 46: at a granary the meal is bounded by the household's share or the emergency ration (facilities.ts), checked unit by
    // unit against the bins as they are now, and each unit taken is booked against the share
    const bins = e.ent === 'building' && (e.type === 'granary' && hasWinterReserve(world) || e.type==='food_rack'&&runsPreservation(world));
    // the allowance is asked once per kind, for the whole meal, and spent unit by unit: the emergency ration is a ration, not a
    // right renewed with every bite
    const budget: Partial<Record<ItemKind, number>> = {};
    const allowed = (k: ItemKind): number => (budget[k] ??= bins && e.ent === 'building' ? withdrawAllowance(world, e, p, k, want) : want);
    const mealFood=(hunger:number)=>pickFood(bins&&runsPreservation(world)?Object.fromEntries(Object.entries(items).filter(([key])=>allowed(key as ItemKind)>=1)):items,hunger);
    let tookAny = false;
    for (let guard = 0; guard < 12 && want > 0; guard++) {
      const k = mealFood(p.needs.hunger + (a.cycle * 14));
      if (!k) break;
      if (bins && allowed(k) < 1) break;
      const got = transfer(world, items, p.inv, carryCap(world, p), k, 1, e.ent === 'building' ? 'building:' + e.id : 'pile:' + e.id, 'person:' + p.id, 'eat from store');
      if (!got) break;
      if (bins) {
        noteWithdraw(world, e, p, k, got);
        budget[k] = (budget[k] ?? 0) - got;
      }
      tookAny = true;
      want--;
      a.cycle++;
    }
    if (!tookAny) {
      // Version 9: nothing could be moved into the pack. If that is because the pack is full and the store DOES hold food, the
      // meal is eaten at the store (tableeating.ts); the store is not written off, because it is not empty.
      const k = eatsAtTheStore(world) ? mealFood(p.needs.hunger) : null;
      if (k && (!bins || allowed(k) >= 1)) {
        a.data.table = true;
        a.data.food = k;
        a.duration = WORK.eat;
        a.data.keep = 0;
        if (bins) a.data.ration = allowed(k); // the meal at the bins stops at the ration
        return;
      }
      noteFailure(world, p, a.targetId, 'no food there');
      return 'there is no food there';
    }
    observe(world, p, e);
    // taken from another household's store (rich only): who saw decides what it costs
    if (a.data.steal && e.ent === 'building') onTheft(world, p, e, a.cycle);
    if (hasCivicFoodBenefit(world)) a.data.took = a.cycle; // rules 49: what left the store for the pack (the meal's own count restarts at the first bite)
    a.cycle = 0;
    const k = pickFood(p.inv, p.needs.hunger);
    if (!k) return 'could not take food';
    a.data.food = k;
    a.duration = WORK.eat;
    a.data.keep = 0;
  },
  work: (world, p, a) => eatTick(world, p, a),
  onEnd(world, p, a, outcome, detail) {
    if (outcome === 'success') addLog(world, p, 'need', 'Ate a meal from the stores.');
    // rules 49 (civic_benefit.ts): a meal from a public storehouse is a benefit received, counted once when the meal ends by what
    // actually left the store for this person: the units moved to the pack at the start (a.data.took), or the bites eaten at the
    // table. Nothing is counted for arriving or for an empty store.
    {
      const e = world.byId.get(a.targetId);
      const took = (a.data.took as number) ?? 0;
      const ate = a.data.table ? a.cycle : 0;
      const units = took + ate;
      if (e && e.ent === 'building' && e.hhId === 0 && e.type === 'storehouse' && units > 0 && a.data.food) recordCivicFoodBenefit(world, p, e, a.data.food as ItemKind, units);
      // rules 53 (winter_practice.ts): a winter meal from the household's own store or a granary counts toward the practice
      if (e && e.ent === 'building' && outcome === 'success') noteWinterMeal(world, p, e, units);
    }
    if (a.data.table) {
      // A meal at a store was taken a bite at a time, so what it came to is known only now: the belief about the store is
      // refreshed as it stands after the meal, and a meal at another household's store is reported once, for what was eaten.
      const e = world.byId.get(a.targetId);
      if (e && (e.ent === 'building' || e.ent === 'pile') && !pileAccessBlocker(p,e)) {
        observe(world, p, e);
        if (a.data.steal && e.ent === 'building') onTheft(world, p, e, a.cycle);
        if (outcome === 'failed' && foodUnits(e.ent === 'building' ? e.store.items : e.items) <= 0) noteFailure(world, p, a.targetId, 'no food there');
      }
    }
  },
});

// ───────────────────────── drink / water ─────────────────────────
function waterFacing(world: World, p: Person): { x: number; y: number } | null {
  let best: { x: number; y: number } | null = null;
  let bd = 99;
  const tx = Math.floor(p.x);
  const ty = Math.floor(p.y);
  for (let dy = -2; dy <= 2; dy++) {
    for (let dx = -2; dx <= 2; dx++) {
      if (isWater(world, tx + dx, ty + dy)) {
        const d = hyp(dx, dy);
        if (d < bd) {
          bd = d;
          best = { x: tx + dx + 0.5, y: ty + dy + 0.5 };
        }
      }
    }
  }
  return best;
}

/** A remembered drinking place nobody can walk to is not worth remembering: forget it so another (or a search) takes over. */
function forgetUnreachableWater(world: World, p: Person, a: Activity, outcome: string, detail: string): void {
  // A temporary remembered hazard changes the route, not the existence of the shore.
  if(hasFloodAccess(world)&&a.data.floodWaitSince!==undefined)return;
  if (outcome === 'failed' && isWaterBeliefId(a.targetId) && /no way|blocked/.test(detail)) delBelief(p, a.targetId);
}

function beginNaturalWater(world: World, p: Person, a: Activity): string | undefined {
  const here=waterContact(world,p);
  if(!here)return 'not at an accessible water shore';
  observeShore(world,p);
  if(here.body.amount<1)return 'the water source is dry';
  a.data.wx=here.x;a.data.wy=here.y;a.data.waterBody=here.body.id;
}

registerHandler('drink', {
  availability: 0.55,
  pose: () => 'drink',
  begin(world, p, a) {
    if(isWellAction(a)){
      const well=wellSource(world,p,a);if(!well)return 'the well is inaccessible';
      observe(world,p,well);if((well.store.items.water??0)<1)return 'the well is empty';
      a.duration=8;return;
    }
    if(isStoredDrink(world,a)){
      const store=storedWaterSource(world,p,a);
      if(!store)return 'the household water store is inaccessible';
      observe(world,p,store);
      if((store.store.items.water??0)<1)return 'no water left in the home store';
      a.duration=8;return;
    }
    if (a.data.fromInv) {
      if ((p.inv.water ?? 0) < 1) return 'no water on me';
      a.duration = 8;
      return;
    }
    if(hasWaterBudget(world)) {
      const blocked=beginNaturalWater(world,p,a);if(blocked)return blocked;
      a.duration=8;return;
    }
    const w = waterFacing(world, p);
    if (!w) {
      // the remembered spot was not actually at the water
      delBelief(p, a.targetId);
      return 'no water here';
    }
    a.data.wx = w.x;
    a.data.wy = w.y;
    a.duration = Math.ceil((97 - p.needs.thirst) / 2.8) + 3;
    addFx(world, 'splash', w.x, w.y, 0);
  },
  onEnd(world, p, a, outcome, detail) {
    forgetUnreachableWater(world, p, a, outcome, detail);
  },
  work(world, p, a): WorkResult {
    if (a.data.fromInv || isStoredDrink(world,a) || isWellAction(a)) {
      const store=isWellAction(a)?wellSource(world,p,a):isStoredDrink(world,a)?storedWaterSource(world,p,a):null;
      if(isWellAction(a)&&!store)return 'fail:the well is inaccessible';
      if(isStoredDrink(world,a)&&!store)return 'fail:the household water store is inaccessible';
      const supply=store?store.store.items:p.inv;
      a.progress++;
      if (a.progress < a.duration) return 'continue';
      if(store)observe(world,p,store); // a failed sip also reveals the now-empty store
      if (consume(world, supply, 'water', 1, 'drunk') < 1) return 'fail:no water left';
      if(store)observe(world,p,store);
      p.needs.thirst = clamp(p.needs.thirst + WATER_VALUE, 0, 100);
      a.cycle++;
      if (p.needs.thirst >= 88 || (supply.water ?? 0) < 1) return 'done';
      a.progress = 0;
      return 'continue';
    }
    if(hasWaterBudget(world)) {
      const body=workingWater(world,p,a);
      if(!body)return a.cycle>0?'partial:cannot reach that shore now':'fail:cannot reach that shore now';
      faceToward(p,a.data.wx,a.data.wy,3);a.progress++;
      if(a.progress<a.duration)return 'continue';
      observeShore(world,p);
      const got=drawWater(world,body,1);
      if(!got)return a.cycle>0?'partial:the water source is dry':'fail:the water source is dry';
      ledgerConsume(world,'water',got,'drunk at natural water');
      p.needs.thirst=clamp(p.needs.thirst+WATER_VALUE,0,100);a.cycle++;a.progress=0;
      observeShore(world,p);addFx(world,'splash',a.data.wx,a.data.wy,0);
      return p.needs.thirst>=88?'done':'continue';
    }
    faceToward(p, a.data.wx, a.data.wy, 3);
    a.progress++;
    p.needs.thirst = clamp(p.needs.thirst + 2.8, 0, 100);
    if (a.progress >= a.duration || p.needs.thirst >= 97) return 'done';
    return 'continue';
  },
});

registerHandler('fetch_water', {
  availability: 0.5,
  pose: () => 'drink',
  begin(world, p, a) {
    if(isWellAction(a)){
      const well=wellSource(world,p,a);if(!well)return 'the well is inaccessible';
      observe(world,p,well);if((well.store.items.water??0)<1)return 'the well is empty';
      a.duration=WORK.water;a.progress=0;return;
    }
    if(hasWaterBudget(world)) {
      const blocked=beginNaturalWater(world,p,a);if(blocked)return blocked;
      a.duration=WORK.water;a.progress=0;return;
    }
    const w = waterFacing(world, p);
    if (!w) {
      delBelief(p, a.targetId);
      return 'no water here';
    }
    a.data.wx = w.x;
    a.data.wy = w.y;
    a.duration = WORK.water;
    a.progress = 0;
  },
  onEnd(world, p, a, outcome, detail) {
    forgetUnreachableWater(world, p, a, outcome, detail);
  },
  work(world, p, a): WorkResult {
    if(isWellAction(a)){
      const well=wellSource(world,p,a);if(!well)return a.cycle>0?'partial:the well is inaccessible':'fail:the well is inaccessible';
      faceToward(p,well.x+well.w/2,well.y+well.h/2,3);
      if(++a.progress<a.duration)return 'continue';
      observe(world,p,well);
      if((well.store.items.water??0)<1)return a.cycle>0?'partial:the well is empty':'fail:the well is empty';
      const got=transfer(world,well.store.items,p.inv,carryCap(world,p),'water',1,'building:'+well.id,'person:'+p.id,'water drawn from well');
      if(!got)return a.cycle>0?'partial:pack is full':'fail:pack is full';
      if(a.data.careSupply)a.data.careAcquired=(a.data.careAcquired??0)+got;
      observe(world,p,well);a.cycle++;a.progress=0;
      return a.cycle>=a.amount?'done':'continue';
    }
    const body=hasWaterBudget(world)?workingWater(world,p,a):undefined;
    if(hasWaterBudget(world)&&!body)return a.cycle>0?'partial:cannot reach that shore now':'fail:cannot reach that shore now';
    faceToward(p, a.data.wx, a.data.wy, 3);
    a.progress++;
    if (a.progress < a.duration) return 'continue';
    if(body)observeShore(world,p);
    if(body&&roomFor(p.inv,carryCap(world,p),'water')<1)return a.cycle>0?'partial:cannot carry more':'fail:cannot carry more';
    const got = body ? drawWater(world,body,1) : produce(world, p.inv, carryCap(world, p), 'water', 1, 'water drawn from the lake');
    if(body&&!got)return a.cycle>0?'partial:the water source is dry':'fail:the water source is dry';
    if(body&&got){addItem(p.inv,'water',got);world.hooks?.onTransfer?.({from:'water:'+body.id,to:'person:'+p.id,item:'water',n:got,reason:'natural water drawn'});observeShore(world,p);}
    if (got <= 0) return a.cycle > 0 ? 'partial:cannot carry more' : 'fail:cannot carry more';
    if(a.data.careSupply)a.data.careAcquired=(a.data.careAcquired??0)+got;
    addFx(world, 'splash', a.data.wx, a.data.wy, 0);
    a.cycle++;
    a.progress = 0;
    if (a.cycle >= a.amount) return 'done';
    if (roomFor(p.inv, carryCap(world, p), 'water') < 1) return 'partial:pack is full';
    return 'continue';
  },
});

// ───────────────────────── deposit / withdraw ─────────────────────────
function containerItems(world: World, id: number): { items: Items; cap: number; kind: 'building' | 'site' | 'pile' } | null {
  const e = world.byId.get(id);
  if (!e) return null;
  if (e.ent === 'building') return { items: e.store.items, cap: e.store.cap, kind: 'building' };
  if (e.ent === 'site') return { items: e.delivered, cap: 9999, kind: 'site' };
  if (e.ent === 'pile') return { items: e.items, cap: 9999, kind: 'pile' };
  return null;
}

function transferDuration(want: Record<string, number>): number {
  return 6 + Object.keys(want).length * 3;
}

registerHandler('deposit', {
  availability: 0.45,
  pose: () => 'store',
  begin(world, p, a) {
    {const block=communalStockBlock(world,p,a);if(block)return block;}
    {const block=cellarAccess(world,p,world.byId.get(a.targetId));if(block)return block;}
    const careBlocked = careStoreBlocker(world, p, a);
    if (careBlocked) return careBlocked;
    const c = containerItems(world, a.targetId);
    if (!c) {
      delBelief(p, a.targetId);
      return 'the place is gone';
    }
    const e = world.byId.get(a.targetId)!;
    if(e.ent==='pile'&&e.gear)return 'keep loose goods separate from deployed gear';
    if(e.ent==='pile'&&e.carcass)return 'keep loose goods separate from the body';
    if(e.ent==='pile'&&e.mealFood)return 'keep other goods separate from the leftover meal food';
    if(e.ent==='pile'&&e.estate)return 'keep new goods separate from these belongings';
    observe(world, p, e);
    a.duration = transferDuration(a.data.items ?? {});
    const door = e.ent === 'building' || e.ent === 'site' ? { x: e.x + e.w / 2, y: e.y + e.h / 2 } : { x: p.x, y: p.y };
    a.tx = door.x;
    a.ty = door.y;
  },
  work(world, p, a): WorkResult {
    {const block=communalStockBlock(world,p,a);if(block)return `fail:${block}`;}
    {const block=cellarAccess(world,p,world.byId.get(a.targetId));if(block)return `fail:${block}`;}
    const careBlocked = careStoreBlocker(world, p, a);
    if (careBlocked) return `fail:${careBlocked}`;
    faceToward(p, a.tx, a.ty);
    a.progress++;
    if (a.progress < a.duration) return 'continue';
    const c = containerItems(world, a.targetId);
    if (!c) return 'fail:the place is gone';
    const want = (a.data.items ?? {}) as Record<string, number>;
    let moved = 0;
    let partial = false;
    const e = world.byId.get(a.targetId)!;
    if(e.ent==='pile'&&e.gear)return 'fail:keep loose goods separate from deployed gear';
    if(e.ent==='pile'&&e.carcass)return 'fail:keep loose goods separate from the body';
    if(e.ent==='pile'&&e.mealFood)return 'fail:keep other goods separate from the leftover meal food';
    if(e.ent==='pile'&&e.estate)return 'fail:keep new goods separate from these belongings';
    for (const k of Object.keys(want)) {
      let n = Math.min(want[k], p.inv[k as ItemKind] ?? 0);
      if(a.data.communalStock){
        n=Math.min(n,communalSpare(world,p,k as ItemKind),communalRoom(world,a.targetId,k as ItemKind));
        if(n<=0){partial=true;continue;}
      }
      if(a.data.projectSupply&&runsRulesVersion(world,69)){
        const plan=p.intentions.find(i=>i.id===a.data.projectSupply&&i.status==='active'&&i.project);
        if(!plan)return 'fail:the project was cancelled';
        if(!plan.project!.nodes.some(node=>node.destination===a.targetId&&node.item===k))return 'fail:that delivery is not a project prerequisite';
        n=Math.min(n,projectAvailable(world,p,plan,k as ItemKind));
        if(n<=0)return 'fail:the material is needed for another plan or promise';
        if(n<want[k])partial=true;
      }
      if (a.data.careStore && runsRulesVersion(world, 63)) {
        const water = a.data.careWaterStore && runsRulesVersion(world, 68);
        n = Math.min(n, water ? careWaterAvailable(world, p, a.data.careRecipient as number) : careFoodAvailable(world, p, a.data.careRecipient as number, k as ItemKind));
        if (n <= 0) return water ? 'fail:the water is now needed for my own needs, others or promises' : 'fail:the food is now needed for my own needs, others or promises';
        if (n < want[k]) partial = true;
      }
      if (a.data.seedStash && world.settings.dynamics === 'rich' && runsRulesVersion(world,58)) {
        if (e.ent !== 'building' || !isHomeType(e.type) || e.hhId !== a.data.seedOwner || p.hhId !== a.data.seedOwner) return 'fail:the seed store is no longer our home';
        if (k !== 'seeds') return 'fail:only spare seed belongs in this trip';
        n = Math.min(n, spareSeed(p));
        if (n === 0) return 'fail:the seed is now needed for planting or promises';
        if (n < want[k]) partial = true;
      }
      if (n <= 0) continue;
      if (e.ent === 'building' && !mayDeposit(e, k as ItemKind)) {
        partial = true;
        continue;
      }
      const m = transfer(world, p.inv, c.items, c.cap, k as ItemKind, n, 'person:' + p.id, c.kind + ':' + a.targetId, 'deposit');
      moved += m;
      if (m < n) partial = true;
      if (m > 0) {
        a.data.moved = { ...(a.data.moved ?? {}), [k]: ((a.data.moved ?? {})[k] ?? 0) + m };
        if(a.data.careStore)careJourneyReceipt(world,p,a.data.careRecipient as number,{[k]:m},true);
        if (e.ent === 'building' && isToolItem(k as ItemKind)) donateToRack(world, e.id, p, k as ToolKind, m);
        if (e.ent === 'building') {
          noteDeposit(world, e, p, k as ItemKind, m);
          // a food reserve is credited where the food actually moves, not from the store looking full afterwards
          if (isFoodKind(k as ItemKind) && a.data.mode !== 'promise') creditStocked(p, e.id, m, e.ent === 'building' && e.type === 'granary' && hasWinterReserve(world));
          if (a.data.destSite) creditContribution(p, a.data.destSite as number, 12 * m);
        }
        if (e.ent === 'site' && e.contrib) e.contrib[p.hhId] = (e.contrib[p.hhId] ?? 0) + m;
      }
    }
    if (e.ent === 'building' || e.ent === 'site' || e.ent === 'pile') observe(world, p, e);
    if (moved === 0) {
      if (a.data.mode === 'promise' && a.data.commitmentId) {
        const cm = p.commitments.find((x) => x.id === (a.data.commitmentId as number));
        if (cm) {
          cm.blocked = partial ? 'no room in the store to leave it' : 'had nothing to leave';
          cm.blockedAt = world.tick;
        }
      }
      return partial ? 'fail:no room' : 'fail:nothing to put down';
    }
    a.cycle = moved;
    // rules 48 (delivery_place.ts): left at the agreed place, the promise and the request record what actually arrived, once
    if (a.data.mode === 'promise' && a.data.commitmentId && hasDeliveryPlace(world)) {
      const cm = p.commitments.find((x) => x.id === (a.data.commitmentId as number));
      const gotHere = cm && cm.item ? ((a.data.moved ?? {}) as Record<string, number>)[cm.item] ?? 0 : 0;
      if (cm && cm.item && gotHere > 0) {
        cm.delivered = (cm.delivered ?? 0) + gotHere;
        const rq = world.requests.find((x) => x.id === cm.requestId);
        if (rq) rq.delivered = (rq.delivered ?? 0) + gotHere;
        const A = personById(world, cm.to);
        if (A) addLog(world, A, 'social', `${p.name} left ${gotHere} ${cm.item} at our door, as promised.`);
        addLog(world, p, 'social', `Left ${gotHere} ${cm.item} at ${A?.name ?? 'their'}’s door, as promised.`);
        if ((cm.delivered ?? 0) >= cm.amount) fulfillCommitment(world, p, cm.id);
      }
      // a promise left at the door is not a deposit of one's own: nothing is credited to a reserve plan or a site
      a.data.moved = {};
    }
    if (p.errand && p.errand.targetId === a.targetId) p.errand = null;
    if (c.kind === 'site') {
      addFx(world, 'deliver', e.ent === 'site' ? e.x + e.w / 2 : p.x, e.ent === 'site' ? e.y + e.h / 2 : p.y, 0);
    }
    return partial ? a.data.careStore ? a.data.careWaterStore && runsRulesVersion(world, 68) ? 'partial:only water that remained spare and fit was left' : 'partial:only food that remained spare and fit was left' : 'partial:no room for everything' : 'done';
  },
  onEnd(world, p, a, outcome) {
    if (a.cycle > 0) {
      const moved = a.data.moved as Record<string, number> | undefined;
      const txt = moved ? Object.entries(moved).map(([k, n]) => `${n} ${k}`).join(', ') : `${a.cycle} items`;
      const e = world.byId.get(a.targetId);
      const where = e && e.ent === 'site' ? 'the building site' : e && e.ent === 'building' ? 'the ' + (e.type === 'storehouse' ? 'storehouse' : 'home store') : 'the pile';
      // a left-over put down to make room says so (leave_heaviest.ts); every other deposit reads exactly as it always did
      addLog(world, p, 'work', typeof a.data.leftAt === 'string' ? `Left ${txt} at ${a.data.leftAt} to free my hands.` : `Put ${txt} into ${where}.`);
    }
  },
});

registerHandler('haul', {
  availability: 0.45,
  pose: () => 'store',
  begin: (world, p, a) => {
    const h = world.byId.get(a.targetId);
    if (!h || h.ent !== 'site') {
      delBelief(p, a.targetId);
      return 'the site is gone (finished or abandoned)';
    }
    if (!mayWorkProject(world, p, h.id)) return 'has not agreed to this public project';
    observe(world, p, h);
    a.duration = transferDuration(a.data.items ?? {});
    a.tx = h.x + h.w / 2;
    a.ty = h.y + h.h / 2;
  },
  work(world, p, a): WorkResult {
    faceToward(p, a.tx, a.ty);
    a.progress++;
    if (a.progress < a.duration) return 'continue';
    const site = world.byId.get(a.targetId);
    if (!site || site.ent !== 'site') return 'fail:the site is gone';
    if (!mayWorkProject(world, p, site.id)) return 'fail:participation withdrawn';
    const want = (a.data.items ?? {}) as Record<string, number>;
    let moved = 0;
    for (const k of Object.keys(want)) {
      const need = (site.required[k as ItemKind] ?? 0) - (site.delivered[k as ItemKind] ?? 0) - (site.used[k as ItemKind] ?? 0);
      const n = Math.min(want[k], p.inv[k as ItemKind] ?? 0, Math.max(0, need));
      if (n <= 0) continue;
      const m = transfer(world, p.inv, site.delivered, 9999, k as ItemKind, n, 'person:' + p.id, 'site:' + site.id, 'delivery');
      moved += m;
      if (m > 0) creditProject(world, p, site.id, k as ItemKind, m);
      if (m > 0 && site.contrib) site.contrib[p.hhId] = (site.contrib[p.hhId] ?? 0) + m;
      if (m > 0) a.data.moved = { ...(a.data.moved ?? {}), [k]: ((a.data.moved ?? {})[k] ?? 0) + m };
    }
    observe(world, p, site);
    // credit a shelter plan at the one place material actually moves into a site, so a plan can only call itself finished
    // on what this person's own hands carried (intent.ts creditHauled; it does nothing for any other kind of plan)
    if (moved > 0) creditHauled(p, site.id, moved);
    // rules 55 (transport.ts): what really reached the site on foot is the experience a cart is wanted on
    if (moved > 0) noteHauled(world, p, (a.data.moved ?? {}) as Partial<Items>);
    // rules 51 (customers.ts): a haul to a customer's own household site supplies what they asked for
    if (moved > 0) customerSuppliedAtSite(world, p, site.hhId, site.id, (a.data.moved ?? {}) as Partial<Items>);
    if (moved > 0) site.lastWorkTick = world.tick;
    if (p.errand && p.errand.targetId === site.id) p.errand = null;
    if (moved > 0) {
      for (const c of p.commitments) {
        if (c.status !== 'active' || c.siteId !== site.id) continue;
        c.contrib = (c.contrib ?? 0) + 40;
        const got = a.data.moved as Record<string, number> | undefined;
        if (c.kind === 'haul' && c.item && got && got[c.item]) {
          c.delivered = (c.delivered ?? 0) + got[c.item];
          if ((c.delivered ?? 0) >= c.amount) fulfillHaul(world, p, c);
        }
      }
    }
    if (moved === 0) return 'fail:the site no longer needs that';
    a.cycle = moved;
    addFx(world, 'deliver', site.x + site.w / 2, site.y + site.h / 2, 0);
    // the household that owns the site notices who helped
    if (site.hhId && site.hhId !== p.hhId) {
      for (const q of world.persons) {
        if (q.alive && q.hhId === site.hhId && hyp(q.x - p.x, q.y - p.y) < 8) adjustRel(q, p.id, world.tick, { aff: 1.8, trust: 1.5, fam: 0.5, note: `helped build our ${site.type.replace('_', '-')}` });
      }
    }
    return 'done';
  },
  onEnd(world, p, a) {
    if (a.cycle > 0) {
      const moved = a.data.moved as Record<string, number> | undefined;
      const txt = moved ? Object.entries(moved).map(([k, n]) => `${n} ${k}`).join(', ') : `${a.cycle} items`;
      addLog(world, p, 'work', `Delivered ${txt} to the building site.`);
    }
  },
});

registerHandler('withdraw', {
  availability: 0.45,
  pose: () => 'store',
  begin(world, p, a) {
    {const block=cellarAccess(world,p,world.byId.get(a.targetId));if(block)return block;}
    const blocked = relocationPackingBlocker(world,p,a); if (blocked) return blocked;
    const c = containerItems(world, a.targetId);
    if (!c) {
      delBelief(p, a.targetId);
      return 'the place is gone';
    }
    const e = world.byId.get(a.targetId)!;
    {const blocked=pileAccessBlocker(p,e);if(blocked)return blocked;}
    observe(world, p, e);
    if (a.data.materialStock && (e.ent !== 'building' || !mayCollectMaterialStock(p, e))) return 'this material store is no longer shared or ours';
    a.duration = transferDuration(a.data.items ?? {});
    a.tx = e.ent === 'building' || e.ent === 'site' ? e.x + e.w / 2 : p.x;
    a.ty = e.ent === 'building' || e.ent === 'site' ? e.y + e.h / 2 : p.y;
  },
  work(world, p, a): WorkResult {
    {const block=cellarAccess(world,p,world.byId.get(a.targetId));if(block)return `fail:${block}`;}
    const blocked = relocationPackingBlocker(world,p,a); if (blocked) return `fail:${blocked}`;
    const waitingAt=world.byId.get(a.targetId),waitingBuilding=waitingAt?.ent==='building'?waitingAt:undefined;
    const requested=(a.data.items??{}) as Items;
    const waiting=preservationCollectionReason(world,p,waitingBuilding,requested);
    if(waiting&&waitingBuilding&&!Object.entries(requested).some(([k,n])=>
      (waitingBuilding.store.items[k as ItemKind]??0)>0&&withdrawAllowance(world,waitingBuilding,p,k as ItemKind,n!)>0&&invRoom(world,p,k as ItemKind)>0)){
      if((a.data.preservationWait??0)>=PRESERVATION_COLLECTION_WAIT)return `fail:${waiting}; leave and try later`;
      a.data.preservationWait=(a.data.preservationWait??0)+1;a.blocked=waiting;
      return 'continue';
    }
    if(a.data.preservationWait!==undefined)a.blocked='';
    faceToward(p, a.tx, a.ty);
    a.progress++;
    if (a.progress < a.duration) return 'continue';
    const c = containerItems(world, a.targetId);
    if (!c) return 'fail:the place is gone';
    const want = (a.data.items ?? {}) as Record<string, number>;
    let moved = 0;
    const e = world.byId.get(a.targetId);
    {const blocked=pileAccessBlocker(p,e);if(blocked)return `fail:${blocked}`;}
    if (a.data.materialStock && (!e || e.ent !== 'building' || !mayCollectMaterialStock(p, e))) {
      if (e) observe(world, p, e);
      return 'fail:this material store is no longer shared or ours';
    }
    for (const k of Object.keys(want)) {
      let n = want[k];
      if (e && e.ent === 'building') n = withdrawAllowance(world, e, p, k as ItemKind, n);
      if (n <= 0) continue;
      const gear=ownedGearRules(world,k as ItemKind),record=gear?ownedGearAt(world,p,a.targetId,k as ItemKind)[0]:undefined;
      if(gear&&!record)continue;
      const m = transfer(world, c.items, p.inv, carryCap(world, p), k as ItemKind, gear?Math.min(n,1):n, c.kind + ':' + a.targetId, 'person:' + p.id, 'withdraw',record?.id);
      moved += m;
      if (m > 0 && e && e.ent === 'building') {
        noteWithdraw(world, e, p, k as ItemKind, m);
        recordCivicBenefit(world, p, e, k as ItemKind, m);
        if (isToolItem(k as ItemKind)) borrowFromRack(world, p, k as ToolKind, m);
      }
    }
    if (e) observe(world, p, e);
    if (moved === 0) {
      noteFailure(world, p, a.targetId, 'nothing there to take');
      return 'fail:there was nothing to take';
    }
    a.cycle = moved;
    return 'done';
  },
  onEnd(world, p, a) {
    if (a.cycle > 0) addLog(world, p, 'work', `Took ${a.cycle} item${a.cycle > 1 ? 's' : ''} from storage.`);
  },
});

/** A tool left on a shared rack is no longer anyone's own: it becomes the settlement's, free to be borrowed and brought back. */
function donateToRack(world: World, buildingId: number, p: Person, kind: ToolKind, n: number): void {
  if(ownedGearRules(world,kind))return;
  let left = n;
  for (const t of world.tools) {
    if (left <= 0) break;
    if (t.holder === buildingId && t.kind === kind && t.ownerHh === p.hhId && !t.loan) {
      t.ownerHh = 0;
      left--;
    }
  }
}

function fulfillHaul(world: World, p: Person, c: import('./types').Commitment): void {
  fulfillCommitment(world, p, c.id);
}

/** A tool taken off a shared rack belongs to someone else (or to nobody): it comes with a promise to return it. */
function borrowFromRack(world: World, p: Person, kind: ToolKind, n: number): void {
  let left = n;
  for (const t of world.tools) {
    if (left <= 0) break;
    if (t.holder === p.id && t.kind === kind && !t.loan && t.ownerHh !== p.hhId) {
      t.loan = { lender: 0, borrower: p.id, due: world.tick + LOAN_TERM };
      left--;
    }
  }
}

void addItem;
void takeFrom;
void ledgerCreate;
void WATER_VALUE;
void distToFootprint;

